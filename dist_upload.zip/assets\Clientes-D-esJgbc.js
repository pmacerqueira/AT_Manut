import{c as Re,b as ke,a as ne,u as le,j as e,A as Ee,i as Le,k as _e,S as Ge,T as Be,f as oe,m as ve,n as Ue}from"./index-Cqqd7WHe.js";import{r as c,d as Ve}from"./vendor-Bk0NZ5Or.js";import{F as He,M as Je,P as Ke,D as Ye}from"./DocumentacaoModal-l019Vr24.js";import{R as Qe}from"./RelatorioView-BP02FaXl.js";import{r as Xe,i as We}from"./gerarPdfRelatorio-DrHP5nOz.js";import{E as we,e as H,s as qe,a as Ze,M as ea}from"./emailConfig-DRobUt5f.js";import{f as $e}from"./format-BvtC0E8y.js";import{p as Se}from"./pt-BAJJYN30.js";import{f as V}from"./datasAzores-CBhl9I61.js";import{A as W}from"./arrow-left-C8TVZuGZ.js";import{P as ie,a as je}from"./plus-2ecO6mRW.js";import{T as aa}from"./trash-2-Ca2Pz469.js";import"./download-DA5F1Yzl.js";import"./chevron-down-B61E7OJo.js";const ta=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M8 18v-2",key:"qcmpov"}],["path",{d:"M12 18v-4",key:"q1q25u"}],["path",{d:"M16 18v-6",key:"15y0np"}]],ye=Re("file-chart-column-increasing",ta),Ne="comercial@navel.pt";function sa({isOpen:g,onClose:f,manutencao:y,relatorio:N,maquina:C,cliente:L}){const{getChecklistBySubcategoria:i,getSubcategoria:$,updateRelatorio:S}=ke(),{showToast:A}=ne(),{showGlobalLoading:R,hideGlobalLoading:M}=le(),[x,z]=c.useState(""),[I,k]=c.useState(!1),[F,v]=c.useState("");if(!g)return null;const s=C?i(C.subcategoriaId,y?.tipo||"periodica"):[],u=y?.data?$e(new Date(y.data),"d MMM yyyy",{locale:Se}):"",n=`Relatório de manutenção — ${C?.marca} ${C?.modelo} (${u}) — Navel`,o=async p=>{p.preventDefault(),v("");const h=x.trim();if(!h){v("Indique o endereço de email do destinatário.");return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(h)){v("Endereço de email inválido.");return}k(!0),R();try{const w=C?$(C.subcategoriaId):null,D=Xe(N,y,C,L,s,{subcategoriaNome:w?.nome,ultimoEnvio:N.ultimoEnvio,logoUrl:"/manut/logo.png"}),P=typeof window<"u"?window.location.origin:"",m=P?`${P.replace(/\/$/,"")}/api/send-report.php`:"/api/send-report.php",d=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({auth_token:we.AUTH_TOKEN,destinatario:h,cc:Ne,assunto:n,corpoHtml:D})});if(!d.ok){const G=await d.text();throw new Error(G||`Erro ${d.status}`)}S(N.id,{ultimoEnvio:{data:new Date().toISOString(),destinatario:h}}),A(`Email enviado para ${h}.`,"success"),z(""),f()}catch(w){v(w.message||"Erro ao enviar email.")}finally{k(!1),M()}};return e.jsx("div",{className:"modal-overlay",onClick:f,children:e.jsxs("div",{className:"modal",onClick:p=>p.stopPropagation(),children:[e.jsx("h2",{children:"Enviar relatório por email"}),e.jsxs("p",{className:"text-muted",children:["O email será enviado para o endereço indicado e em cópia para ",Ne,"."]}),e.jsxs("form",{onSubmit:o,children:[e.jsxs("label",{children:["Email do destinatário ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:x,onChange:p=>{z(p.target.value),v("")},placeholder:"ex: cliente@empresa.pt",required:!0,disabled:I})]}),F&&e.jsx("p",{className:"form-erro",children:F}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:f,disabled:I,children:"Cancelar"}),e.jsx("button",{type:"submit",disabled:I,children:I?"A enviar…":e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"✉"})," Enviar email"]})})]})]})]})})}const Ce="comercial@navel.pt";function oa({isOpen:g,onClose:f,documento:y,maquina:N}){const{showToast:C}=ne(),{showGlobalLoading:L,hideGlobalLoading:i}=le(),[$,S]=c.useState(""),[A,R]=c.useState(!1),[M,x]=c.useState("");if(!g)return null;const I=`Documento: ${y?.titulo||"Documento"} — ${N?.marca} ${N?.modelo} — Navel`,k=`
<!DOCTYPE html>
<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5;color:#333">
<p>Segue o documento solicitado relativo ao equipamento <strong>${H(N?.marca||"")} ${H(N?.modelo||"")}</strong> (Nº Série: ${H(String(N?.numeroSerie||"—"))}).</p>
<p><a href="${qe(y?.url)}" style="color:#2563eb">Abrir documento (PDF)</a></p>
<p style="margin-top:2em;font-size:0.9em;color:#666">— Navel Manutenções · www.navel.pt</p>
<p style="margin-top:1.5em;font-size:0.75em;color:#999;border-top:1px solid #ddd;padding-top:0.5em">${H(Ee)}</p>
</body></html>`,F=async v=>{v.preventDefault(),x("");const s=$.trim();if(!s){x("Indique o endereço de email do destinatário.");return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)){x("Endereço de email inválido.");return}R(!0),L();try{const n=typeof window<"u"?window.location.origin:"",o=n?`${n.replace(/\/$/,"")}/api/send-report.php`:"/api/send-report.php",p=await fetch(o,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({auth_token:we.AUTH_TOKEN,destinatario:s,cc:Ce,assunto:I,corpoHtml:k})});if(!p.ok){const h=await p.text();throw new Error(h||`Erro ${p.status}`)}C(`Email enviado para ${s}.`,"success"),S(""),f()}catch(n){x(n.message||"Erro ao enviar email.")}finally{R(!1),i()}};return e.jsx("div",{className:"modal-overlay",onClick:f,children:e.jsxs("div",{className:"modal",onClick:v=>v.stopPropagation(),children:[e.jsx("h2",{children:"Enviar documento por email"}),e.jsxs("p",{className:"text-muted",children:["O email será enviado para o endereço indicado e em cópia para ",Ce,"."]}),e.jsxs("form",{onSubmit:F,children:[e.jsxs("label",{children:["Email do destinatário ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:$,onChange:v=>{S(v.target.value),x("")},placeholder:"ex: cliente@empresa.pt",required:!0,disabled:A})]}),M&&e.jsx("p",{className:"form-erro",children:M}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:f,disabled:A,children:"Cancelar"}),e.jsx("button",{type:"submit",disabled:A,children:A?"A enviar…":"Enviar"})]})]})]})})}const Z={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",sede:"Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",web:"www.navel.pt"};function ia(g,f,y,N,C,L={}){const i=H,$=L.logoUrl??"/manut/logo.png",S=new Date().toISOString().slice(0,10),A=V(S,!0),R=new Date().getFullYear(),M=f.map(s=>{const u=C(s.subcategoriaId),n=y.filter(m=>m.maquinaId===s.id),o=n.filter(m=>m.status==="concluida").sort((m,d)=>d.data.localeCompare(m.data))[0],p=n.filter(m=>m.status==="agendada"||m.status==="pendente").sort((m,d)=>m.data.localeCompare(d.data))[0],h=p&&p.data<S,E=n.filter(m=>m.status==="concluida").length,w=o?N.find(m=>m.manutencaoId===o.id):null;let D,P;return s.proximaManut?h?(D="badge-atraso",P="Em atraso"):(D="badge-ok",P="Conforme"):(D="badge-montagem",P="Por instalar"),{m:s,sub:u,ultima:o,proxima:p,emAtraso:h,totalManuts:E,relUltima:w,estadoBadge:D,estadoLabel:P}}),x=f.length,z=M.filter(s=>s.emAtraso).length,I=M.filter(s=>!s.emAtraso&&s.m.proximaManut).length,k=M.filter(s=>!s.m.proximaManut).length,F=x>0?Math.round(I/x*100):0;return`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Frota — ${i(g.nome)}</title>
<style>
/* ── Reset / Página ── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
@page{size:A4 portrait;margin:14mm 12mm 12mm}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:9pt;color:#1e293b;background:#fff;line-height:1.4}
/* ── Paleta ── */
:root{
  --azul:#0f4c81;--azul-light:#e8f1fb;--cinza:#f8fafc;
  --verde:#15803d;--verde-light:#dcfce7;
  --vermelho:#dc2626;--vermelho-light:#fee2e2;
  --laranja:#d97706;--laranja-light:#fef3c7;
  --muted:#64748b;--border:#e2e8f0;
}
/* ── Cabeçalho ── */
.header{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px;border-bottom:2px solid var(--azul);margin-bottom:10px}
.header-logo img{height:36px;object-fit:contain}
.header-empresa{text-align:right;font-size:7.5pt;color:var(--muted);line-height:1.5}
.header-empresa strong{color:var(--azul);font-size:8.5pt}
/* ── Títulos de secção ── */
.secao-titulo{background:var(--azul);color:#fff;padding:4px 8px;font-size:8pt;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px;border-radius:3px}
/* ── Ficha do cliente ── */
.cliente-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:3px 12px;padding:8px 10px;background:var(--cinza);border-radius:4px;border:1px solid var(--border);margin-bottom:10px}
.cliente-field{display:flex;flex-direction:column;gap:1px}
.c-label{font-size:7pt;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}
.c-value{font-size:8.5pt;font-weight:600;color:#1e293b}
/* ── KPIs ── */
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px}
.kpi-card{background:var(--cinza);border:1px solid var(--border);border-radius:5px;padding:7px 8px;text-align:center}
.kpi-card.kpi-verde{background:var(--verde-light);border-color:var(--verde)}
.kpi-card.kpi-vermelho{background:var(--vermelho-light);border-color:var(--vermelho)}
.kpi-card.kpi-laranja{background:var(--laranja-light);border-color:var(--laranja)}
.kpi-numero{font-size:18pt;font-weight:800;line-height:1.1}
.kpi-verde .kpi-numero{color:var(--verde)}
.kpi-vermelho .kpi-numero{color:var(--vermelho)}
.kpi-laranja .kpi-numero{color:var(--laranja)}
.kpi-label{font-size:7pt;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;margin-top:2px}
/* ── Tabela de frota ── */
.tabela-frota{width:100%;border-collapse:collapse;font-size:8pt}
.tabela-frota th{background:var(--azul);color:#fff;padding:4px 5px;text-align:left;font-size:7.5pt;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.tabela-frota td{padding:3.5px 5px;border-bottom:1px solid var(--border);vertical-align:middle}
.tabela-frota tr:nth-child(even) td{background:var(--cinza)}
.tabela-frota tr:hover td{background:var(--azul-light)}
.col-equip{width:28%}
.col-serie{width:16%;font-family:monospace;font-size:7.5pt;color:var(--muted)}
.col-ultima{width:14%;text-align:center}
.col-proxima{width:14%;text-align:center}
.col-total{width:8%;text-align:center;color:var(--muted)}
.col-estado{width:13%;text-align:center}
.col-num{width:7%;text-align:center;color:var(--muted);font-size:7pt}
/* ── Badges ── */
.badge{display:inline-block;padding:1.5px 6px;border-radius:10px;font-size:7pt;font-weight:700;white-space:nowrap}
.badge-ok{background:var(--verde-light);color:var(--verde)}
.badge-atraso{background:var(--vermelho-light);color:var(--vermelho)}
.badge-montagem{background:var(--laranja-light);color:var(--laranja)}
.data-atraso{color:var(--vermelho);font-weight:600}
.data-ok{color:var(--verde)}
/* ── Rodapé ── */
.rodape{margin-top:12px;padding-top:6px;border-top:1px solid var(--border);font-size:7pt;color:var(--muted);display:flex;justify-content:space-between;align-items:center}
.rodape-data{font-size:7pt;color:var(--muted)}
</style>
</head>
<body>

<!-- Cabeçalho -->
<div class="header">
  <div class="header-logo">
    <img src="${$}" alt="Navel-Açores">
  </div>
  <div class="header-empresa">
    <strong>${i(Z.nome)}</strong><br>
    ${i(Z.sede)}<br>
    ${i(Z.telefones)} · ${i(Z.web)}
  </div>
</div>

<!-- Título -->
<div class="secao-titulo">Relatório Executivo de Frota — ${R}</div>

<!-- Ficha do cliente -->
<div class="cliente-grid">
  <div class="cliente-field">
    <span class="c-label">Cliente</span>
    <span class="c-value">${i(g.nome)}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">NIF</span>
    <span class="c-value">${i(g.nif??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Localidade</span>
    <span class="c-value">${i(g.localidade??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Morada</span>
    <span class="c-value">${i(g.morada??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Telefone</span>
    <span class="c-value">${i(g.telefone??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Email</span>
    <span class="c-value">${i(g.email??"—")}</span>
  </div>
</div>

<!-- KPIs -->
<div class="kpis">
  <div class="kpi-card">
    <div class="kpi-numero">${x}</div>
    <div class="kpi-label">Equipamentos</div>
  </div>
  <div class="kpi-card ${F>=80?"kpi-verde":F>=50?"kpi-laranja":"kpi-vermelho"}">
    <div class="kpi-numero">${F}%</div>
    <div class="kpi-label">Taxa de cumprimento</div>
  </div>
  <div class="kpi-card ${z>0?"kpi-vermelho":"kpi-verde"}">
    <div class="kpi-numero">${z}</div>
    <div class="kpi-label">Em atraso</div>
  </div>
  <div class="kpi-card ${k>0?"kpi-laranja":""}">
    <div class="kpi-numero">${k}</div>
    <div class="kpi-label">Por instalar</div>
  </div>
</div>

<!-- Tabela de frota -->
<div class="secao-titulo">Frota de equipamentos (${x})</div>
<table class="tabela-frota">
  <thead>
    <tr>
      <th class="col-equip">Equipamento / Modelo</th>
      <th class="col-serie">Nº Série</th>
      <th class="col-ultima">Última manut.</th>
      <th class="col-proxima">Próxima manut.</th>
      <th class="col-total">Nº serv.</th>
      <th class="col-estado">Estado</th>
      <th class="col-num">Últ. relatório</th>
    </tr>
  </thead>
  <tbody>
    ${M.map(({m:s,sub:u,ultima:n,proxima:o,relUltima:p,estadoBadge:h,estadoLabel:E})=>`
    <tr>
      <td class="col-equip">
        <strong>${i(s.marca)} ${i(s.modelo)}</strong>
        ${u?`<br><span style="font-size:7pt;color:var(--muted)">${i(u.nome)}</span>`:""}
      </td>
      <td class="col-serie">${i(s.numeroSerie)}</td>
      <td class="col-ultima" style="text-align:center">${n?V(n.data,!0):"—"}</td>
      <td class="col-proxima" style="text-align:center">
        ${o?`<span class="${o.data<S?"data-atraso":"data-ok"}">${V(o.data,!0)}</span>`:s.proximaManut?`<span class="${s.proximaManut<S?"data-atraso":"data-ok"}">${V(s.proximaManut,!0)}</span>`:"—"}
      </td>
      <td class="col-total">${s.proximaManut?y.filter(w=>w.maquinaId===s.id&&w.status==="concluida").length:"—"}</td>
      <td class="col-estado" style="text-align:center"><span class="badge ${h}">${i(E)}</span></td>
      <td class="col-num">${p?.numeroRelatorio?`<span style="font-size:7pt">${i(p.numeroRelatorio)}</span>`:"—"}</td>
    </tr>`).join("")}
  </tbody>
</table>

${z>0?`
<div class="secao-titulo" style="background:var(--vermelho);margin-top:12px">Manutenções em atraso (${z})</div>
<table class="tabela-frota">
  <thead>
    <tr>
      <th style="width:35%">Equipamento</th>
      <th style="width:18%">Nº Série</th>
      <th style="width:15%">Data prevista</th>
      <th style="width:10%">Dias atraso</th>
      <th style="width:22%">Observações</th>
    </tr>
  </thead>
  <tbody>
    ${M.filter(s=>s.emAtraso).map(({m:s,sub:u,proxima:n})=>{const o=Math.max(0,Math.floor((new Date(S)-new Date(n.data))/864e5));return`<tr>
        <td><strong>${i(s.marca)} ${i(s.modelo)}</strong>${u?` <span style="color:var(--muted);font-size:7pt">· ${i(u.nome)}</span>`:""}</td>
        <td style="font-family:monospace;font-size:7.5pt">${i(s.numeroSerie)}</td>
        <td class="data-atraso">${V(n.data,!0)}</td>
        <td class="data-atraso" style="text-align:center;font-weight:700">${o}d</td>
        <td style="font-size:7.5pt;color:var(--muted)">${i(n.observacoes??"")}</td>
      </tr>`}).join("")}
  </tbody>
</table>`:""}

<!-- Rodapé -->
<div class="rodape">
  <span>${i(Ee)}</span>
  <span class="rodape-data">Documento gerado em ${A}</span>
</div>

</body>
</html>`}const na={pendente:"Pendente",agendada:"Agendada",concluida:"Executada"};function ya(){const{clientes:g,maquinas:f,manutencoes:y,relatorios:N,addCliente:C,updateCliente:L,removeCliente:i,getSubcategoria:$,getCategoria:S,getChecklistBySubcategoria:A,getRelatorioByManutencao:R}=ke(),{canDelete:M,canEditCliente:x,canAddCliente:z,isAdmin:I}=Le(),{showToast:k}=ne(),{showGlobalLoading:F,hideGlobalLoading:v}=le(),s=Ve(),[u,n]=c.useState(null),[o,p]=c.useState(null),[h,E]=c.useState("categorias"),[w,D]=c.useState(null),[P,m]=c.useState(null),[d,G]=c.useState(null),[J,K]=c.useState(null),[re,de]=c.useState(null),[ce,ee]=c.useState(null),[q,Y]=c.useState(null),[B,ae]=c.useState(null),[te,me]=c.useState(null),[T,O]=c.useState({nif:"",nome:"",morada:"",codigoPostal:"",localidade:"",telefone:"",email:""}),[ue,U]=c.useState(""),[se,pe]=c.useState(""),he=_e(se,250),Me=()=>{O({nif:"",nome:"",morada:"",codigoPostal:"",localidade:"",telefone:"",email:""}),U(""),n("add")},ze=a=>{O({nif:a.nif,nome:a.nome,morada:a.morada||"",codigoPostal:a.codigoPostal||"",localidade:a.localidade||"",telefone:a.telefone||"",email:a.email||""}),U(""),n("edit")},Pe=a=>{p(a),E("categorias"),D(null),m(null),G(null),O({nif:a.nif,nome:a.nome,morada:a.morada||"",codigoPostal:a.codigoPostal||"",localidade:a.localidade||"",telefone:a.telefone||"",email:a.email||""}),n("ficha")},ge=()=>{n(null),p(null),E("categorias"),D(null),m(null),G(null)},De=a=>{if(a.preventDefault(),U(""),!T.email?.trim()){U("O email do cliente é obrigatório para envio de lembretes e relatórios.");return}if(u==="add"){if(C(T)===null){U("Já existe um cliente com este NIF.");return}k("Cliente adicionado com sucesso.","success")}else{const{nif:t,...r}=T;L(t,r),o?.nif===t&&p(j=>j?{...j,...r}:null),k("Dados do cliente actualizados.","success")}u!=="ficha"&&n(null)},Q=a=>f.filter(t=>t.clienteNif===a).length,xe=a=>f.filter(t=>t.clienteNif===a),be=async a=>{const t=xe(a.nif);if(t.length===0){k("Este cliente não tem equipamentos registados.","warning");return}F();try{const r=ia(a,t,y,N??[],$,{logoUrl:"/manut/logo.png"}),j=`frota_${a.nif}_${new Date().toISOString().slice(0,10)}.pdf`;await We(r,j)}catch{k("Erro ao gerar relatório de frota.","error",4e3)}finally{v()}},_=o?xe(o.nif):[],Ae=_.reduce((a,t)=>{const r=$(t.subcategoriaId),j=r?S(r.categoriaId):null;return j&&!a.find(l=>l.id===j.id)&&a.push(j),a},[]).sort((a,t)=>(a.nome||"").localeCompare(t.nome||"")),Ie=w?_.filter(a=>$(a.subcategoriaId)?.categoriaId===w.id).reduce((a,t)=>{const r=$(t.subcategoriaId);return r&&!a.find(j=>j.id===r.id)&&a.push(r),a},[]).sort((a,t)=>(a.nome||"").localeCompare(t.nome||"")):[],Fe=P?_.filter(a=>a.subcategoriaId===P.id):[],fe=a=>y.filter(t=>t.maquinaId===a).sort((t,r)=>new Date(r.data)-new Date(t.data)),Te=c.useMemo(()=>{const a=he.trim().toLowerCase();if(!a)return g;const t=a.split(/\s+/).filter(Boolean);return g.filter(r=>{const j=(r.nif||"").toLowerCase().includes(a),l=t.some(b=>(r.nome||"").toLowerCase().includes(b));return j||l})},[he,g]);return e.jsxs("div",{className:"page",children:[e.jsxs("div",{className:"page-header",children:[e.jsxs("div",{children:[e.jsxs("button",{type:"button",className:"btn-back",onClick:()=>s(-1),children:[e.jsx(W,{size:20}),"Voltar atrás"]}),e.jsx("h1",{children:"Clientes"}),e.jsx("p",{className:"page-sub",children:"Empresas e proprietários de equipamentos Navel"})]}),z&&e.jsxs("button",{type:"button",onClick:Me,children:[e.jsx(ie,{size:18})," Novo cliente"]})]}),e.jsxs("div",{className:"search-bar",children:[e.jsx(Ge,{size:18,className:"search-icon"}),e.jsx("input",{type:"search",value:se,onChange:a=>pe(a.target.value),placeholder:"Pesquisar por NIF ou palavra do nome...","aria-label":"Pesquisar clientes"}),se&&e.jsx("button",{type:"button",className:"search-clear",onClick:()=>pe(""),"aria-label":"Limpar pesquisa",children:"×"})]}),e.jsx("div",{className:"table-card card clientes-table",children:e.jsxs("table",{className:"data-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"NIF"}),e.jsx("th",{children:"Nome do Cliente"}),e.jsx("th",{children:"Morada"}),e.jsx("th",{children:"Localidade"}),e.jsx("th",{children:"Telefone"}),e.jsx("th",{children:"Email"}),e.jsx("th",{children:"Máquinas"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:Te.map(a=>e.jsxs("tr",{children:[e.jsx("td",{"data-label":"NIF",children:e.jsx("code",{children:a.nif})}),e.jsx("td",{"data-label":"Nome",children:e.jsx("button",{type:"button",className:"btn-link-inline",onClick:()=>Pe(a),title:"Abrir ficha",children:e.jsx("strong",{children:a.nome})})}),e.jsx("td",{"data-label":"Morada",children:a.morada||"—"}),e.jsx("td",{"data-label":"Localidade",children:a.localidade||"—"}),e.jsx("td",{"data-label":"Telefone",children:a.telefone||"—"}),e.jsx("td",{"data-label":"Email",children:a.email?a.email:e.jsxs("span",{className:"sem-email-aviso",title:"Email em falta — edite o cliente para corrigir",children:[e.jsx(Be,{size:13})," Sem email"]})}),e.jsx("td",{"data-label":"Máquinas",children:Q(a.nif)}),e.jsxs("td",{className:"actions","data-label":"",children:[Q(a.nif)>0&&e.jsx("button",{className:"icon-btn secondary",onClick:()=>be(a),title:"Relatório executivo de frota (PDF)",children:e.jsx(ye,{size:16})}),x&&e.jsx("button",{className:"icon-btn secondary",onClick:()=>ze(a),title:"Editar",children:e.jsx(je,{size:16})}),M&&e.jsx("button",{className:"icon-btn danger",onClick:()=>{i(a.nif),k("Cliente eliminado.","info")},disabled:Q(a.nif)>0,title:Q(a.nif)>0?"Elimine as máquinas primeiro":"Eliminar",children:e.jsx(aa,{size:16})})]})]},a.nif))})]})}),u==="ficha"&&o&&e.jsx("div",{className:"modal-overlay modal-ficha-overlay",onClick:ge,children:e.jsxs("div",{className:"modal modal-ficha-cliente",onClick:a=>a.stopPropagation(),children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"0.5rem"},children:[e.jsxs("h2",{style:{margin:0},children:["Ficha do cliente — ",o.nome]}),_.length>0&&e.jsxs("button",{className:"btn secondary",style:{display:"flex",alignItems:"center",gap:"0.35rem",fontSize:"0.82rem"},onClick:()=>be(o),title:"Relatório executivo de frota (PDF)",children:[e.jsx(ye,{size:15})," Relatório de frota"]})]}),e.jsxs("div",{className:"ficha-cliente-dados",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"NIF:"})," ",o.nif," · ",e.jsx("strong",{children:"Morada:"})," ",o.morada||"—"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Localidade:"})," ",o.codigoPostal," ",o.localidade," · ",e.jsx("strong",{children:"Telefone:"})," ",o.telefone||"—"," · ",e.jsx("strong",{children:"Email:"})," ",o.email||"—"]})]}),_.length===0?e.jsxs("div",{className:"ficha-empty",children:[e.jsx("p",{className:"text-muted",children:"Este cliente ainda não tem máquinas registadas."}),z&&e.jsxs("button",{type:"button",className:"btn-add-maquina",onClick:()=>K({mode:"add",clienteNif:o.nif}),children:[e.jsx(ie,{size:18})," Adicionar máquina"]})]}):e.jsxs(e.Fragment,{children:[h==="categorias"&&e.jsxs("div",{className:"ficha-categorias",children:[e.jsx("h3",{children:"Categorias"}),e.jsx("div",{className:"categorias-grid",children:Ae.map(a=>{const t=_.filter(r=>$(r.subcategoriaId)?.categoriaId===a.id).length;return e.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>{D(a),E("subcategorias")},children:[e.jsx("h4",{children:a.nome}),e.jsxs("p",{children:[t," equipamento(s)"]}),e.jsx(oe,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},a.id)})})]}),h==="subcategorias"&&w&&e.jsxs("div",{className:"ficha-subcategorias",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{D(null),E("categorias")},children:[e.jsx(W,{size:16})," Categorias"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",w.nome]})]}),e.jsx("h3",{children:"Subcategorias"}),e.jsx("div",{className:"categorias-grid",children:Ie.map(a=>{const t=_.filter(r=>r.subcategoriaId===a.id).length;return e.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>{m(a),E("maquinas")},children:[e.jsx("h4",{children:a.nome}),e.jsxs("p",{children:[t," equipamento(s)"]}),e.jsx(oe,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},a.id)})})]}),h==="maquinas"&&P&&e.jsxs("div",{className:"ficha-maquinas-view",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{m(null),E("subcategorias")},children:[e.jsx(W,{size:16})," Subcategorias"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",P.nome]})]}),e.jsx("h3",{children:"Frota de máquinas"}),e.jsx("div",{className:"maquinas-ficha-lista",children:Fe.map(a=>e.jsxs("button",{type:"button",className:"maquina-ficha-card",onClick:()=>{G(a),E("maquina-detalhe")},children:[e.jsxs("strong",{children:[a.marca," ",a.modelo]}),e.jsxs("span",{className:"text-muted",children:[" — Nº Série: ",a.numeroSerie]}),e.jsx(oe,{size:18,style:{marginLeft:"auto",opacity:.6}})]},a.id))})]}),h==="maquina-detalhe"&&d&&(()=>{const a=f.find(l=>l.id===d.id)??d,t=a.documentos??[],r=l=>t.find(b=>b.tipo===l),j=l=>ve.find(b=>b.id===l)?.label??l;return e.jsxs("div",{className:"ficha-maquina-detalhe",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{G(null),E("maquinas")},children:[e.jsx(W,{size:16})," Frota"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",d.marca," ",d.modelo]})]}),e.jsxs("div",{className:"maquina-detalhe-header",children:[e.jsxs("h3",{children:[d.marca," ",d.modelo," — Nº Série: ",d.numeroSerie]}),e.jsx("div",{className:"maquina-detalhe-actions",children:I&&e.jsxs(e.Fragment,{children:[e.jsxs("button",{type:"button",className:"secondary",onClick:()=>{ee(null),K({mode:"edit",maquina:d})},children:[e.jsx(je,{size:16})," Editar"]}),e.jsxs("button",{type:"button",className:"secondary",onClick:()=>ee(d),children:[e.jsx(He,{size:16})," Documentação"]})]})})]}),e.jsx("h4",{children:"Documentação obrigatória"}),e.jsx("div",{className:"doc-table-wrapper",children:e.jsxs("table",{className:"data-table doc-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Documento"}),e.jsx("th",{children:"Existe"}),e.jsx("th",{children:"Ações"})]})}),e.jsx("tbody",{children:ve.map(l=>{const b=l.id==="outros"?t.filter(Oe=>Oe.tipo==="outros")[0]:r(l.id),X=!!b;return e.jsxs("tr",{children:[e.jsx("td",{"data-label":"Documento",children:j(l.id)}),e.jsx("td",{"data-label":"Existe",children:e.jsx("span",{className:X?"badge badge-sim":"badge badge-nao",children:X?"Sim":"Não"})}),e.jsx("td",{className:"doc-table-actions","data-label":"Ações",children:b?e.jsxs(e.Fragment,{children:[e.jsx("a",{href:qe(b.url),target:"_blank",rel:"noopener noreferrer",className:"icon-btn secondary",title:"Visualizar",children:e.jsx(Ze,{size:16})}),e.jsx("button",{type:"button",className:"icon-btn secondary",onClick:()=>me({documento:b,maquina:a}),title:"Enviar por email",children:e.jsx(ea,{size:16})})]}):e.jsx("span",{className:"text-muted",children:"—"})})]},l.id)})})]})}),e.jsx("h4",{children:"Histórico de manutenções"}),e.jsx("div",{className:"manutencoes-histórico",children:fe(d.id).length===0?e.jsx("p",{className:"text-muted",children:"Nenhuma manutenção registada."}):fe(d.id).map(l=>{const b=R(l.id);return e.jsxs("div",{className:"manutencao-item",children:[e.jsxs("button",{type:"button",className:"manutencao-item-btn",onClick:()=>Y({manutencao:l,relatorio:b,maquina:d,cliente:o}),children:[e.jsxs("div",{children:[e.jsx("strong",{children:$e(new Date(l.data),"d MMM yyyy",{locale:Se})}),e.jsxs("span",{className:"text-muted",children:[" — ",l.tecnico||b?.tecnico||"Não atribuído"]})]}),e.jsx("span",{className:`badge badge-${l.status}`,children:na[l.status]})]}),b?.assinadoPeloCliente&&e.jsx("button",{type:"button",className:"btn-enviar-email",onClick:X=>{X.stopPropagation(),ae({manutencao:l,relatorio:b,maquina:d,cliente:o})},children:"Enviar relatório por email"})]},l.id)})})]})})(),z&&e.jsxs("button",{type:"button",className:"btn-add-maquina",onClick:()=>K({mode:"add",clienteNif:o.nif}),style:{marginTop:"1rem"},children:[e.jsx(ie,{size:18})," Adicionar máquina"]})]}),e.jsx("div",{className:"form-actions",style:{marginTop:"1rem"},children:e.jsx("button",{type:"button",className:"secondary",onClick:ge,children:"Fechar"})})]})}),J&&e.jsx(Je,{isOpen:!0,onClose:()=>K(null),mode:J.mode,clienteNifLocked:J.clienteNif,maquina:J.maquina,onSave:(a,t)=>{t==="add"&&a&&Ue.includes(a.subcategoriaId)&&de(a)}}),e.jsx(Ke,{isOpen:!!re,onClose:()=>de(null),maquina:re,modoInicial:!0}),e.jsx(Ye,{isOpen:!!ce,onClose:()=>ee(null),maquina:ce}),q&&e.jsx("div",{className:"modal-overlay",onClick:()=>Y(null),children:e.jsxs("div",{className:"modal modal-relatorio modal-relatorio-ficha",onClick:a=>a.stopPropagation(),children:[e.jsxs("div",{className:"modal-relatorio-header",children:[e.jsx("h2",{children:"Relatório de manutenção"}),e.jsx("button",{type:"button",className:"secondary",onClick:()=>Y(null),children:"Fechar"})]}),e.jsx(Qe,{relatorio:q.relatorio,manutencao:q.manutencao,maquina:q.maquina,cliente:q.cliente,checklistItems:q.maquina?A(q.maquina.subcategoriaId,q.manutencao?.tipo||"periodica"):[]}),q.relatorio?.assinadoPeloCliente&&e.jsx("div",{className:"form-actions",style:{marginTop:"1rem"},children:e.jsx("button",{type:"button",onClick:()=>{Y(null),ae({manutencao:q.manutencao,relatorio:q.relatorio,maquina:q.maquina,cliente:q.cliente})},children:"Enviar relatório por email"})})]})}),B&&e.jsx(sa,{isOpen:!0,onClose:()=>ae(null),manutencao:B.manutencao,relatorio:B.relatorio,maquina:B.maquina,cliente:B.cliente}),te&&e.jsx(oa,{isOpen:!0,onClose:()=>me(null),documento:te.documento,maquina:te.maquina}),u&&u!=="ficha"&&e.jsx("div",{className:"modal-overlay",onClick:()=>n(null),children:e.jsxs("div",{className:"modal",onClick:a=>a.stopPropagation(),children:[e.jsx("h2",{children:u==="add"?"Novo cliente":"Editar cliente"}),ue&&e.jsx("p",{className:"form-erro",children:ue}),e.jsxs("form",{onSubmit:De,children:[e.jsxs("label",{children:["NIF ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{required:!0,value:T.nif,onChange:a=>O(t=>({...t,nif:a.target.value})),placeholder:"123456789",readOnly:u==="edit",className:u==="edit"?"readonly":""})]}),e.jsxs("label",{children:["Nome do Cliente ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{required:!0,value:T.nome,onChange:a=>O(t=>({...t,nome:a.target.value})),placeholder:"Razão social"})]}),e.jsxs("label",{children:["Morada",e.jsx("input",{value:T.morada,onChange:a=>O(t=>({...t,morada:a.target.value}))})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("label",{children:["Código Postal",e.jsx("input",{value:T.codigoPostal,onChange:a=>O(t=>({...t,codigoPostal:a.target.value}))})]}),e.jsxs("label",{children:["Localidade",e.jsx("input",{value:T.localidade,onChange:a=>O(t=>({...t,localidade:a.target.value}))})]})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("label",{children:["Telefone",e.jsx("input",{value:T.telefone,onChange:a=>O(t=>({...t,telefone:a.target.value}))})]}),e.jsxs("label",{children:["Email ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:T.email,onChange:a=>O(t=>({...t,email:a.target.value})),placeholder:"email@cliente.pt"})]})]}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:()=>n(null),children:"Cancelar"}),e.jsx("button",{type:"submit",children:u==="add"?"Adicionar":"Guardar"})]})]})]})})]})}export{ya as default};
