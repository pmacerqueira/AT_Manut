const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/jspdf.es.min-CrDbxoDP.js","assets/index-CbAXMX-_.js","assets/vendor-Bk0NZ5Or.js","assets/index-Rvtpichj.css"])))=>i.map(i=>d[i]);
import{a as T,f as y}from"./datasAzores-CBhl9I61.js";import{b as D,D as N,e as O}from"./emailConfig-C4nt6uh7.js";import{A as R,l as L,_ as M}from"./index-CbAXMX-_.js";const x={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",divisaoComercial:"Div. Comercial: Pico d'Agua Park, Rua 5, n.º13-15 · 9600-049 Pico da Pedra",sede:"Sede / Divisão Oficinas: Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",pais:"Açores — Portugal",web:"www.navel.pt"};function H(a,i,r,m,c=[],b={}){if(!a)return"";const{subcategoriaNome:u,ultimoEnvio:t,logoUrl:g}=b,o=g??"/manut/logo.png",s=O,C=a.dataCriacao?T(a.dataCriacao):"—",S=a.dataAssinatura?T(a.dataAssinatura):"—",F=i?.data?y(i.data,!0):"—",z=a.dataAssinatura?y(a.dataAssinatura,!0):a.dataCriacao?y(a.dataCriacao,!0):"—",e=r&&u?s(`${u} — ${r.marca} ${r.modelo} — Nº Série: ${r.numeroSerie}`):r?s(`${r.marca} ${r.modelo} — Nº Série: ${r.numeroSerie}`):"—",w=t?.data&&t?.destinatario?`Último envio por email: ${T(t.data)} para ${s(t.destinatario)}`:null,P=s(i?.tecnico||a?.tecnico||"—"),A=a.assinaturaDigital?D(a.assinaturaDigital):"",v=Math.ceil((c??[]).length/2),d=(c??[]).slice(0,v),h=(c??[]).slice(v),f=(p,l,$=0)=>{const E=a.checklistRespostas?.[p.id],k=E==="sim"?'<span class="badge-sim">S</span>':E==="nao"?'<span class="badge-nao">N</span>':'<span class="badge-nd">—</span>';return`<tr><td>${l+$+1}.</td><td>${s(p.texto)}</td><td>${k}</td></tr>`};let n=`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Manutenção — Navel</title>
<style>
/* ── Página A4, margens mínimas ── */
@page{size:A4 portrait;margin:8mm 11mm}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10.5px;line-height:1.38;color:#1a1a2e;background:#fff;padding:0}

/* ── Paleta ── */
:root{
  --azul:#1a4880;--azul-med:#2d6eb5;--azul-claro:#e8f2fa;
  --cinza:#f4f6f8;--borda:#c6d8ec;--texto:#1a1a2e;--muted:#5a6a7e;
  --verde:#16a34a;--vermelho:#dc2626;--acento:#f0a500;
}

/* ── Cabeçalho ── */
.rpt-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:8px;border-bottom:2.5px solid var(--azul)}
.rpt-logo img{max-height:42px;max-width:150px;object-fit:contain;display:block}
.rpt-logo-fallback{font-size:1.2em;font-weight:700;color:var(--azul)}
.rpt-empresa{text-align:right;font-size:9px;line-height:1.5;color:var(--muted)}
.rpt-empresa strong{display:block;font-size:10px;color:var(--azul);margin-bottom:1px}
.rpt-empresa a{color:var(--azul-med);text-decoration:none}

/* ── Título ── */
.rpt-titulo-bar{display:flex;align-items:center;justify-content:space-between;background:var(--azul);color:#fff;padding:5px 10px;margin:7px 0 0;border-radius:3px}
.rpt-titulo-bar h1{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
.rpt-num-wrap{text-align:right}
.rpt-num-label{font-size:8px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;display:block}
.rpt-num{font-size:14px;font-weight:800;letter-spacing:.04em;font-family:'Courier New',monospace}
.rpt-acento{height:2px;background:linear-gradient(90deg,var(--acento),var(--azul-med));margin-bottom:10px;border-radius:0 0 2px 2px}

/* ── Secções ── */
section{margin-bottom:9px}
.rpt-section-title{font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--azul-med);border-bottom:1px solid var(--borda);padding-bottom:2px;margin-bottom:5px}

/* ── Grid de dados (2 colunas) ── */
.rpt-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px 10px}
.rpt-field{padding:2px 0;border-bottom:1px solid #edf2f7}
.rpt-field:last-child{border-bottom:none}
.rpt-label{font-size:8.5px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);display:block;margin-bottom:0}
.rpt-value{font-size:10.5px;color:var(--texto)}
.rpt-field--full{grid-column:1/-1}

/* ── Checklist 2 colunas ── */
.checklist-2col{display:grid;grid-template-columns:1fr 1fr;gap:0 10px}
.checklist-table{width:100%;border-collapse:collapse;font-size:9.5px}
.checklist-table tr:nth-child(even){background:var(--cinza)}
.checklist-table td{padding:2.5px 4px 2.5px 0;border-bottom:1px solid #edf2f7;vertical-align:top}
.checklist-table td:first-child{width:1.6em;color:var(--muted);font-size:8.5px;padding-left:2px;white-space:nowrap}
.checklist-table td:last-child{width:22px;text-align:center;padding-right:2px}
.badge-sim{background:rgba(22,163,74,.15);color:var(--verde);padding:1px 4px;border-radius:8px;font-size:9px;font-weight:700}
.badge-nao{background:rgba(220,38,38,.12);color:var(--vermelho);padding:1px 4px;border-radius:8px;font-size:9px;font-weight:700}
.badge-nd{color:var(--muted);font-size:9px}

/* ── Notas ── */
.rpt-notas{background:var(--azul-claro);border-left:2.5px solid var(--azul-med);padding:5px 9px;border-radius:0 3px 3px 0;font-size:10px;color:var(--texto)}

/* ── Fotos ── */
.rpt-fotos-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:6px}
.rpt-fotos-grid img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:3px;border:1px solid var(--borda);display:block}

/* ── Assinatura + declaração lado a lado ── */
.rpt-bottom{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:start}
.rpt-assinatura-box{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px}
.rpt-assinatura-img img{max-width:180px;max-height:70px;border:1px solid var(--borda);border-radius:3px;margin-top:4px;background:#fff;display:block}
.rpt-declaracao{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px;font-size:8.5px;color:var(--muted);line-height:1.55}

/* ── Rodapé ── */
.rpt-footer{margin-top:8px;padding-top:6px;border-top:1px solid var(--borda);display:flex;justify-content:space-between;font-size:8.5px;color:var(--muted)}

/* ── Peças e consumíveis ── */
.pecas-table{width:100%;border-collapse:collapse;font-size:9.5px}
.pecas-table th{background:var(--azul);color:#fff;padding:3px 5px;text-align:left;font-size:8.5px;text-transform:uppercase;letter-spacing:.04em}
.pecas-table td{padding:2.5px 5px;border-bottom:1px solid #edf2f7;vertical-align:middle}
.pecas-table tr:nth-child(even) td{background:var(--cinza)}
.pecas-table .cell-pos{width:55px;color:var(--muted);font-family:monospace;font-size:8.5px}
.pecas-table .cell-code{width:130px;font-family:monospace;font-size:8.5px}
.pecas-table .cell-qty{width:45px;text-align:right}
.pecas-table .cell-un{width:40px}
</style>
</head>
<body>

<header class="rpt-header">
  <div class="rpt-logo">
    <img src="${o}" alt="Navel"
      onerror="this.parentNode.innerHTML='<span class=rpt-logo-fallback>Navel</span>'">
  </div>
  <div class="rpt-empresa">
    <strong>${s(x.nome)}</strong>
    ${s(x.divisaoComercial)}<br>
    ${s(x.sede)}<br>
    ${s(x.telefones)} &nbsp;|&nbsp; <a href="https://${x.web}">${x.web}</a><br>
    ${s(x.pais)}
  </div>
</header>

<div class="rpt-titulo-bar">
  <h1>Relatório de Manutenção</h1>
  <div class="rpt-num-wrap">
    <span class="rpt-num-label">Nº de Serviço</span>
    <span class="rpt-num">${s(a?.numeroRelatorio??i?.id??"—")}</span>
  </div>
</div>
<div class="rpt-acento"></div>

<!-- Dados -->
<section>
  <div class="rpt-section-title">Dados da manutenção</div>
  <div class="rpt-grid">
    <div class="rpt-field">
      <span class="rpt-label">Data agendada</span>
      <span class="rpt-value">${F}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Data de realização</span>
      <span class="rpt-value">${z}</span>
    </div>
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Equipamento</span>
      <span class="rpt-value">${e}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Cliente</span>
      <span class="rpt-value">${s(m?.nome??"—")}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Técnico responsável</span>
      <span class="rpt-value">${P}</span>
    </div>
    ${i?.horasTotais!=null||i?.horasServico!=null?`
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Contadores de horas</span>
      <span class="rpt-value">${i.horasTotais!=null?`Total: ${i.horasTotais} h`:""}${i.horasTotais!=null&&i.horasServico!=null?" · ":""}${i.horasServico!=null?`Serviço: ${i.horasServico} h`:""}</span>
    </div>`:""}
  </div>
</section>`;if(c?.length>0&&(n+=`
<section>
  <div class="rpt-section-title">Checklist de verificação</div>
  <div class="checklist-2col">
    <table class="checklist-table"><tbody>
      ${d.map((p,l)=>f(p,l,0)).join("")}
    </tbody></table>
    <table class="checklist-table"><tbody>
      ${h.map((p,l)=>f(p,l,v)).join("")}
    </tbody></table>
  </div>
</section>`),(a.notas||a.fotos?.length>0)&&(n+='<section><div class="rpt-section-title">Notas e fotografias</div>',a.notas&&(n+=`<div class="rpt-notas">${s(a.notas).replace(/\n/g,"<br>")}</div>`),a.fotos?.length>0&&(n+='<div class="rpt-fotos-grid">',a.fotos.forEach((p,l)=>{const $=D(p);$&&(n+=`<img src="${$}" alt="Fotografia ${l+1}">`)}),n+="</div>"),n+="</section>"),a.pecasUsadas?.length>0){const p=a.tipoManutKaeser?` — Manutenção Tipo ${a.tipoManutKaeser}`:"";n+=`
<section>
  <div class="rpt-section-title">Peças e consumíveis utilizados${p}</div>
  <table class="pecas-table">
    <thead>
      <tr><th>Pos.</th><th>Código artigo</th><th>Descrição</th><th>Qtd.</th><th>Un.</th></tr>
    </thead>
    <tbody>
      ${a.pecasUsadas.map(l=>`
      <tr>
        <td class="cell-pos">${s(l.posicao??"—")}</td>
        <td class="cell-code">${s(l.codigoArtigo)}</td>
        <td>${s(l.descricao)}</td>
        <td class="cell-qty">${l.quantidadeUsada??l.quantidade}</td>
        <td class="cell-un">${s(l.unidade)}</td>
      </tr>`).join("")}
    </tbody>
  </table>
</section>`}return n+=`
<!-- Assinatura + Declaração lado a lado -->
<section>
  <div class="rpt-section-title">Registo e assinatura</div>
  <div class="rpt-bottom">
    <div class="rpt-assinatura-box">
      <div class="rpt-grid">
        <div class="rpt-field">
          <span class="rpt-label">Data de criação</span>
          <span class="rpt-value">${C}</span>
        </div>
        <div class="rpt-field">
          <span class="rpt-label">Data de assinatura</span>
          <span class="rpt-value">${S}</span>
        </div>
        <div class="rpt-field rpt-field--full">
          <span class="rpt-label">Assinado pelo cliente</span>
          <span class="rpt-value">${s(a.nomeAssinante??"—")}</span>
        </div>
      </div>
      ${A?`
      <div class="rpt-assinatura-img">
        <span class="rpt-label" style="margin-top:5px;display:block">Assinatura manuscrita</span>
        <img src="${A}" alt="Assinatura do cliente">
      </div>`:""}
    </div>
    <div class="rpt-declaracao">${s(N)}</div>
  </div>
</section>

${w?`<p style="font-size:8.5px;color:#888;margin-bottom:5px">${w}</p>`:""}
<footer class="rpt-footer">
  <span>${s(R)}</span>
  <span>${s(x.web)} &nbsp;|&nbsp; ${s(x.telefones)}</span>
</footer>

</body></html>`,n}function j(){return window.innerWidth<=768||/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)}async function G({relatorio:a,manutencao:i,maquina:r,cliente:m,checklistItems:c=[],subcategoriaNome:b="",html:u}){if(j())try{const t=await I({relatorio:a,manutencao:i,maquina:r,cliente:m,checklistItems:c,subcategoriaNome:b}),g=URL.createObjectURL(t);window.open(g,"_blank")||alert("Permita pop-ups para visualizar o PDF."),setTimeout(()=>URL.revokeObjectURL(g),6e4)}catch(t){L.error("gerarPdfRelatorio","abrirPdfRelatorio","Erro ao gerar PDF em mobile",{msg:t?.message}),alert("Não foi possível gerar o PDF.")}else U(u)}function U(a){const i=window.open("","_blank");if(!i){alert("Permita pop-ups para obter o PDF.");return}i.document.write(a),i.document.close();const r=()=>{i.focus(),i.print(),i.onafterprint=()=>i.close()};i.addEventListener("load",()=>{const m=Array.from(i.document.images);if(m.length===0){r();return}let c=m.filter(u=>!u.complete).length;if(c===0){r();return}const b=()=>{c--,c<=0&&r()};m.forEach(u=>{u.complete||(u.addEventListener("load",b),u.addEventListener("error",b))}),setTimeout(r,3e3)})}async function I({relatorio:a,manutencao:i,maquina:r,cliente:m,checklistItems:c=[],subcategoriaNome:b=""}){const{jsPDF:u}=await M(async()=>{const{jsPDF:d}=await import("./jspdf.es.min-CrDbxoDP.js").then(h=>h.j);return{jsPDF:d}},__vite__mapDeps([0,1,2,3])),t=new u({orientation:"portrait",unit:"mm",format:"a4"}),g=210,o=14,s=g-2*o,C=i?.tipo==="montagem"?"Montagem":"Manutenção Periódica",S=a?.numeroRelatorio??"S/N",F=r?`${b?b+" — ":""}${r.marca} ${r.modelo} (Nº ${r.numeroSerie})`:"—",z=a?.dataAssinatura?new Date(a.dataAssinatura).toLocaleString("pt-PT",{dateStyle:"long",timeStyle:"short",timeZone:"Atlantic/Azores"}):"—";t.setFillColor(30,58,95),t.rect(0,0,g,26,"F"),t.setTextColor(255,255,255),t.setFontSize(13),t.setFont("helvetica","bold"),t.text("NAVEL-AÇORES",o,11),t.setFontSize(8),t.setFont("helvetica","normal"),t.text("296 205 290 / 296 630 120  •  geral@navel.pt  •  www.navel.pt",o,18),t.text("JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",o,23);let e=36;t.setTextColor(30,58,95),t.setFontSize(11),t.setFont("helvetica","bold"),t.text("Relatório de "+C,o,e),e+=7,t.setTextColor(13,110,253),t.setFontSize(18),t.setFont("helvetica","bold"),t.text(S,o,e),e+=5,t.setDrawColor(13,110,253),t.setLineWidth(.5),t.line(o,e,g-o,e),e+=7;const w=[["CLIENTE",m?.nome??"—"],["EQUIPAMENTO",F],["DATA DE EXECUÇÃO",z],["TÉCNICO",a?.tecnico??i?.tecnico??"—"],["ASSINADO POR",a?.nomeAssinante??"—"]];if(t.setFontSize(9),w.forEach(([d,h],f)=>{f%2===1&&(t.setFillColor(248,249,250),t.rect(o,e-4,s,7.5,"F")),t.setFont("helvetica","bold"),t.setTextColor(107,114,128),t.text(d,o+1,e),t.setFont("helvetica","normal"),t.setTextColor(17,24,39);const n=t.splitTextToSize(String(h),s-55);t.text(n,o+55,e),e+=n.length>1?n.length*5+2:7.5}),e+=3,t.setDrawColor(220,220,220),t.setLineWidth(.3),t.line(o,e,g-o,e),e+=7,c.length>0){e>260&&(t.addPage(),e=20),t.setFontSize(10),t.setFont("helvetica","bold"),t.setTextColor(30,58,95),t.text("CHECKLIST DE VERIFICAÇÃO",o,e),e+=6;const d=Object.values(a?.checklistRespostas??{}).filter(f=>f==="sim").length,h=Object.values(a?.checklistRespostas??{}).filter(f=>f==="nao").length;t.setFontSize(8),t.setFont("helvetica","normal"),t.setTextColor(107,114,128),t.text(`${d} conforme • ${h} não conforme • ${c.length} itens`,o,e),e+=5,t.setFontSize(8.5),c.forEach((f,n)=>{e>270&&(t.addPage(),e=20),n%2===0&&(t.setFillColor(249,250,251),t.rect(o,e-3.5,s,7,"F"));const p=a?.checklistRespostas?.[f.id],l=p==="sim"?"SIM":p==="nao"?"NÃO":"—",$=p==="sim"?[22,163,74]:p==="nao"?[220,38,38]:[107,114,128];t.setFont("helvetica","normal"),t.setTextColor(107,114,128),t.text(String(n+1)+".",o+1,e),t.setTextColor(55,65,81),t.text(f.texto,o+8,e,{maxWidth:s-22}),t.setFont("helvetica","bold"),t.setTextColor(...$),t.text(l,g-o-2,e,{align:"right"}),e+=7}),e+=4}if(a?.notas){e>240&&(t.addPage(),e=20),t.setFontSize(10),t.setFont("helvetica","bold"),t.setTextColor(30,58,95),t.text("NOTAS ADICIONAIS",o,e),e+=6,t.setFontSize(9),t.setFont("helvetica","normal"),t.setTextColor(55,65,81);const d=t.splitTextToSize(a.notas,s);t.text(d,o,e),e+=d.length*5+5}e>255&&(t.addPage(),e=20),t.setFillColor(240,253,244),t.setDrawColor(187,247,208),t.rect(o,e-4,s,16,"FD"),t.setFontSize(9),t.setFont("helvetica","bold"),t.setTextColor(22,163,74),t.text("✓ Relatório assinado digitalmente",o+3,e+1),t.setFontSize(8),t.setFont("helvetica","normal"),t.setTextColor(55,65,81);const P=a?.nomeAssinante?`Assinado por ${a.nomeAssinante} em ${z}. Assinatura manuscrita arquivada no sistema.`:`Assinado em ${z}. Assinatura manuscrita arquivada no sistema.`;t.text(P,o+3,e+8,{maxWidth:s-6}),e+=20;const A=(a?.fotos??[]).length;A>0&&(e>270&&(t.addPage(),e=20),t.setFontSize(8.5),t.setFont("helvetica","italic"),t.setTextColor(107,114,128),t.text(`📷 ${A} fotografia(s) documentadas no sistema Navel Manutencoes.`,o,e));const v=t.internal.getNumberOfPages();for(let d=1;d<=v;d++)t.setPage(d),t.setFillColor(30,58,95),t.rect(0,283,g,14,"F"),t.setTextColor(160,180,210),t.setFontSize(6.5),t.setFont("helvetica","normal"),t.text(R,g/2,286,{align:"center"}),t.setFontSize(5.5),t.text("Pico da Pedra & Ponta Delgada  •  296 205 290 / 296 630 120  •  www.navel.pt",g/2,291,{align:"center"}),v>1&&(t.setTextColor(200,210,230),t.text(`Página ${d}/${v}`,g-o,293,{align:"right"}));return t.output("blob")}export{G as a,U as i,H as r};
