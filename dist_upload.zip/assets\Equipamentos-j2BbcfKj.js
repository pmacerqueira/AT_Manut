import{c as Y,b as ha,a as xa,n as Na,j as a,X as Z,I as ya,K as ka,Q as U,o as Ca,A as Sa,i as wa,u as za,f as na}from"./index-DJNb0I1h.js";import{r as p,g as Ea,d as Aa,u as qa,i as Pa}from"./vendor-Bk0NZ5Or.js";import{F as oa,M as $a,D as Ma}from"./DocumentacaoModal-DnKduXv4.js";import{E as Da}from"./ExecutarManutencaoModal-BUF597pm.js";import{D as Ta}from"./download-KlU-MdNR.js";import{C as Ia}from"./chevron-down-u3QelWAi.js";import{T as J}from"./trash-2-DIQrgkxa.js";import{P as La,a as ra}from"./plus-DEQufh-b.js";import{r as Ra}from"./vendor-qr-DgLtAz-0.js";import{f as B,a as Fa}from"./datasAzores-CBhl9I61.js";import{b as Oa,e as _a}from"./emailConfig-D4E5Iu8I.js";import{i as Ha}from"./gerarPdfRelatorio-DvYDwJj7.js";import{A as la}from"./arrow-left-BmxozOpK.js";import{P as Qa}from"./emailService-B5zvk-g4.js";import{F as ca}from"./file-text-CrZ3Pcwy.js";import{i as Va}from"./isBefore-CyjzPuBp.js";import{f as da}from"./format-BvtC0E8y.js";import{p as pa}from"./pt-BAJJYN30.js";import"./addDays-EA-Jdp2P.js";import"./alertasConfig-BYiXAfoY.js";const Ba=[["path",{d:"M12 22v-9",key:"x3hkom"}],["path",{d:"M15.17 2.21a1.67 1.67 0 0 1 1.63 0L21 4.57a1.93 1.93 0 0 1 0 3.36L8.82 14.79a1.655 1.655 0 0 1-1.64 0L3 12.43a1.93 1.93 0 0 1 0-3.36z",key:"2ntwy6"}],["path",{d:"M20 13v3.87a2.06 2.06 0 0 1-1.11 1.83l-6 3.08a1.93 1.93 0 0 1-1.78 0l-6-3.08A2.06 2.06 0 0 1 4 16.87V13",key:"1pmm1c"}],["path",{d:"M21 12.43a1.93 1.93 0 0 0 0-3.36L8.83 2.2a1.64 1.64 0 0 0-1.63 0L3 4.57a1.93 1.93 0 0 0 0 3.36l12.18 6.86a1.636 1.636 0 0 0 1.63 0z",key:"12ttoo"}]],W=Y("package-open",Ba);const Ka=[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]],Ua=Y("printer",Ka);const Ga=[["path",{d:"M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",key:"1c8476"}],["path",{d:"M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7",key:"1ydtos"}],["path",{d:"M7 3v4a1 1 0 0 0 1 1h7",key:"t51u73"}]],Xa=Y("save",Ga),ma=[{id:"A",label:"Tipo A",hint:"3.000h / 1 ano"},{id:"B",label:"Tipo B",hint:"6.000h"},{id:"C",label:"Tipo C",hint:"12.000h"},{id:"D",label:"Tipo D",hint:"36.000h"},{id:"periodica",label:"Periódica",hint:"Manutenção periódica standard"}],ua=["PÇ","TER","L","KG","M","UN"],K={posicao:"",codigoArtigo:"",descricao:"",quantidade:1,unidade:"PÇ"};function Za({isOpen:c,onClose:m,maquina:t}){const{getPecasPlanoByMaquina:k,addPecaPlano:M,addPecasPlanoLote:b,updatePecaPlano:D,removePecaPlano:r,removePecasPlanoByMaquina:f,getSubcategoria:A}=ha(),{showToast:C}=xa(),[d,T]=p.useState("A"),[v,j]=p.useState(K),[E,N]=p.useState(null),[x,y]=p.useState(K),[w,q]=p.useState(!1),I=t?A(t.subcategoriaId):null,S=t&&Na.includes(t.subcategoriaId),L=S?ma:ma.filter(e=>e.id==="periodica"),P=p.useMemo(()=>t?k(t.id,d):[],[t,d,k]),$=p.useMemo(()=>t?k(t.id).length:0,[t,k]);if(!c||!t)return null;const n=e=>{if(e.preventDefault(),!v.codigoArtigo.trim()||!v.descricao.trim()){C("Código de artigo e descrição são obrigatórios.","warning");return}M({...v,maquinaId:t.id,tipoManut:d}),j(K),C("Peça adicionada ao plano.","success")},h=e=>{if(!x.codigoArtigo.trim()||!x.descricao.trim()){C("Código de artigo e descrição são obrigatórios.","warning");return}D(e,x),N(null),C("Peça actualizada.","success")},z=()=>{const e=ka.filter(u=>u.tipoManut===d).map(u=>({...u,maquinaId:t.id}));if(e.length===0){C("Não existe plano de referência KAESER ASK 28T para o tipo "+d+".","info");return}k(t.id,d).forEach(u=>r(u.id)),b(e),C(`${e.length} peças importadas do template KAESER ASK 28T (Tipo ${d}).`,"success")},R=()=>{P.forEach(e=>r(e.id)),q(!1),C(`Plano Tipo ${d} limpo.`,"success")},F=()=>{f(t.id),q(!1),C("Todos os planos desta máquina foram eliminados.","success")};return a.jsx("div",{className:"modal-overlay",onClick:m,children:a.jsxs("div",{className:"modal modal-pecas-plano",onClick:e=>e.stopPropagation(),children:[a.jsxs("div",{className:"modal-pecas-header",children:[a.jsxs("div",{children:[a.jsxs("h2",{children:[a.jsx(W,{size:20})," Plano de peças e consumíveis"]}),a.jsxs("p",{className:"modal-pecas-sub",children:[t.marca," ",t.modelo," — Nº Série: ",a.jsx("strong",{children:t.numeroSerie}),I&&a.jsxs(a.Fragment,{children:["  ·  ",I.nome]})]})]}),a.jsx("button",{className:"icon-btn",onClick:m,title:"Fechar",children:a.jsx(Z,{size:20})})]}),a.jsxs("div",{className:"modal-pecas-tabs",children:[L.map(e=>{const l=t?k(t.id,e.id).length:0;return a.jsxs("button",{className:`tab-tipo ${d===e.id?"active":""}`,onClick:()=>{T(e.id),N(null),j(K)},children:[a.jsx("span",{className:"tab-tipo-label",children:e.label}),a.jsx("span",{className:"tab-tipo-hint",children:e.hint}),l>0&&a.jsx("span",{className:"tab-tipo-count",children:l})]},e.id)}),a.jsx("span",{className:"tab-total",children:$>0?`${$} peças no total`:"Sem peças configuradas"})]}),S&&d!=="periodica"&&a.jsxs("div",{className:"modal-pecas-import",children:[a.jsxs("span",{className:"import-hint",children:["Template de referência disponível: ",a.jsx("strong",{children:"KAESER ASK 28T"})," — ",ya[d]?.label]}),a.jsxs("button",{type:"button",className:"btn btn-sm secondary",onClick:z,children:[a.jsx(Ta,{size:14})," Importar template"]})]}),a.jsx("div",{className:"modal-pecas-table-wrap",children:P.length===0?a.jsxs("p",{className:"modal-pecas-vazio",children:["Sem peças configuradas para ",a.jsxs("strong",{children:["Tipo ",d==="periodica"?"Periódica":d]}),".",S&&d!=="periodica"&&' Use "Importar template" para pré-preencher.']}):a.jsxs("table",{className:"tabela-pecas",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Pos."}),a.jsx("th",{children:"Código artigo"}),a.jsx("th",{children:"Descrição"}),a.jsx("th",{children:"Qtd"}),a.jsx("th",{children:"Un."}),a.jsx("th",{})]})}),a.jsx("tbody",{children:P.map(e=>E===e.id?a.jsxs("tr",{className:"row-edit",children:[a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:x.posicao,onChange:l=>y(u=>({...u,posicao:l.target.value})),placeholder:"Ex: 0512",style:{width:"60px"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:x.codigoArtigo,onChange:l=>y(u=>({...u,codigoArtigo:l.target.value})),required:!0,style:{width:"130px"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:x.descricao,onChange:l=>y(u=>({...u,descricao:l.target.value})),required:!0,style:{width:"100%"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",type:"number",min:.01,step:.01,value:x.quantidade,onChange:l=>y(u=>({...u,quantidade:parseFloat(l.target.value)||1})),style:{width:"60px"}})}),a.jsx("td",{children:a.jsx("select",{className:"input-sm",value:x.unidade,onChange:l=>y(u=>({...u,unidade:l.target.value})),children:ua.map(l=>a.jsx("option",{children:l},l))})}),a.jsxs("td",{className:"cell-actions",children:[a.jsx("button",{className:"icon-btn success",onClick:()=>h(e.id),title:"Guardar",children:a.jsx(Xa,{size:14})}),a.jsx("button",{className:"icon-btn",onClick:()=>N(null),title:"Cancelar",children:a.jsx(Z,{size:14})})]})]},e.id):a.jsxs("tr",{children:[a.jsx("td",{className:"cell-pos",children:e.posicao||"—"}),a.jsx("td",{className:"cell-code",children:e.codigoArtigo}),a.jsx("td",{children:e.descricao}),a.jsx("td",{className:"cell-qty",children:e.quantidade}),a.jsx("td",{className:"cell-un",children:e.unidade}),a.jsxs("td",{className:"cell-actions",children:[a.jsx("button",{className:"icon-btn secondary",onClick:()=>{N(e.id),y({posicao:e.posicao||"",codigoArtigo:e.codigoArtigo,descricao:e.descricao,quantidade:e.quantidade,unidade:e.unidade})},title:"Editar",children:a.jsx(Ia,{size:14})}),a.jsx("button",{className:"icon-btn danger",onClick:()=>r(e.id),title:"Remover",children:a.jsx(J,{size:14})})]})]},e.id))})]})}),a.jsxs("form",{className:"modal-pecas-add-row",onSubmit:n,children:[a.jsx("input",{className:"input-sm",placeholder:"Posição",value:v.posicao,onChange:e=>j(l=>({...l,posicao:e.target.value})),style:{width:"65px",flexShrink:0}}),a.jsx("input",{className:"input-sm",placeholder:"Código artigo *",value:v.codigoArtigo,onChange:e=>j(l=>({...l,codigoArtigo:e.target.value})),style:{width:"135px",flexShrink:0}}),a.jsx("input",{className:"input-sm",placeholder:"Descrição *",value:v.descricao,onChange:e=>j(l=>({...l,descricao:e.target.value})),style:{flex:1}}),a.jsx("input",{className:"input-sm",type:"number",min:.01,step:.01,value:v.quantidade,onChange:e=>j(l=>({...l,quantidade:parseFloat(e.target.value)||1})),style:{width:"60px",flexShrink:0}}),a.jsx("select",{className:"input-sm",value:v.unidade,onChange:e=>j(l=>({...l,unidade:e.target.value})),style:{width:"70px",flexShrink:0},children:ua.map(e=>a.jsx("option",{children:e},e))}),a.jsxs("button",{type:"submit",className:"btn btn-sm primary",style:{flexShrink:0},children:[a.jsx(La,{size:14})," Adicionar"]})]}),a.jsx("div",{className:"modal-pecas-footer",children:w?a.jsxs("div",{className:"confirmar-limpar",children:[a.jsx("span",{children:"Eliminar:"}),a.jsxs("button",{className:"btn btn-sm danger",onClick:R,children:["Só Tipo ",d==="periodica"?"Periódica":d," (",P.length,")"]}),a.jsxs("button",{className:"btn btn-sm danger",onClick:F,children:["Toda a máquina (",$,")"]}),a.jsx("button",{className:"btn btn-sm",onClick:()=>q(!1),children:"Cancelar"})]}):a.jsxs(a.Fragment,{children:[$>0&&a.jsxs("button",{className:"btn btn-sm btn-outline-muted",onClick:()=>q(!0),children:[a.jsx(J,{size:13})," Limpar plano…"]}),a.jsx("button",{className:"btn secondary",onClick:m,style:{marginLeft:"auto"},children:"Fechar"})]})})]})})}var Ja=Ra();const Wa=Ea(Ja);function Ya({isOpen:c,onClose:m,maquina:t,subcategoria:k,cliente:M}){const[b,D]=p.useState(null);return p.useEffect(()=>{if(!c||!t)return;const f=`${window.location.origin}/manut/equipamentos?maquina=${encodeURIComponent(t.id)}`;Wa.toDataURL(f,{width:400,margin:1,color:{dark:"#0d2340",light:"#ffffff"},errorCorrectionLevel:"H"}).then(D).catch(()=>D(null))},[c,t]),p.useEffect(()=>{if(!c)return;const f=A=>{A.key==="Escape"&&m()};return document.addEventListener("keydown",f),()=>document.removeEventListener("keydown",f)},[c,m]),!c||!t?null:a.jsx("div",{className:"modal-overlay qr-modal-overlay",onClick:m,children:a.jsxs("div",{className:"modal qr-modal",onClick:f=>f.stopPropagation(),role:"dialog","aria-modal":"true","aria-label":"Etiqueta QR",children:[a.jsxs("div",{className:"modal-header qr-modal-header no-print",children:[a.jsxs("div",{style:{display:"flex",alignItems:"center",gap:"0.5rem"},children:[a.jsx(U,{size:20}),a.jsxs("h2",{style:{margin:0,fontSize:"1rem"},children:["Etiqueta QR — ",t.marca," ",t.modelo]})]}),a.jsx("button",{type:"button",className:"icon-btn secondary",onClick:m,"aria-label":"Fechar",children:a.jsx(Z,{size:20})})]}),a.jsxs("div",{className:"qr-modal-body",children:[a.jsxs("p",{className:"no-print qr-modal-hint",children:["Pré-visualização da etiqueta ",a.jsx("strong",{children:"90 × 50 mm"}),". Imprima, recorte e cole na máquina. A câmara do telemóvel lê o QR e abre directamente a ficha da máquina."]}),a.jsxs("div",{className:"qr-etiqueta",id:"qr-etiqueta-print",children:[a.jsxs("div",{className:"qr-etiqueta-left",children:[a.jsx("div",{className:"qr-etiqueta-logo-wrap",children:a.jsx("img",{src:"/manut/logo-navel.png",alt:"Navel",className:"qr-etiqueta-logo",onError:f=>{f.currentTarget.style.display="none"}})}),a.jsx("div",{className:"qr-etiqueta-sep"}),k?.nome&&a.jsx("div",{className:"qr-etiqueta-type",children:k.nome}),a.jsxs("div",{className:"qr-etiqueta-machine",children:[a.jsxs("div",{className:"qr-etiqueta-nome",children:[t.marca," ",t.modelo]}),a.jsxs("div",{className:"qr-etiqueta-serie",children:["S/N: ",a.jsx("strong",{children:t.numeroSerie||"—"})]}),M&&a.jsx("div",{className:"qr-etiqueta-cliente",children:M.nome}),t.localizacao&&a.jsx("div",{className:"qr-etiqueta-local",children:t.localizacao})]})]}),a.jsxs("div",{className:"qr-etiqueta-right",children:[b?a.jsx("img",{src:b,alt:"QR Code",className:"qr-etiqueta-img"}):a.jsxs("div",{className:"qr-etiqueta-loading",children:[a.jsx(U,{size:28,strokeWidth:1.2}),a.jsx("span",{children:"A gerar…"})]}),a.jsx("div",{className:"qr-etiqueta-scan-hint",children:"Digitalizar"})]}),a.jsxs("div",{className:"qr-etiqueta-footer",children:["Navel-Açores, Lda  ·  AT_Manut v",Ca]})]}),a.jsxs("div",{className:"qr-modal-actions no-print",children:[a.jsx("button",{type:"button",className:"btn secondary",onClick:m,children:"Fechar"}),a.jsxs("button",{type:"button",className:"btn primary",onClick:()=>window.print(),disabled:!b,children:[a.jsx(Ua,{size:16})," Imprimir etiqueta"]})]})]})]})})}const H={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",divisao:"Div. Comercial: Pico d'Água Park, Rua 5, n.º13-15 · 9600-049 Pico da Pedra",sede:"Sede / Div. Oficinas: Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",tel:"Tel: 296 205 290 / 296 630 120",web:"www.navel.pt"};function ae({maquina:c,cliente:m,subcategoria:t,categoria:k,manutencoes:M=[],relatorios:b=[],logoUrl:D}){const r=_a,f=D??"/manut/logo-navel.png",A=new Date,C=A.toLocaleString("pt-PT",{dateStyle:"long",timeStyle:"short",timeZone:"Atlantic/Azores"}),d=[...M].sort((n,h)=>h.data.localeCompare(n.data)),T=d.length,v=d.filter(n=>n.status==="concluida"),j=d.filter(n=>n.status!=="concluida"),E=j.filter(n=>new Date(n.data)<A),N=j.filter(n=>new Date(n.data)>=A),x=v[0],y=N.reduce((n,h)=>!n||h.data<n.data?h:n,null),w=x?B(x.data,!0):"—",q=y?B(y.data,!0):"—",I=c.proximaManut?B(c.proximaManut,!0):q,S=v.map(n=>b.find(h=>h.manutencaoId===n.id)).find(n=>n?.assinaturaDigital),L=S?.assinaturaDigital?Oa(S.assinaturaDigital):null,P=t?`${t.nome} — ${c.marca} ${c.modelo}`:`${c.marca} ${c.modelo}`,$=(n,h)=>{const z=b.find(O=>O.manutencaoId===n.id),R=n.tipo==="montagem"?"Montagem":"Periódica",F=B(n.data,!0),e=r(z?.tecnico??n.tecnico??"—"),l=z?.nomeAssinante?r(z.nomeAssinante):"—",u=z?.notas?r(z.notas.length>90?z.notas.slice(0,90)+"…":z.notas):"—",Q=n.status==="concluida"?'<span class="badge-ok">Executada</span>':new Date(n.data)<A?'<span class="badge-err">Em atraso</span>':'<span class="badge-pend">Agendada</span>';return`<tr${h%2===1?' class="row-alt"':""}>
      <td class="td-c">${h+1}</td>
      <td>${F}</td>
      <td class="td-c">${R}</td>
      <td class="td-c">${Q}</td>
      <td>${e}</td>
      <td>${l}</td>
      <td class="td-notes">${u}</td>
    </tr>`};return`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Histórico de Manutenção — ${r(c.marca)} ${r(c.modelo)}</title>
<style>
@page { size: A4 portrait; margin: 10mm 13mm; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 10.5px; line-height: 1.4; color: #1a1a2e; background: #fff; }

:root {
  --azul:#1a4880; --azul-med:#2d6eb5; --azul-claro:#e8f2fa;
  --cinza:#f4f6f8; --borda:#c6d8ec; --texto:#1a1a2e; --muted:#5a6a7e;
  --verde:#16a34a; --vermelho:#dc2626; --laranja:#d97706; --acento:#f0a500;
}

/* ── Cabeçalho ── */
.rpt-header { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; padding-bottom:8px; border-bottom:2.5px solid var(--azul); }
.rpt-logo img { max-height:38px; max-width:140px; object-fit:contain; display:block; }
.rpt-empresa { text-align:right; font-size:8.5px; line-height:1.55; color:var(--muted); }
.rpt-empresa strong { display:block; font-size:9.5px; color:var(--azul); margin-bottom:1px; }

/* ── Barra de título ── */
.rpt-titulo-bar { display:flex; align-items:center; justify-content:space-between; background:var(--azul); color:#fff; padding:5px 10px; margin:7px 0 0; border-radius:3px; }
.rpt-titulo-bar h1 { font-size:11px; font-weight:700; letter-spacing:.07em; text-transform:uppercase; }
.rpt-gerado { font-size:7.5px; opacity:.75; }
.rpt-acento { height:2px; background:linear-gradient(90deg,var(--acento),var(--azul-med)); margin-bottom:11px; border-radius:0 0 2px 2px; }

/* ── Ficha do equipamento ── */
.section-title { font-size:8.5px; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:var(--azul-med); border-bottom:1px solid var(--borda); padding-bottom:3px; margin:0 0 6px; }
.ficha-grid { display:grid; grid-template-columns:1fr 1fr; gap:0; border:1px solid var(--borda); border-radius:4px; overflow:hidden; margin-bottom:10px; }
.ficha-col { padding:8px 10px; }
.ficha-col + .ficha-col { border-left:1px solid var(--borda); background:var(--cinza); }
.ficha-field { margin-bottom:5px; }
.ficha-field:last-child { margin-bottom:0; }
.ficha-label { display:block; font-size:7.5px; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--muted); margin-bottom:1px; }
.ficha-value { font-size:10.5px; color:var(--texto); font-weight:500; }
.ficha-value-lg { font-size:13px; font-weight:700; color:var(--azul); }

/* ── Estatísticas ── */
.stats-row { display:grid; grid-template-columns:repeat(5,1fr); gap:6px; margin-bottom:12px; }
.stat-box { border:1px solid var(--borda); border-radius:4px; padding:6px 8px; text-align:center; background:var(--cinza); }
.stat-num { display:block; font-size:18px; font-weight:800; line-height:1.1; color:var(--azul); }
.stat-num.red { color:var(--vermelho); }
.stat-num.green { color:var(--verde); }
.stat-num.orange { color:var(--laranja); }
.stat-lbl { display:block; font-size:7.5px; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; margin-top:2px; }

/* ── Tabela histórico ── */
.hist-table { width:100%; border-collapse:collapse; font-size:9px; margin-bottom:14px; page-break-inside:auto; }
.hist-table th { background:var(--azul); color:#fff; padding:4px 6px; text-align:left; font-size:8px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; white-space:nowrap; }
.hist-table td { padding:4px 6px; border-bottom:1px solid #edf2f7; vertical-align:top; }
.hist-table tr.row-alt td { background:var(--cinza); }
.td-c { text-align:center; }
.td-notes { font-size:8.5px; color:var(--muted); max-width:140px; }

/* ── Badges ── */
.badge-ok   { background:rgba(22,163,74,.14);  color:var(--verde);    padding:1px 5px; border-radius:8px; font-size:8px; font-weight:700; white-space:nowrap; }
.badge-err  { background:rgba(220,38,38,.12);  color:var(--vermelho); padding:1px 5px; border-radius:8px; font-size:8px; font-weight:700; white-space:nowrap; }
.badge-pend { background:rgba(217,119,6,.12);  color:var(--laranja);  padding:1px 5px; border-radius:8px; font-size:8px; font-weight:700; white-space:nowrap; }

/* ── Assinatura ── */
.assin-box { border:1px solid var(--borda); border-radius:4px; padding:8px 10px; background:var(--cinza); display:inline-block; margin-bottom:12px; }
.assin-box img { display:block; max-width:200px; max-height:80px; margin-top:5px; border:1px solid var(--borda); background:#fff; border-radius:3px; }
.assin-meta { font-size:8.5px; color:var(--muted); margin-top:3px; }

/* ── Rodapé ── */
.rpt-footer { margin-top:10px; padding-top:6px; border-top:1px solid var(--borda); display:flex; justify-content:space-between; font-size:8.5px; color:var(--muted); }

@media print {
  .hist-table tr { page-break-inside:avoid; }
  .hist-table thead { display:table-header-group; }
}
</style>
</head>
<body>

<header class="rpt-header">
  <div class="rpt-logo">
    <img src="${f}" alt="Navel"
      onerror="this.parentNode.innerHTML='<strong style=color:#1a4880;font-size:14px>NAVEL</strong>'">
  </div>
  <div class="rpt-empresa">
    <strong>${r(H.nome)}</strong>
    ${r(H.divisao)}<br>
    ${r(H.sede)}<br>
    ${r(H.tel)} &nbsp;|&nbsp; ${r(H.web)}
  </div>
</header>

<div class="rpt-titulo-bar">
  <h1>Histórico Completo de Manutenção</h1>
  <span class="rpt-gerado">Gerado em ${C}</span>
</div>
<div class="rpt-acento"></div>

<div class="section-title">Ficha do equipamento</div>
<div class="ficha-grid">
  <div class="ficha-col">
    <div class="ficha-field">
      <span class="ficha-label">Equipamento</span>
      <span class="ficha-value ficha-value-lg">${r(c.marca)} ${r(c.modelo)}</span>
    </div>
    <div class="ficha-field">
      <span class="ficha-label">Nº de Série</span>
      <span class="ficha-value">${r(c.numeroSerie||"—")}</span>
    </div>
    ${t?`<div class="ficha-field">
      <span class="ficha-label">Tipo / Subcategoria</span>
      <span class="ficha-value">${r(t.nome)}${k?` &mdash; ${r(k.nome)}`:""}</span>
    </div>`:""}
    ${c.localizacao?`<div class="ficha-field">
      <span class="ficha-label">Localização</span>
      <span class="ficha-value">${r(c.localizacao)}</span>
    </div>`:""}
  </div>
  <div class="ficha-col">
    <div class="ficha-field">
      <span class="ficha-label">Cliente</span>
      <span class="ficha-value ficha-value-lg">${r(m?.nome??"—")}</span>
    </div>
    ${m?.nif?`<div class="ficha-field">
      <span class="ficha-label">NIF</span>
      <span class="ficha-value">${r(m.nif)}</span>
    </div>`:""}
    ${m?.morada?`<div class="ficha-field">
      <span class="ficha-label">Morada</span>
      <span class="ficha-value">${r(m.morada)}</span>
    </div>`:""}
    <div class="ficha-field">
      <span class="ficha-label">Próxima manutenção</span>
      <span class="ficha-value">${I}</span>
    </div>
  </div>
</div>

<div class="section-title">Estatísticas globais</div>
<div class="stats-row">
  <div class="stat-box">
    <span class="stat-num">${T}</span>
    <span class="stat-lbl">Total</span>
  </div>
  <div class="stat-box">
    <span class="stat-num green">${v.length}</span>
    <span class="stat-lbl">Executadas</span>
  </div>
  <div class="stat-box">
    <span class="stat-num orange">${N.length}</span>
    <span class="stat-lbl">Agendadas</span>
  </div>
  <div class="stat-box">
    <span class="stat-num${E.length>0?" red":""}">${E.length}</span>
    <span class="stat-lbl">Em atraso</span>
  </div>
  <div class="stat-box">
    <span class="stat-num" style="font-size:${w.length>8?"9":"13"}px;padding-top:${w.length>8?"5":"2"}px">${w}</span>
    <span class="stat-lbl">Última execução</span>
  </div>
</div>

<div class="section-title">
  Registo histórico — ${T} intervenç${T===1?"ão":"ões"} (mais recente primeiro)
</div>
${T===0?'<p style="color:#5a6a7e;font-size:10px;margin-bottom:12px;font-style:italic">Nenhuma manutenção registada para este equipamento.</p>':`<table class="hist-table">
  <thead>
    <tr>
      <th class="td-c" style="width:22px">#</th>
      <th style="width:62px">Data</th>
      <th class="td-c" style="width:58px">Tipo</th>
      <th class="td-c" style="width:68px">Estado</th>
      <th style="width:80px">Técnico</th>
      <th style="width:90px">Assinado por</th>
      <th>Observações</th>
    </tr>
  </thead>
  <tbody>
    ${d.map((n,h)=>$(n,h)).join(`
    `)}
  </tbody>
</table>`}

${L?`<div class="section-title">Última assinatura registada</div>
<div class="assin-box">
  <span class="ficha-label">Assinatura manuscrita do cliente</span>
  <img src="${L}" alt="Assinatura do cliente">
  ${S?.nomeAssinante?`<div class="assin-meta">Assinado por: <strong>${r(S.nomeAssinante)}</strong>${S.dataAssinatura?` &nbsp;&mdash;&nbsp; ${Fa(S.dataAssinatura)}`:""}</div>`:""}
</div>`:""}

<footer class="rpt-footer">
  <span>${r(Sa)}</span>
  <span>${r(P)} &nbsp;&middot;&nbsp; S/N: ${r(c.numeroSerie||"—")}</span>
</footer>

</body>
</html>`}function ye(){const{clientes:c,categorias:m,maquinas:t,INTERVALOS:k,getSubcategoriasByCategoria:M,getSubcategoria:b,manutencoes:D,relatorios:r,removeMaquina:f}=ha(),{canDelete:A,isAdmin:C}=wa(),{showToast:d}=xa(),{showGlobalLoading:T,hideGlobalLoading:v}=za(),[j,E]=p.useState("categorias"),[N,x]=p.useState(null),[y,w]=p.useState(null),[q,I]=p.useState(null),[S,L]=p.useState(null),[P,$]=p.useState(null),[n,h]=p.useState(null),[z,R]=p.useState(null),[F,e]=p.useState(null),l=Aa(),u=qa(),[Q,G]=Pa(),O=Q.get("filter")==="atraso";p.useEffect(()=>{const s=Q.get("maquina");if(!s)return;const i=t.find(g=>g.id===s);if(!i)return;const o=b(i.subcategoriaId);if(o){const g=m.find(_=>_.id===o.categoriaId);g&&(x(g),w(o),E("maquinas"))}G(g=>(g.delete("maquina"),g),{replace:!0})},[t]),p.useEffect(()=>{const s=u.state?.highlightId;if(!s)return;const i=t.find(g=>g.id===s);if(!i)return;const o=b(i.subcategoriaId);if(o){const g=m.find(_=>_.id===o.categoriaId);g&&(x(g),w(o),E("maquinas"))}},[u.state]);const V=s=>c.find(i=>i.nif===s),aa=s=>{e(s.id),T();try{const i=b(s.subcategoriaId),o=i?m.find(X=>X.id===i.categoriaId):null,g=V(s.clienteNif),_=D.filter(X=>X.maquinaId===s.id),ja=ae({maquina:s,cliente:g,subcategoria:i,categoria:o,manutencoes:_,relatorios:r});Ha(ja)}catch{d("Erro ao gerar histórico PDF.","error")}finally{v(),e(null)}},ea=t.filter(s=>Va(new Date(s.proximaManut),new Date)),ga=s=>{x(s),w(null),E("subcategorias")},ba=s=>{w(s),E("maquinas")},sa=()=>{E("categorias"),x(null),w(null)},fa=()=>{E("subcategorias"),w(null)},va=N?M(N.id):[],ta=(y?t.filter(s=>s.subcategoriaId===y.id):[]).reduce((s,i)=>{const o=V(i.clienteNif)?.nome??"Sem cliente";return s[o]||(s[o]=[]),s[o].push(i),s},{}),ia=Object.keys(ta).sort((s,i)=>s.localeCompare(i));return a.jsxs("div",{className:"page",children:[a.jsxs("div",{className:"page-header",children:[a.jsxs("div",{children:[a.jsxs("button",{type:"button",className:"btn-back",onClick:()=>l(-1),children:[a.jsx(la,{size:20}),"Voltar atrás"]}),a.jsx("h1",{children:"Equipamentos"}),a.jsx("p",{className:"page-sub",children:O?"Equipamentos em atraso de manutenção":"Navegação por categorias e subcategorias"})]}),O&&a.jsx("button",{type:"button",className:"secondary",onClick:()=>G({}),children:"Ver todos"})]}),O?a.jsx("div",{className:"table-card card",children:ea.length===0?a.jsx("p",{className:"text-muted",style:{padding:"1.5rem"},children:"Nenhum equipamento em atraso de manutenção."}):a.jsx("div",{className:"maquinas-por-cliente-lista",children:Object.entries(ea.reduce((s,i)=>{const o=V(i.clienteNif)?.nome??"Sem cliente";return s[o]||(s[o]=[]),s[o].push(i),s},{})).sort((s,i)=>s[0].localeCompare(i[0])).map(([s,i])=>a.jsxs("div",{className:"maquinas-por-cliente",children:[a.jsx("h4",{children:s}),i.map(o=>{const g=b(o.subcategoriaId);return a.jsxs("div",{className:"maquina-row",style:{borderLeft:"3px solid var(--color-danger)"},children:[a.jsxs("div",{className:"maquina-row-info",children:[a.jsxs("div",{className:"equip-desc-block",children:[a.jsxs("strong",{children:[g?.nome||""," — ",o.marca," ",o.modelo]}),a.jsxs("span",{className:"text-muted equip-num-serie",children:["Nº Série: ",o.numeroSerie]})]}),a.jsxs("span",{className:"badge badge-danger",children:["Próx. manut.: ",da(new Date(o.proximaManut),"d MMM yyyy",{locale:pa})]})]}),a.jsxs("div",{className:"actions",children:[a.jsxs("button",{type:"button",className:"btn-executar-manut",onClick:()=>$({maquina:o}),title:"Executar manutenção",children:[a.jsx(Qa,{size:12})," Executar"]}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>aa(o),title:"Histórico completo em PDF",disabled:F===o.id,children:a.jsx(ca,{size:16})}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>h(o),title:"Gerar etiqueta QR",children:a.jsx(U,{size:16})}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>L(o),title:"Documentação",children:a.jsx(oa,{size:16})}),C&&a.jsxs(a.Fragment,{children:[a.jsx("button",{className:"icon-btn secondary",onClick:()=>R(o),title:"Plano de peças e consumíveis",children:a.jsx(W,{size:16})}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>I(o),title:"Editar",children:a.jsx(ra,{size:16})})]})]})]},o.id)})]},s))})}):a.jsxs(a.Fragment,{children:[j==="categorias"&&a.jsx("div",{className:"categorias-grid",children:m.map(s=>a.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>ga(s),children:[a.jsx("h3",{children:s.nome}),a.jsxs("p",{children:[t.filter(i=>b(i.subcategoriaId)?.categoriaId===s.id).length," equipamento(s)"]}),a.jsx(na,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},s.id))}),j==="subcategorias"&&N&&a.jsxs(a.Fragment,{children:[a.jsxs("div",{className:"equipamentos-nav",children:[a.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:sa,children:[a.jsx(la,{size:16})," Equipamentos"]}),a.jsxs("span",{className:"breadcrumb",children:["/ ",N.nome]})]}),a.jsx("div",{className:"categorias-grid",children:va.map(s=>{const i=t.filter(o=>o.subcategoriaId===s.id).length;return a.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>ba(s),children:[a.jsx("h3",{children:s.nome}),a.jsxs("p",{children:[i," equipamento(s)"]}),a.jsx(na,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},s.id)})})]}),j==="maquinas"&&y&&N&&a.jsxs(a.Fragment,{children:[a.jsxs("div",{className:"equipamentos-nav",children:[a.jsx("button",{type:"button",className:"breadcrumb-btn",onClick:sa,children:"Equipamentos"}),a.jsx("span",{className:"breadcrumb",children:"/"}),a.jsx("button",{type:"button",className:"breadcrumb-btn",onClick:fa,children:N.nome}),a.jsxs("span",{className:"breadcrumb",children:["/ ",y.nome]})]}),a.jsx("div",{className:"maquinas-por-cliente-lista",children:ia.length===0?a.jsx("p",{className:"text-muted",children:"Nenhum equipamento registado nesta subcategoria."}):ia.map(s=>a.jsxs("div",{className:"maquinas-por-cliente",children:[a.jsx("h4",{children:s}),ta[s].map(i=>a.jsxs("div",{className:"maquina-row",children:[a.jsxs("div",{children:[a.jsxs("strong",{children:[i.marca," ",i.modelo]}),a.jsxs("span",{className:"text-muted",children:[" — Nº Série: ",i.numeroSerie]}),i.ultimaManutencaoData&&a.jsxs("span",{className:"text-muted",style:{marginLeft:"0.5rem",fontSize:"0.85em"},children:["· Última manut.: ",da(new Date(i.ultimaManutencaoData),"d MMM yyyy",{locale:pa})]})]}),a.jsxs("div",{className:"actions",children:[a.jsx("button",{className:"icon-btn secondary",onClick:()=>aa(i),title:"Histórico completo em PDF",disabled:F===i.id,children:a.jsx(ca,{size:16})}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>h(i),title:"Gerar etiqueta QR",children:a.jsx(U,{size:16})}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>L(i),title:"Documentação",children:a.jsx(oa,{size:16})}),C&&a.jsxs(a.Fragment,{children:[a.jsx("button",{className:"icon-btn secondary",onClick:()=>R(i),title:"Plano de peças e consumíveis",children:a.jsx(W,{size:16})}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>I(i),title:"Editar",children:a.jsx(ra,{size:16})})]}),A&&a.jsx("button",{className:"icon-btn danger",onClick:()=>{f(i.id),d("Equipamento eliminado.","info")},title:"Eliminar",children:a.jsx(J,{size:16})})]})]},i.id))]},s))})]})]}),q&&a.jsx($a,{isOpen:!0,onClose:()=>I(null),mode:"edit",maquina:q}),a.jsx(Ma,{isOpen:!!S,onClose:()=>L(null),maquina:S}),a.jsx(Ya,{isOpen:!!n,onClose:()=>h(null),maquina:n,subcategoria:n?b(n.subcategoriaId):null,cliente:n?V(n.clienteNif):null}),P&&a.jsx(Da,{isOpen:!0,onClose:()=>$(null),manutencao:null,maquina:P.maquina}),a.jsx(Za,{isOpen:!!z,onClose:()=>R(null),maquina:z})]})}export{ye as default};
