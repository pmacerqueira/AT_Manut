import{a as A,f as C}from"./datasAzores-CBhl9I61.js";import{D as J}from"./relatorio-tAT1QDzU.js";import{a as P,e as X}from"./emailConfig-Bhax3Ffp.js";import{v as Y,I as W,A as Z,q as aa,r as j,x as ea}from"./index-D5_3x8VJ.js";const p={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",divisaoComercial:"Div. Comercial: Pico d'Agua Park, Rua 5, n.º13-15 · 9600-049 Pico da Pedra",sede:"Sede / Divisão Oficinas: Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",pais:"Açores — Portugal",web:"www.navel.pt"};function ia(e,d,t,K,b=[],M={}){if(!e)return"";const{subcategoriaNome:S,ultimoEnvio:m,logoUrl:U}=M,L=U??"/manut/logo.png",a=X,g=!!(e.tipoManutKaeser||Y(t?.marca)),u=e.tipoManutKaeser??"",v=u?W[u]:null,c=t?.posicaoKaeser??null,w=c!=null?ea(c):null,E=c!=null?j(c):null,D=w!=null?j(w):null,O=e.dataCriacao?A(e.dataCriacao):"—",F=e.dataAssinatura?A(e.dataAssinatura):"—",H=d?.data?C(d.data,!0):"—",V=e.dataAssinatura?C(e.dataAssinatura,!0):e.dataCriacao?C(e.dataCriacao,!0):"—",_=t&&S?a(`${S} — ${t.marca} ${t.modelo} — Nº Série: ${t.numeroSerie}`):t?a(`${t.marca} ${t.modelo} — Nº Série: ${t.numeroSerie}`):"—",N=m?.data&&m?.destinatario?`Último envio por email: ${A(m.data)} para ${a(m.destinatario)}`:null,Q=a(d?.tecnico||e?.tecnico||"—"),R=e.assinaturaDigital?P(e.assinaturaDigital):"",z=Math.ceil((b??[]).length/2),q=(b??[]).slice(0,z),I=(b??[]).slice(z),y=(i,o,r=0)=>{const l=e.checklistRespostas?.[i.id],f=l==="sim"?'<span class="badge-sim">SIM</span>':l==="nao"?'<span class="badge-nao">NÃO</span>':'<span class="badge-nd">—</span>';return`<tr><td class="cl-num">${o+r+1}.</td><td class="cl-texto">${a(i.texto)}</td><td class="cl-badge">${f}</td></tr>`};let n=`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Manutenção — Navel</title>
<style>
/* ── Página A4, margens de impressão ── */
@page{size:A4 portrait;margin:8mm 11mm}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10.5px;line-height:1.42;color:#1a1a2e;background:#fff;padding:0}

/* ── Paleta ── */
:root{
  --azul:#1a4880;--azul-med:#2d6eb5;--azul-claro:#e8f2fa;
  --cinza:#f4f6f8;--borda:#c6d8ec;--texto:#1a1a2e;--muted:#5a6a7e;
  --verde:#16a34a;--vermelho:#dc2626;--acento:#f0a500;
  --kaeser:#b45309;--kaeser-bg:#fffbeb;--kaeser-borda:#fde68a;
}

/* ── Quebras de página ── */
section{margin-bottom:10px;page-break-inside:avoid}
.section-can-break{page-break-inside:auto}
.page-break-before{page-break-before:always}
.no-break{page-break-inside:avoid}

/* ── Cabeçalho ── */
.rpt-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:8px;border-bottom:2.5px solid var(--azul)}
.rpt-logo img{max-height:42px;max-width:150px;object-fit:contain;display:block}
.rpt-logo-fallback{font-size:1.2em;font-weight:700;color:var(--azul)}
.rpt-empresa{text-align:right;font-size:9px;line-height:1.5;color:var(--muted)}
.rpt-empresa strong{display:block;font-size:10px;color:var(--azul);margin-bottom:1px}
.rpt-empresa a{color:var(--azul-med);text-decoration:none}

/* ── Título ── */
.rpt-titulo-bar{display:flex;align-items:center;justify-content:space-between;background:var(--azul);color:#fff;padding:5px 10px;margin:7px 0 0;border-radius:3px}
.rpt-titulo-bar h1{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
.rpt-num-wrap{text-align:right}
.rpt-num-label{font-size:8px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;display:block}
.rpt-num{font-size:14px;font-weight:800;letter-spacing:.04em;font-family:'Courier New',monospace}
.rpt-acento{height:2px;background:linear-gradient(90deg,var(--acento),var(--azul-med));margin-bottom:8px;border-radius:0 0 2px 2px}

/* ── Secções ── */
.rpt-section-title{font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--azul-med);border-bottom:1px solid var(--borda);padding-bottom:2px;margin-bottom:5px}

/* ── Grid de dados (2 colunas) ── */
.rpt-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px 10px}
.rpt-field{padding:2.5px 0;border-bottom:1px solid #edf2f7}
.rpt-field:last-child{border-bottom:none}
.rpt-label{font-size:8.5px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);display:block;margin-bottom:0}
.rpt-value{font-size:10.5px;color:var(--texto)}
.rpt-field--full{grid-column:1/-1}

/* ── Bloco KAESER ── */
.kaeser-band{background:var(--kaeser-bg);border:1.5px solid var(--kaeser-borda);border-radius:5px;margin-bottom:9px;overflow:hidden;page-break-inside:avoid}
.kaeser-band-header{background:var(--kaeser);color:#fff;padding:4px 10px;display:flex;align-items:center;justify-content:space-between;gap:8px}
.kaeser-band-titulo{font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}
.kaeser-band-subtitulo{font-size:9px;opacity:.85}
.kaeser-band-body{padding:7px 10px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px 14px}
.kaeser-item{}
.kaeser-item-label{font-size:8px;text-transform:uppercase;letter-spacing:.05em;color:var(--kaeser);font-weight:700;display:block;margin-bottom:1px}
.kaeser-item-valor{font-size:11px;font-weight:600;color:var(--texto)}
.kaeser-item-valor.destaque{font-size:13px;font-weight:800;color:var(--kaeser)}
.kaeser-item-val-sub{font-size:8.5px;color:var(--muted);display:block}
.kaeser-seq{grid-column:1/-1;margin-top:4px;border-top:1px solid var(--kaeser-borda);padding-top:5px}
.kaeser-seq-label{font-size:8px;text-transform:uppercase;letter-spacing:.05em;color:var(--kaeser);font-weight:700;margin-bottom:3px}
.kaeser-seq-dots{display:flex;gap:3px;flex-wrap:wrap;align-items:center}
.kaeser-dot{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;border:1.5px solid transparent;flex-shrink:0}
.kaeser-dot.passado{background:#e5e7eb;color:#6b7280;border-color:#d1d5db}
.kaeser-dot.atual{background:var(--kaeser);color:#fff;border-color:var(--kaeser)}
.kaeser-dot.proximo{background:#fff;color:var(--kaeser);border-color:var(--kaeser)}
.kaeser-dot.futuro{background:#f9fafb;color:#9ca3af;border-color:#e5e7eb}
.kaeser-dot-sep{color:#9ca3af;font-size:10px;padding:0 1px}

/* ── Checklist coluna única ── */
.checklist-1col{width:100%}
.checklist-2col{display:grid;grid-template-columns:1fr 1fr;gap:0 10px}
.checklist-table{width:100%;border-collapse:collapse;font-size:9.5px}
.checklist-table tr:nth-child(even){background:var(--cinza)}
.checklist-table td{padding:2.8px 4px;border-bottom:1px solid #edf2f7;vertical-align:top}
.checklist-table td.cl-num{width:1.6em;color:var(--muted);font-size:8.5px;padding-left:2px;white-space:nowrap}
.checklist-table td.cl-texto{padding-right:6px}
.checklist-table td.cl-badge{width:32px;text-align:center;padding-right:2px;white-space:nowrap}
.badge-sim{background:rgba(22,163,74,.15);color:var(--verde);padding:1px 5px;border-radius:8px;font-size:8.5px;font-weight:700}
.badge-nao{background:rgba(220,38,38,.12);color:var(--vermelho);padding:1px 5px;border-radius:8px;font-size:8.5px;font-weight:700}
.badge-nd{color:var(--muted);font-size:9px}

/* ── Notas ── */
.rpt-notas{background:var(--azul-claro);border-left:2.5px solid var(--azul-med);padding:5px 9px;border-radius:0 3px 3px 0;font-size:10px;color:var(--texto)}

/* ── Fotos ── */
.rpt-fotos-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:6px}
.rpt-fotos-grid img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:3px;border:1px solid var(--borda);display:block}

/* ── Peças e consumíveis ── */
.pecas-table{width:100%;border-collapse:collapse;font-size:9.5px}
.pecas-table thead{display:table-header-group}
.pecas-table th{background:var(--azul);color:#fff;padding:4px 6px;text-align:left;font-size:8.5px;text-transform:uppercase;letter-spacing:.04em}
.pecas-table td{padding:3px 6px;border-bottom:1px solid #edf2f7;vertical-align:middle}
.pecas-table tr.row-usado td{background:#f0fdf4}
.pecas-table tr.row-nao-usado td{background:#fafafa;color:#9ca3af}
.pecas-table tr.row-nao-usado .cell-desc{text-decoration:line-through}
.pecas-table .cell-status{width:20px;text-align:center;font-size:11px;font-weight:700}
.pecas-table .cell-pos{width:46px;color:var(--muted);font-family:'Courier New',monospace;font-size:8.5px}
.pecas-table .cell-code{width:118px;font-family:'Courier New',monospace;font-size:9px}
.pecas-table .cell-qty{width:36px;text-align:right;font-weight:600}
.pecas-table .cell-un{width:34px;color:var(--muted);font-size:8.5px}
.pecas-group-row td{background:var(--cinza)!important;font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);padding:3px 6px;page-break-after:avoid}
.pecas-group-usado td{border-left:3px solid var(--verde);color:var(--verde)}
.pecas-group-nao-usado td{border-left:3px solid #9ca3af}
.pecas-resumo{display:flex;gap:16px;padding:4px 6px;background:var(--cinza);border-top:1.5px solid var(--borda);font-size:9px}
.pecas-resumo-item{display:flex;align-items:center;gap:4px}
.pecas-resumo-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.pecas-resumo-dot.verde{background:var(--verde)}
.pecas-resumo-dot.cinza{background:#9ca3af}

/* ── Assinatura + declaração lado a lado ── */
.rpt-bottom{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:start}
.rpt-assinatura-box{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px}
.rpt-assinatura-img img{max-width:180px;max-height:70px;border:1px solid var(--borda);border-radius:3px;margin-top:4px;background:#fff;display:block}
.rpt-declaracao{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px;font-size:8.5px;color:var(--muted);line-height:1.55}

/* ── Rodapé ── */
.rpt-footer{margin-top:8px;padding-top:6px;border-top:1px solid var(--borda);display:flex;justify-content:space-between;font-size:8.5px;color:var(--muted)}
</style>
</head>
<body>

<header class="rpt-header">
  <div class="rpt-logo">
    <img src="${L}" alt="Navel"
      onerror="this.parentNode.innerHTML='<span class=rpt-logo-fallback>Navel</span>'">
  </div>
  <div class="rpt-empresa">
    <strong>${a(p.nome)}</strong>
    ${a(p.divisaoComercial)}<br>
    ${a(p.sede)}<br>
    ${a(p.telefones)} &nbsp;|&nbsp; <a href="https://${p.web}">${p.web}</a><br>
    ${a(p.pais)}
  </div>
</header>

<div class="rpt-titulo-bar">
  <h1>Relatório de Manutenção${g?" — Compressor":""}</h1>
  <div class="rpt-num-wrap">
    <span class="rpt-num-label">Nº de Serviço</span>
    <span class="rpt-num">${a(e?.numeroRelatorio??d?.id??"—")}</span>
  </div>
</div>
<div class="rpt-acento"></div>`;if(g){const i=v?.label??(u?`Tipo ${u}`:"Compressor"),o=v?.descricao??"",r=t?.horasTotaisAcumuladas??form?.horasTotais??null,l=t?.horasServicoAcumuladas??form?.horasServico??null,f=t?.anoFabrico??"—",x=a(t?.marca??"—"),s=a(t?.modelo??"—"),h=a(t?.numeroSerie??"—"),T=a(t?.numeroDocumentoVenda??""),G=aa.map((B,k)=>{let $="futuro";return c!=null&&(k<c?$="passado":k===c?$="atual":k===w&&($="proximo")),`<span class="kaeser-dot ${$}" title="Ano ${k+1}">${B}</span>`}).join('<span class="kaeser-dot-sep">·</span>');n+=`
<div class="kaeser-band">
  <div class="kaeser-band-header">
    <span class="kaeser-band-titulo">Manutenção KAESER — ${a(i)}</span>
    ${o?`<span class="kaeser-band-subtitulo">${a(o)}</span>`:""}
  </div>
  <div class="kaeser-band-body">
    <div class="kaeser-item">
      <span class="kaeser-item-label">Fabricante / Modelo</span>
      <span class="kaeser-item-valor">${x} ${s}</span>
    </div>
    <div class="kaeser-item">
      <span class="kaeser-item-label">Número de série</span>
      <span class="kaeser-item-valor destaque">${h}</span>
    </div>
    <div class="kaeser-item">
      <span class="kaeser-item-label">Ano de fabrico</span>
      <span class="kaeser-item-valor">${f}</span>
      ${T?`<span class="kaeser-item-val-sub">Doc. venda: ${T}</span>`:""}
    </div>
    ${r!=null?`
    <div class="kaeser-item">
      <span class="kaeser-item-label">Horas totais acumuladas</span>
      <span class="kaeser-item-valor destaque">${r} h</span>
    </div>`:""}
    ${l!=null?`
    <div class="kaeser-item">
      <span class="kaeser-item-label">Horas de serviço</span>
      <span class="kaeser-item-valor">${l} h</span>
    </div>`:""}
    ${E?`
    <div class="kaeser-item">
      <span class="kaeser-item-label">Ciclo efectuado</span>
      <span class="kaeser-item-valor">${a(E)}</span>
      ${D?`<span class="kaeser-item-val-sub">Próxima: ${a(D)}</span>`:""}
    </div>`:""}
    <div class="kaeser-seq">
      <div class="kaeser-seq-label">Sequência do ciclo de manutenção (12 anos)</div>
      <div class="kaeser-seq-dots">
        ${G}
        ${c!=null?`<span style="font-size:8px;color:#9ca3af;margin-left:6px">
          ● Efectuado &nbsp; ○ Próximo &nbsp; · Futuro
        </span>`:""}
      </div>
    </div>
  </div>
</div>`}if(n+=`
<section>
  <div class="rpt-section-title">Dados da manutenção</div>
  <div class="rpt-grid">
    <div class="rpt-field">
      <span class="rpt-label">Data agendada</span>
      <span class="rpt-value">${H}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Data de realização</span>
      <span class="rpt-value">${V}</span>
    </div>
    ${g?"":`
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Equipamento</span>
      <span class="rpt-value">${_}</span>
    </div>`}
    <div class="rpt-field">
      <span class="rpt-label">Cliente</span>
      <span class="rpt-value">${a(K?.nome??"—")}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Técnico responsável</span>
      <span class="rpt-value">${Q}</span>
    </div>
    ${(d?.horasTotais!=null||d?.horasServico!=null)&&!g?`
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Contadores de horas</span>
      <span class="rpt-value">${d.horasTotais!=null?`Total: ${d.horasTotais} h`:""}${d.horasTotais!=null&&d.horasServico!=null?" · ":""}${d.horasServico!=null?`Serviço: ${d.horasServico} h`:""}</span>
    </div>`:""}
  </div>
</section>`,b?.length>0&&(g?n+=`
<section class="section-can-break">
  <div class="rpt-section-title">Checklist de verificação — ${b.length} pontos</div>
  <div class="checklist-1col">
    <table class="checklist-table"><tbody>
      ${(b??[]).map((i,o)=>y(i,o,0)).join("")}
    </tbody></table>
  </div>
</section>`:n+=`
<section>
  <div class="rpt-section-title">Checklist de verificação</div>
  <div class="checklist-2col">
    <table class="checklist-table"><tbody>
      ${q.map((i,o)=>y(i,o,0)).join("")}
    </tbody></table>
    <table class="checklist-table"><tbody>
      ${I.map((i,o)=>y(i,o,z)).join("")}
    </tbody></table>
  </div>
</section>`),(e.notas||e.fotos?.length>0)&&(n+='<section><div class="rpt-section-title">Notas e fotografias</div>',e.notas&&(n+=`<div class="rpt-notas">${a(e.notas).replace(/\n/g,"<br>")}</div>`),e.fotos?.length>0&&(n+='<div class="rpt-fotos-grid">',e.fotos.forEach((i,o)=>{const r=P(i);r&&(n+=`<img src="${r}" alt="Fotografia ${o+1}">`)}),n+="</div>"),n+="</section>"),e.pecasUsadas?.length>0){const i=s=>"usado"in s?s:{...s,usado:(s.quantidadeUsada??s.quantidade??0)>0},o=e.pecasUsadas.map(i),r=o.filter(s=>s.usado),l=o.filter(s=>!s.usado),f=u?`Consumíveis e peças — Manutenção Tipo ${u}${v?` · ${v.label}`:""}`:"Consumíveis e peças",x=(s,h)=>`
      <tr class="${h} no-break">
        <td class="cell-status">${h==="row-usado"?"✓":"✗"}</td>
        <td class="cell-pos">${a(s.posicao??"")}</td>
        <td class="cell-code">${a(s.codigoArtigo??"")}</td>
        <td>${a(s.descricao??"")}</td>
        <td class="cell-qty">${s.quantidade??""}</td>
        <td class="cell-un">${a(s.unidade??"")}</td>
      </tr>`;n+=`
<section class="section-can-break${g?" page-break-before":""}">
  <div class="rpt-section-title">${f}</div>
  <table class="pecas-table">
    <thead>
      <tr>
        <th style="width:20px"></th>
        <th style="width:46px">Pos.</th>
        <th style="width:118px">Código artigo</th>
        <th>Descrição</th>
        <th style="width:36px;text-align:right">Qtd.</th>
        <th style="width:34px">Un.</th>
      </tr>
    </thead>
    <tbody>
      ${r.length>0?`<tr class="pecas-group-row pecas-group-usado"><td colspan="6">✓ Utilizados — ${r.length} artigo${r.length!==1?"s":""}</td></tr>`:""}
      ${r.map(s=>x(s,"row-usado")).join("")}
      ${l.length>0?`<tr class="pecas-group-row pecas-group-nao-usado"><td colspan="6">✗ Não utilizados — ${l.length} artigo${l.length!==1?"s":""}</td></tr>`:""}
      ${l.map(s=>x(s,"row-nao-usado")).join("")}
    </tbody>
  </table>
  <div class="pecas-resumo">
    <span class="pecas-resumo-item"><span class="pecas-resumo-dot verde"></span>${r.length} artigo${r.length!==1?"s":""} utilizado${r.length!==1?"s":""}</span>
    ${l.length>0?`<span class="pecas-resumo-item"><span class="pecas-resumo-dot cinza"></span>${l.length} artigo${l.length!==1?"s":""} não substituído${l.length!==1?"s":""}</span>`:""}
    <span style="margin-left:auto;color:var(--muted)">${o.length} artigo${o.length!==1?"s":""} no plano</span>
  </div>
</section>`}return n+=`
<section class="no-break">
  <div class="rpt-section-title">Registo e assinatura</div>
  <div class="rpt-bottom">
    <div class="rpt-assinatura-box">
      <div class="rpt-grid">
        <div class="rpt-field">
          <span class="rpt-label">Data de criação</span>
          <span class="rpt-value">${O}</span>
        </div>
        <div class="rpt-field">
          <span class="rpt-label">Data de assinatura</span>
          <span class="rpt-value">${F}</span>
        </div>
        <div class="rpt-field rpt-field--full">
          <span class="rpt-label">Assinado pelo cliente</span>
          <span class="rpt-value">${a(e.nomeAssinante??"—")}</span>
        </div>
      </div>
      ${R?`
      <div class="rpt-assinatura-img">
        <span class="rpt-label" style="margin-top:5px;display:block">Assinatura manuscrita</span>
        <img src="${R}" alt="Assinatura do cliente">
      </div>`:""}
    </div>
    <div class="rpt-declaracao">${a(J)}</div>
  </div>
</section>

${N?`<p style="font-size:8.5px;color:#888;margin-bottom:5px">${N}</p>`:""}
<footer class="rpt-footer">
  <span>${a(Z)}</span>
  <span>${a(p.web)} &nbsp;|&nbsp; ${a(p.telefones)}</span>
</footer>

</body></html>`,n}export{ia as r};
