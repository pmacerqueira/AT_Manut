import{c as P,A as L}from"./index-BW_jW9Vz.js";import{b as g,a as b}from"./datasAzores-CucQI6kh.js";import{a as h,D as O,e as _}from"./relatorio-I-22c2nM.js";const M=[["path",{d:"m22 7-8.991 5.727a2 2 0 0 1-2.009 0L2 7",key:"132q7q"}],["rect",{x:"2",y:"4",width:"20",height:"16",rx:"2",key:"izxlao"}]],H=P("mail",M),r={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",divisaoComercial:"Div. Comercial: Pico d'Agua Park, Rua 5, n.º13-15 · 9600-049 Pico da Pedra",sede:"Sede / Divisão Oficinas: Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",pais:"Açores — Portugal",web:"www.navel.pt"};function I(a,s,o,$,p=[],z={}){if(!a)return"";const{subcategoriaNome:f,ultimoEnvio:d,logoUrl:y}=z,A=y??"/manut/logo.png",t=_,w=a.dataCriacao?g(a.dataCriacao):"—",k=a.dataAssinatura?g(a.dataAssinatura):"—",C=s?.data?b(s.data,!0):"—",E=a.dataAssinatura?b(a.dataAssinatura,!0):a.dataCriacao?b(a.dataCriacao,!0):"—",N=o&&f?t(`${f} — ${o.marca} ${o.modelo} — Nº Série: ${o.numeroSerie}`):o?t(`${o.marca} ${o.modelo} — Nº Série: ${o.numeroSerie}`):"—",m=d?.data&&d?.destinatario?`Último envio por email: ${g(d.data)} para ${t(d.destinatario)}`:null,D=t(s?.tecnico||a?.tecnico||"—"),v=a.assinaturaDigital?h(a.assinaturaDigital):"",c=Math.ceil((p??[]).length/2),S=(p??[]).slice(0,c),R=(p??[]).slice(c),u=(i,l,n=0)=>{const x=a.checklistRespostas?.[i.id],T=x==="sim"?'<span class="badge-sim">S</span>':x==="nao"?'<span class="badge-nao">N</span>':'<span class="badge-nd">—</span>';return`<tr><td>${l+n+1}.</td><td>${t(i.texto)}</td><td>${T}</td></tr>`};let e=`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Manutenção — Navel</title>
<style>
/* ── Página A4, margens mínimas ── */
@page{size:A4 portrait;margin:8mm 11mm}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10.5px;line-height:1.38;color:#1a1a2e;background:#fff;padding:0}

/* ── Paleta ── */
:root{
  --azul:#1a4880;--azul-med:#2d6eb5;--azul-claro:#e8f2fa;
  --cinza:#f4f6f8;--borda:#c6d8ec;--texto:#1a1a2e;--muted:#5a6a7e;
  --verde:#16a34a;--vermelho:#dc2626;--acento:#f0a500;
}

/* ── Cabeçalho ── */
.rpt-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:8px;border-bottom:2.5px solid var(--azul)}
.rpt-logo img{max-height:42px;max-width:150px;object-fit:contain;display:block}
.rpt-logo-fallback{font-size:1.2em;font-weight:700;color:var(--azul)}
.rpt-empresa{text-align:right;font-size:9px;line-height:1.5;color:var(--muted)}
.rpt-empresa strong{display:block;font-size:10px;color:var(--azul);margin-bottom:1px}
.rpt-empresa a{color:var(--azul-med);text-decoration:none}

/* ── Título ── */
.rpt-titulo-bar{display:flex;align-items:center;justify-content:space-between;background:var(--azul);color:#fff;padding:5px 10px;margin:7px 0 0;border-radius:3px}
.rpt-titulo-bar h1{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
.rpt-num-wrap{text-align:right}
.rpt-num-label{font-size:8px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;display:block}
.rpt-num{font-size:14px;font-weight:800;letter-spacing:.04em;font-family:'Courier New',monospace}
.rpt-acento{height:2px;background:linear-gradient(90deg,var(--acento),var(--azul-med));margin-bottom:10px;border-radius:0 0 2px 2px}

/* ── Secções ── */
section{margin-bottom:9px}
.rpt-section-title{font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--azul-med);border-bottom:1px solid var(--borda);padding-bottom:2px;margin-bottom:5px}

/* ── Grid de dados (2 colunas) ── */
.rpt-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px 10px}
.rpt-field{padding:2px 0;border-bottom:1px solid #edf2f7}
.rpt-field:last-child{border-bottom:none}
.rpt-label{font-size:8.5px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);display:block;margin-bottom:0}
.rpt-value{font-size:10.5px;color:var(--texto)}
.rpt-field--full{grid-column:1/-1}

/* ── Checklist 2 colunas ── */
.checklist-2col{display:grid;grid-template-columns:1fr 1fr;gap:0 10px}
.checklist-table{width:100%;border-collapse:collapse;font-size:9.5px}
.checklist-table tr:nth-child(even){background:var(--cinza)}
.checklist-table td{padding:2.5px 4px 2.5px 0;border-bottom:1px solid #edf2f7;vertical-align:top}
.checklist-table td:first-child{width:1.6em;color:var(--muted);font-size:8.5px;padding-left:2px;white-space:nowrap}
.checklist-table td:last-child{width:22px;text-align:center;padding-right:2px}
.badge-sim{background:rgba(22,163,74,.15);color:var(--verde);padding:1px 4px;border-radius:8px;font-size:9px;font-weight:700}
.badge-nao{background:rgba(220,38,38,.12);color:var(--vermelho);padding:1px 4px;border-radius:8px;font-size:9px;font-weight:700}
.badge-nd{color:var(--muted);font-size:9px}

/* ── Notas ── */
.rpt-notas{background:var(--azul-claro);border-left:2.5px solid var(--azul-med);padding:5px 9px;border-radius:0 3px 3px 0;font-size:10px;color:var(--texto)}

/* ── Fotos ── */
.rpt-fotos-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:6px}
.rpt-fotos-grid img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:3px;border:1px solid var(--borda);display:block}

/* ── Assinatura + declaração lado a lado ── */
.rpt-bottom{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:start}
.rpt-assinatura-box{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px}
.rpt-assinatura-img img{max-width:180px;max-height:70px;border:1px solid var(--borda);border-radius:3px;margin-top:4px;background:#fff;display:block}
.rpt-declaracao{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px;font-size:8.5px;color:var(--muted);line-height:1.55}

/* ── Rodapé ── */
.rpt-footer{margin-top:8px;padding-top:6px;border-top:1px solid var(--borda);display:flex;justify-content:space-between;font-size:8.5px;color:var(--muted)}
</style>
</head>
<body>

<header class="rpt-header">
  <div class="rpt-logo">
    <img src="${A}" alt="Navel"
      onerror="this.parentNode.innerHTML='<span class=rpt-logo-fallback>Navel</span>'">
  </div>
  <div class="rpt-empresa">
    <strong>${t(r.nome)}</strong>
    ${t(r.divisaoComercial)}<br>
    ${t(r.sede)}<br>
    ${t(r.telefones)} &nbsp;|&nbsp; <a href="https://${r.web}">${r.web}</a><br>
    ${t(r.pais)}
  </div>
</header>

<div class="rpt-titulo-bar">
  <h1>Relatório de Manutenção</h1>
  <div class="rpt-num-wrap">
    <span class="rpt-num-label">Nº de Serviço</span>
    <span class="rpt-num">${t(a?.numeroRelatorio??s?.id??"—")}</span>
  </div>
</div>
<div class="rpt-acento"></div>

<!-- Dados -->
<section>
  <div class="rpt-section-title">Dados da manutenção</div>
  <div class="rpt-grid">
    <div class="rpt-field">
      <span class="rpt-label">Data agendada</span>
      <span class="rpt-value">${C}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Data de realização</span>
      <span class="rpt-value">${E}</span>
    </div>
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Equipamento</span>
      <span class="rpt-value">${N}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Cliente</span>
      <span class="rpt-value">${t($?.nome??"—")}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Técnico responsável</span>
      <span class="rpt-value">${D}</span>
    </div>
    ${s?.horasTotais!=null||s?.horasServico!=null?`
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Contadores de horas</span>
      <span class="rpt-value">${s.horasTotais!=null?`Total: ${s.horasTotais} h`:""}${s.horasTotais!=null&&s.horasServico!=null?" · ":""}${s.horasServico!=null?`Serviço: ${s.horasServico} h`:""}</span>
    </div>`:""}
  </div>
</section>`;return p?.length>0&&(e+=`
<section>
  <div class="rpt-section-title">Checklist de verificação</div>
  <div class="checklist-2col">
    <table class="checklist-table"><tbody>
      ${S.map((i,l)=>u(i,l,0)).join("")}
    </tbody></table>
    <table class="checklist-table"><tbody>
      ${R.map((i,l)=>u(i,l,c)).join("")}
    </tbody></table>
  </div>
</section>`),(a.notas||a.fotos?.length>0)&&(e+='<section><div class="rpt-section-title">Notas e fotografias</div>',a.notas&&(e+=`<div class="rpt-notas">${t(a.notas).replace(/\n/g,"<br>")}</div>`),a.fotos?.length>0&&(e+='<div class="rpt-fotos-grid">',a.fotos.forEach((i,l)=>{const n=h(i);n&&(e+=`<img src="${n}" alt="Fotografia ${l+1}">`)}),e+="</div>"),e+="</section>"),e+=`
<!-- Assinatura + Declaração lado a lado -->
<section>
  <div class="rpt-section-title">Registo e assinatura</div>
  <div class="rpt-bottom">
    <div class="rpt-assinatura-box">
      <div class="rpt-grid">
        <div class="rpt-field">
          <span class="rpt-label">Data de criação</span>
          <span class="rpt-value">${w}</span>
        </div>
        <div class="rpt-field">
          <span class="rpt-label">Data de assinatura</span>
          <span class="rpt-value">${k}</span>
        </div>
        <div class="rpt-field rpt-field--full">
          <span class="rpt-label">Assinado pelo cliente</span>
          <span class="rpt-value">${t(a.nomeAssinante??"—")}</span>
        </div>
      </div>
      ${v?`
      <div class="rpt-assinatura-img">
        <span class="rpt-label" style="margin-top:5px;display:block">Assinatura manuscrita</span>
        <img src="${v}" alt="Assinatura do cliente">
      </div>`:""}
    </div>
    <div class="rpt-declaracao">${t(O)}</div>
  </div>
</section>

${m?`<p style="font-size:8.5px;color:#888;margin-bottom:5px">${m}</p>`:""}
<footer class="rpt-footer">
  <span>${t(L)}</span>
  <span>${t(r.web)} &nbsp;|&nbsp; ${t(r.telefones)}</span>
</footer>

</body></html>`,e}const G={ENDPOINT_URL:"https://www.navel.pt/api/send-email.php",AUTH_TOKEN:"Navel2026$Api!Key#xZ99",REPLY_TO:"geral@navel.pt"};export{G as E,H as M,I as r};
