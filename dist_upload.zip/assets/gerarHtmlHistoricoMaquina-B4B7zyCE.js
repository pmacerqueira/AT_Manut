const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/apiService-B-7NRfzQ.js","assets/index-BWdHbKeY.js","assets/vendor-Bk0NZ5Or.js","assets/vendor-pdf-hYLUQ4hX.js","assets/vendor-icons-Xj5hpEcu.js","assets/vendor-datefns-CCZTWiZ_.js","assets/index-BWxVqpgk.css"])))=>i.map(i=>d[i]);
import{_ as Ea}from"./vendor-pdf-hYLUQ4hX.js";import{b as ja,a as wa,c as Ya,R as Za,C as Qa,D as Xa,E as Ja,g as ae,P as ra,j as a,O as ee,F as ya,G as Ta,s as Ra,u as Ka,x as ba,l as ia,S as $a,T as Aa,A as Ma,p as fa,f as la,H as te}from"./index-BWdHbKeY.js";import{r as C}from"./vendor-Bk0NZ5Or.js";import{h as Ua,s as ga,e as La,a as Pa}from"./horasContadorEquipamento-CtzZOQDv.js";import{S as Sa,d as oe}from"./kaeserCiclo-BSrwchLP.js";import{f as ma}from"./vendor-datefns-CCZTWiZ_.js";import{p as ha}from"./pt-DInhV8Fk.js";import{I as Oa,X as Da,Z as _a,_ as re,o as se,w as va,x as Ba,K as ie}from"./vendor-icons-Xj5hpEcu.js";import{apiUploadMachinePdf as ne}from"./apiService-B-7NRfzQ.js";import{E as sa}from"./empresa-pV7uX3IF.js";const qa="Cada equipamento tem uma única ficha de documentação no servidor. Pode geri-la aqui, em Equipamentos (ícone de pasta na mesma linha do equipamento) ou em Clientes, na ficha do cliente — frota — equipamento — botão «Documentação técnica». O que adicionar ou alterar reflecte-se em todo o lado. Estes ficheiros ficam disponíveis na execução de manutenções, montagens e reparações.",Ha="Nos compressores de parafuso, carregue o PDF do plano como tipo «Plano de manutenção (PDF)» para poder importar consumíveis por fase A/B/C/D (Plano de peças).",Re="A documentação (ícone de pasta) é a mesma ficha que em Clientes › frota do equipamento.",Ke="Documentação técnica — mesma ficha que em Clientes (frota do cliente)";function za(o){return String(o??"").trim().toLowerCase()}function le(o,l){const t=String(l??"").trim();if(!t)return!1;const c=String(o?.clienteNif??"").trim(),d=String(o?.clienteId??"").trim(),N=y=>y.replace(/\s+/g,"");return c===t||d===t||N(c)===N(t)||N(d)===N(t)}function ce(o,{numeroSerie:l,clienteNif:t,excludeId:c=null}){const d=za(l);if(!d)return null;const N=c!=null&&String(c)!==""?String(c):null;for(const y of o||[])if(!(N&&String(y.id)===N)&&le(y,t)&&za(y.numeroSerie??y.numero_serie)===d)return y;return null}const ca=(o,l)=>o(l)?.nome?.toLowerCase().includes("levador")??!1,oa=o=>["sub5","sub14"].includes(o),de=o=>Ta.includes(o);function pe(o){if(!o)return"";const l=o.planoManutencaoCompressor??o.plano_manutencao_compressor??"";return l||(oa(o.subcategoriaId)&&o.posicaoKaeser!=null&&ya(o.marca)?ra:"")}function xa(o,l){const t={...o,...l},c=t.subcategoriaId;return oa(c)?(t.planoManutencaoCompressor??"")===ra?{...t,posicaoKaeser:t.posicaoKaeser===void 0?null:t.posicaoKaeser}:{...t,posicaoKaeser:null}:{...t,planoManutencaoCompressor:"",posicaoKaeser:null}}function ue(o=[]){return[...o].sort((l,t)=>{const c=(l?.nome??"").trim(),d=(t?.nome??"").trim();return c.localeCompare(d,"pt",{sensitivity:"base"})})}function da(o){const l=String(o?.id??"").trim();if(l)return`id:${l}`;const t=(o?.nome??"").trim().toLowerCase();return t?`name:${t}`:""}function me(o){return new Promise((l,t)=>{const c=new FileReader;c.onerror=t,c.onload=()=>l(String(c.result||"")),c.readAsDataURL(o)})}function he(o){return new Promise((l,t)=>{const c=new Image;c.onerror=t,c.onload=()=>{const y=Math.min(1200/c.width,360/c.height,1),B=Math.max(1,Math.round(c.width*y)),K=Math.max(1,Math.round(c.height*y)),x=document.createElement("canvas");x.width=B,x.height=K;const w=x.getContext("2d");w.clearRect(0,0,B,K),w.drawImage(c,0,0,B,K),l(x.toDataURL("image/png",.92))},c.src=o})}function Ue({isOpen:o,onClose:l,mode:t,clienteNifLocked:c,maquina:d,onSave:N}){const{clientes:y,categorias:B,marcas:K,maquinas:x,INTERVALOS:w,getSubcategoriasByCategoria:f,getSubcategoria:V,getCategoria:I,addMarca:F,addMaquina:j,updateMaquina:A,addManutencao:D,manutencoes:L,updateManutencao:X}=ja(),{showToast:s}=wa(),{user:O}=Ya(),G=O?.role===Za.ADMIN,[J,E]=C.useState(""),aa=C.useMemo(()=>{const e=new Date().getFullYear(),r=new Set;for(let v=e-1;v<=e+3;v++)Qa(v).forEach(k=>r.add(k));return r},[]),Q=C.useCallback(e=>{if(!e)return E(""),!0;const r=new Date(e+"T12:00:00");if(Xa(r)){const v=r.getDay()===0?"Domingo":"Sábado";return E(`${v} — não é dia útil. Escolha um dia de semana.`),!1}return Ja(r,aa)?(E("Esta data é feriado. Escolha outro dia."),!1):(E(""),!0)},[aa]),W=C.useRef(!1),[p,n]=C.useState({clienteNif:"",categoriaId:"",subcategoriaId:"",periodicidadeManut:"",marcaId:"",marca:"",marcaLogoUrl:"",modelo:"",numeroSerie:"",anoFabrico:"",numeroDocumentoVenda:"",proximaManut:"",refKitManut3000h:"",refKitManut6000h:"",refCorreia:"",refFiltroOleo:"",refFiltroSeparador:"",refFiltroAr:"",planoManutencaoCompressor:"",posicaoKaeser:null}),g=C.useMemo(()=>p.id?L.some(e=>String(e.maquinaId)===String(p.id)&&e.status==="concluida"):!1,[L,p.id]),T=p.categoriaId?f(p.categoriaId):[],[z,H]=C.useState(!1),[$,q]=C.useState({nome:"",logoUrl:"",corHex:"#1a4880"}),[m,P]=C.useState(!1),R=ue(K),Y=e=>R.find(r=>String(r?.id)===String(e)),i=e=>R.find(r=>(r?.nome??"").trim().toLowerCase()===String(e??"").trim().toLowerCase()),b=e=>R.find(r=>da(r)===e),M=(()=>{if(z)return"__new__";if(p.marcaId){const e=Y(p.marcaId);if(e)return da(e)}if(p.marca){const e=i(p.marca);if(e)return da(e)}return""})();C.useEffect(()=>{const e=o&&!W.current;if(W.current=o,!!e){if(t==="add"){const v=B[0]?.id||"",u=f(v)[0]?.id||"",U=ca(I,v)?"anual":"";n({clienteNif:c||y[0]?.nif||"",categoriaId:v,subcategoriaId:u,periodicidadeManut:U,marcaId:"",marca:"",marcaLogoUrl:"",marcaCorHex:"",modelo:"",numeroSerie:"",anoFabrico:new Date().getFullYear(),numeroDocumentoVenda:"",proximaManut:ae(),refKitManut3000h:"",refKitManut6000h:"",refCorreia:"",refFiltroOleo:"",refFiltroSeparador:"",refFiltroAr:"",planoManutencaoCompressor:"",posicaoKaeser:null}),H(!1),q({nome:"",logoUrl:"",corHex:"#1a4880"})}else if(d){const r=V(d.subcategoriaId);I(r?.categoriaId);const v=d.periodicidadeManut??(ca(I,r?.categoriaId)?"anual":""),k=K.find(U=>(U.nome??"").toLowerCase()===(d.marca??"").toLowerCase()),u=pe(d);n({id:d.id,clienteNif:d.clienteNif,categoriaId:r?.categoriaId||"",subcategoriaId:d.subcategoriaId,periodicidadeManut:v,marcaId:d.marcaId!=null?String(d.marcaId):k?.id!=null?String(k.id):"",marca:d.marca,marcaLogoUrl:d.marcaLogoUrl||"",marcaCorHex:d.marcaCorHex||k?.corHex||"",modelo:d.modelo,numeroSerie:d.numeroSerie,anoFabrico:d.anoFabrico||"",numeroDocumentoVenda:d.numeroDocumentoVenda||"",proximaManut:d.proximaManut,refKitManut3000h:d.refKitManut3000h||"",refKitManut6000h:d.refKitManut6000h||"",refCorreia:d.refCorreia||"",refFiltroOleo:d.refFiltroOleo||"",refFiltroSeparador:d.refFiltroSeparador||"",refFiltroAr:d.refFiltroAr||"",planoManutencaoCompressor:u,posicaoKaeser:u===ra?d.posicaoKaeser??null:null}),H(!1),q({nome:"",logoUrl:"",corHex:"#1a4880"})}}},[o,t,c,d,B,y,K,f,V,I,w]);const ta=async e=>{if(e.preventDefault(),!G&&!Q(p.proximaManut)){s("A data escolhida não é dia útil. Selecione outro dia.","warning");return}const{categoriaId:r,id:v,...k}=p;let u={...k};try{if(z){const _=$.nome.trim();if(!_){s("Indique o nome da nova marca.","warning");return}const ea=$.logoUrl.trim(),Ca=($.corHex||"").trim(),Na=await F({nome:_,logoUrl:ea,corHex:Ca}),Wa=Na!=null?String(Na):"";u={...u,marcaId:Wa,marca:_,marcaLogoUrl:ea,marcaCorHex:Ca}}else if(u.marcaId||u.marca){const _=u.marcaId?K.find(ea=>String(ea.id)===String(u.marcaId)):K.find(ea=>(ea?.nome??"").trim().toLowerCase()===String(u.marca??"").trim().toLowerCase());_&&(u={...u,marcaId:_.id!=null&&String(_.id).trim()!==""?String(_.id):"",marca:_.nome||u.marca||"",marcaLogoUrl:_.logoUrl||u.marcaLogoUrl||"",marcaCorHex:_.corHex||u.marcaCorHex||""})}oa(u.subcategoriaId)&&u.planoManutencaoCompressor===ra||(u.planoManutencaoCompressor="",u.posicaoKaeser=null);const U=String(u.clienteNif??c??"").trim();if(ce(x,{numeroSerie:u.numeroSerie,clienteNif:U,excludeId:t==="edit"?v:null})){s("Já existe um equipamento deste cliente com este nº de série. Não é possível duplicar.","warning");return}if(t==="add"){const _=await j(u);u.proximaManut&&D({maquinaId:_,data:u.proximaManut,tipo:"periodica",status:"pendente",observacoes:"",tecnico:""}),s("Equipamento adicionado com sucesso.","success"),N?.({id:_,...u},"add")}else{if(await A(v,u),u.proximaManut&&u.proximaManut!==d?.proximaManut){const _=L.find(ea=>String(ea.maquinaId)===String(v)&&(ea.status==="pendente"||ea.status==="agendada"));_?X(_.id,{data:u.proximaManut}):D({maquinaId:v,data:u.proximaManut,tipo:"periodica",status:"pendente",observacoes:"",tecnico:""})}s("Equipamento actualizado com sucesso.","success"),N?.({id:v,...u},"edit")}l()}catch(U){s(U?.message||"Falha ao guardar equipamento/marca.","error",4e3)}};if(!o)return null;const na=async e=>{if(e){if(!e.type?.startsWith("image/")){s("Selecione um ficheiro de imagem válido.","warning");return}P(!0);try{const r=await me(e),v=await he(r),{apiUploadMarcaLogo:k}=await Ea(async()=>{const{apiUploadMarcaLogo:ua}=await import("./apiService-B-7NRfzQ.js");return{apiUploadMarcaLogo:ua}},__vite__mapDeps([0,1,2,3,4,5,6])),u=$.nome.trim()||"marca",U=await k({dataUrl:v,brandName:u});q(ua=>({...ua,logoUrl:U?.url||""})),s("Logotipo carregado e otimizado com sucesso.","success")}catch(r){s(`Falha no upload do logotipo: ${r?.message||"erro desconhecido"}`,"error",4e3)}finally{P(!1)}}};return a.jsx("div",{className:"modal-overlay",onClick:l,children:a.jsxs("div",{className:"modal",onClick:e=>e.stopPropagation(),children:[a.jsx("h2",{children:t==="add"?"Nova máquina":"Editar máquina"}),a.jsxs("form",{onSubmit:ta,children:[a.jsxs("label",{children:["Cliente",a.jsx("select",{required:!0,value:p.clienteNif,onChange:e=>n(r=>({...r,clienteNif:e.target.value})),disabled:!!c,className:c?"readonly":"",children:[...y].sort((e,r)=>(e.nome||"").localeCompare(r.nome||"","pt")).map(e=>a.jsxs("option",{value:e.nif,children:[e.nome," (NIF: ",e.nif,")"]},e.nif))})]}),a.jsxs("label",{children:["Categoria",a.jsx("select",{required:!0,value:p.categoriaId,onChange:e=>{const r=e.target.value,k=f(r)[0]?.id||"",u=ca(I,r)?"anual":"";n(U=>xa(U,{categoriaId:r,subcategoriaId:k,periodicidadeManut:u}))},children:B.map(e=>a.jsxs("option",{value:e.id,children:[e.nome," (",e.intervaloTipo,")"]},e.id))})]}),a.jsxs("label",{children:["Subcategoria (tipo de máquina)",a.jsx("select",{required:!0,value:p.subcategoriaId,onChange:e=>{const r=e.target.value;n(v=>xa(v,{subcategoriaId:r}))},children:T.map(e=>a.jsx("option",{value:e.id,children:e.nome},e.id))})]}),ca(I,p.categoriaId)&&a.jsxs("label",{children:["Periodicidade de manutenção",a.jsxs("select",{required:!0,value:p.periodicidadeManut,onChange:e=>n(r=>({...r,periodicidadeManut:e.target.value})),children:[a.jsx("option",{value:"trimestral",children:"3 meses (trimestral)"}),a.jsx("option",{value:"semestral",children:"6 meses (semestral)"}),a.jsx("option",{value:"anual",children:"1 ano (anual)"})]})]}),!ca(I,p.categoriaId)&&p.categoriaId&&a.jsxs("label",{children:["Periodicidade de manutenção",a.jsxs("select",{value:p.periodicidadeManut,onChange:e=>n(r=>({...r,periodicidadeManut:e.target.value})),children:[a.jsx("option",{value:"",children:"Usar da categoria"}),a.jsx("option",{value:"trimestral",children:"3 meses (trimestral)"}),a.jsx("option",{value:"semestral",children:"6 meses (semestral)"}),a.jsx("option",{value:"anual",children:"1 ano (anual)"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Marca",a.jsxs("select",{value:M,onChange:e=>{const r=e.target.value;if(r==="__new__"){H(!0),n(k=>{const u={...k,marcaId:"",marca:"",marcaLogoUrl:"",marcaCorHex:""};return oa(u.subcategoriaId)?(u.planoManutencaoCompressor??"")===ra?{...u,posicaoKaeser:u.posicaoKaeser??null}:{...u,posicaoKaeser:null}:{...u,posicaoKaeser:null,planoManutencaoCompressor:""}});return}if(!r){H(!1),q({nome:"",logoUrl:"",corHex:"#1a4880"}),n(k=>{const u={...k,marcaId:"",marca:"",marcaLogoUrl:"",marcaCorHex:""};return oa(u.subcategoriaId)?(u.planoManutencaoCompressor??"")===ra?{...u,posicaoKaeser:u.posicaoKaeser??null}:{...u,posicaoKaeser:null}:{...u,posicaoKaeser:null,planoManutencaoCompressor:""}});return}const v=b(r);H(!1),q({nome:"",logoUrl:"",corHex:"#1a4880"}),n(k=>{const u=v?.nome||"",U={...k,marcaId:v?.id!=null&&String(v.id).trim()!==""?String(v.id):"",marca:u,marcaLogoUrl:v?.logoUrl||"",marcaCorHex:v?.corHex||""};return oa(U.subcategoriaId)?(U.planoManutencaoCompressor??"")===ra?{...U,posicaoKaeser:U.posicaoKaeser??null}:{...U,posicaoKaeser:null}:{...U,posicaoKaeser:null,planoManutencaoCompressor:""}})},children:[a.jsx("option",{value:"",children:"— Selecionar marca —"}),R.map(e=>a.jsx("option",{value:da(e),children:e.nome},da(e)||`marca-${(e?.nome??"").toLowerCase()}`)),a.jsx("option",{value:"__new__",children:"+ Nova Marca…"})]}),!z&&!p.marcaId&&a.jsx("small",{className:"text-muted",children:"Selecione uma marca ou crie uma nova."})]}),z&&a.jsxs(a.Fragment,{children:[a.jsxs("label",{children:["Nova marca",a.jsx("input",{value:$.nome,onChange:e=>q(r=>({...r,nome:e.target.value})),placeholder:"Ex: ISTOBAL"})]}),a.jsxs("label",{children:["URL do logotipo da marca",a.jsx("input",{type:"url",value:$.logoUrl,onChange:e=>q(r=>({...r,logoUrl:e.target.value})),placeholder:"https://.../logo-marca.png"})]}),a.jsxs("label",{children:["Cor institucional da marca",a.jsxs("div",{style:{display:"flex",gap:"0.5rem",alignItems:"center"},children:[a.jsx("input",{type:"color",value:$.corHex||"#1a4880",onChange:e=>q(r=>({...r,corHex:e.target.value})),style:{width:"48px",height:"34px",padding:0}}),a.jsx("input",{type:"text",value:$.corHex,onChange:e=>q(r=>({...r,corHex:e.target.value})),placeholder:"#c8102e"})]})]}),a.jsxs("label",{children:["Upload do logotipo (recomendado)",a.jsx("input",{type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",onChange:async e=>{const r=e.target.files?.[0];await na(r),e.target.value=""},disabled:m}),a.jsx("small",{className:"text-muted",children:m?"A otimizar e enviar logotipo...":"A imagem é otimizada automaticamente para documentos."})]}),$.logoUrl&&a.jsxs("div",{className:"form-group",children:[a.jsx("small",{className:"text-muted",children:"Pré-visualização do logotipo:"}),a.jsx("div",{style:{marginTop:"0.35rem",padding:"0.45rem",border:"1px solid #e2e8f0",borderRadius:"6px",background:"#fff"},children:a.jsx("img",{src:$.logoUrl,alt:"Preview logotipo da marca",style:{maxHeight:"42px",maxWidth:"170px",objectFit:"contain"}})})]})]}),a.jsxs("label",{children:["Modelo",a.jsx("input",{value:p.modelo,onChange:e=>n(r=>({...r,modelo:e.target.value})),placeholder:"Ex: EV-4P"})]}),a.jsxs("label",{children:["Nº Série",a.jsx("input",{required:!0,value:p.numeroSerie,onChange:e=>n(r=>({...r,numeroSerie:e.target.value})),placeholder:"Ex: NAV-EV-001"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Ano de fabrico",a.jsx("input",{type:"number",min:1900,max:2100,value:p.anoFabrico,onChange:e=>n(r=>({...r,anoFabrico:e.target.value?Number(e.target.value):""})),placeholder:"Ex: 2022"})]}),a.jsxs("label",{children:["Nº documento de venda",a.jsx("input",{value:p.numeroDocumentoVenda,onChange:e=>n(r=>({...r,numeroDocumentoVenda:e.target.value})),placeholder:"Ex: FV-2022-001"})]})]}),a.jsxs("label",{children:["Próxima data de manutenção",a.jsx("input",{type:"date",required:!0,value:p.proximaManut,onChange:e=>{const r=e.target.value;n(v=>({...v,proximaManut:r})),Q(r)}}),J&&a.jsx("span",{className:"form-aviso-data",children:J})]}),t==="edit"&&(()=>{const e=x.find(k=>String(k.id)===String(p.id));if(!e||!de(e.subcategoriaId))return null;const r=Ua(e),v=!g&&(!!e.ultimaManutencaoData||r!=null);return g?!e.ultimaManutencaoData&&r==null?null:a.jsxs("div",{className:"form-section horas-acumuladas-section",children:[a.jsx("h3",{children:"Contador (atualizado à última manutenção)"}),a.jsxs("p",{className:"horas-info",children:[e.ultimaManutencaoData&&a.jsxs("span",{children:["Última manutenção: ",ma(new Date(e.ultimaManutencaoData+"T12:00:00"),"d MMM yyyy",{locale:ha})]}),e.ultimaManutencaoData&&r!=null&&" · ",r!=null&&a.jsxs("span",{children:["Horas no contador: ",r," h"]})]})]}):a.jsxs("div",{className:"form-section horas-acumuladas-section",children:[a.jsx("h3",{children:"Contador"}),v?a.jsxs(a.Fragment,{children:[a.jsxs("p",{className:"horas-info",children:["Não há manutenções concluídas, mas a ficha na base ainda tem data/horas de intervenções que já não existem. A referência correcta é ",a.jsx("strong",{children:"0 h"})," até voltar a concluir uma visita."]}),G&&a.jsxs("p",{className:"horas-info",style:{marginTop:"0.5rem"},children:[a.jsxs("span",{className:"text-muted",style:{display:"block",marginBottom:"0.35rem"},children:["Valores órfãos na base: ",e.ultimaManutencaoData?`última data ${ma(new Date(e.ultimaManutencaoData+"T12:00:00"),"d MMM yyyy",{locale:ha})}`:"sem data",r!=null?` · ${r} h`:""]}),a.jsx("button",{type:"button",className:"btn secondary btn-sm",onClick:async()=>{if(window.confirm("Limpar na ficha a data da última manutenção e as horas acumuladas? (Recomendado após apagar intervenções antigas.)"))try{await A(e.id,{ultimaManutencaoData:null,horasServicoAcumuladas:null,horasTotaisAcumuladas:null}),s("Contador e data repostos na ficha.","success")}catch(k){s(k?.message||"Não foi possível limpar a ficha.","error",4e3)}},children:"Limpar contador e data na ficha"})]})]}):a.jsxs("p",{className:"horas-info",children:["Sem manutenções ",a.jsx("strong",{children:"concluídas"})," neste equipamento. Referência na ficha: ",a.jsx("strong",{children:"0 h"})," até à primeira intervenção finalizada com relatório."]})]})})(),oa(p.subcategoriaId)&&a.jsxs("div",{className:"form-section",children:[a.jsx("h3",{children:"Escolha o plano de manutenção a aplicar"}),a.jsxs("p",{className:"horas-info",children:["Cada fabricante pode ter o seu plano (Fini, LaPadana, IES, ECF, …). Por agora está disponível o plano ",a.jsx("strong",{children:"KAESER A/B/C/D"}),", com consumíveis por fase e por número de série — importação a partir do PDF do template no ",a.jsx("strong",{children:"Plano de peças"}),"."]}),a.jsxs("label",{children:["Plano de manutenção",a.jsx("select",{value:p.planoManutencaoCompressor??"",onChange:e=>{const r=e.target.value;n(v=>xa(v,{planoManutencaoCompressor:r}))},children:ee.map(e=>a.jsx("option",{value:e.value,children:e.label},e.value||"none"))})]}),p.planoManutencaoCompressor===ra&&a.jsxs(a.Fragment,{children:[a.jsx("p",{className:"horas-info",style:{marginTop:"0.75rem"},children:"Ciclo de 12 anos (referência horas de serviço): A → B → A → C → A → B → A → C → A → B → A → D. A importação PDF preenche os consumíveis das fases A, B, C e D para este número de série."}),a.jsxs("label",{children:["Posição no ciclo A/B/C/D (opcional no cadastro)",a.jsxs("select",{value:p.posicaoKaeser==null?"":String(p.posicaoKaeser),onChange:e=>{const r=e.target.value;n(v=>({...v,posicaoKaeser:r===""?null:Number(r)}))},children:[a.jsx("option",{value:"",children:"A definir na 1ª execução (horas de serviço no compressor)"}),Sa.map((e,r)=>a.jsxs("option",{value:String(r),children:["Ano ",r+1," — Tipo ",e,p.posicaoKaeser!=null&&r===p.posicaoKaeser?" (actual)":""]},r))]})]}),p.posicaoKaeser!=null?a.jsxs("p",{className:"horas-info",style:{marginTop:"0.25rem"},children:[a.jsx("strong",{children:"Próxima manutenção:"})," ",oe((p.posicaoKaeser+1)%Sa.length)]}):a.jsxs("p",{className:"horas-info",style:{marginTop:"0.25rem"},children:["Sem posição fixa: no agendamento não é necessário saber a fase. Na execução, o técnico regista as ",a.jsx("strong",{children:"horas de serviço"})," e confirma o tipo A/B/C/D."]})]})]}),oa(p.subcategoriaId)&&a.jsxs("div",{className:"form-section consumiveis-section",children:[a.jsx("h3",{children:"Consumíveis (manutenção regular)"}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Refª kit manutenção 3000h",a.jsx("input",{value:p.refKitManut3000h,onChange:e=>n(r=>({...r,refKitManut3000h:e.target.value})),placeholder:"Ex: 1900 1466 00"})]}),a.jsxs("label",{children:["Refª kit manutenção 6000h",a.jsx("input",{value:p.refKitManut6000h,onChange:e=>n(r=>({...r,refKitManut6000h:e.target.value})),placeholder:"Ex: 1900 1467 00"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Refª correia",a.jsx("input",{value:p.refCorreia,onChange:e=>n(r=>({...r,refCorreia:e.target.value})),placeholder:"Ex: 1900 1468 00"})]}),a.jsxs("label",{children:["Refª filtro de óleo",a.jsx("input",{value:p.refFiltroOleo,onChange:e=>n(r=>({...r,refFiltroOleo:e.target.value})),placeholder:"Ex: 1900 1469 00"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Refª filtro separador",a.jsx("input",{value:p.refFiltroSeparador,onChange:e=>n(r=>({...r,refFiltroSeparador:e.target.value})),placeholder:"Ex: 1900 1470 00"})]}),a.jsxs("label",{children:["Refª filtro do ar",a.jsx("input",{value:p.refFiltroAr,onChange:e=>n(r=>({...r,refFiltroAr:e.target.value})),placeholder:"Ex: 1900 1471 00"})]})]})]}),oa(p.subcategoriaId)&&a.jsxs("div",{className:"form-section",children:[a.jsx("h3",{children:"Documentação técnica do equipamento"}),a.jsx("p",{className:"horas-info",children:qa}),a.jsx("p",{className:"horas-info",style:{marginTop:"0.5rem"},children:Ha})]}),a.jsxs("div",{className:"form-actions",children:[a.jsx("button",{type:"button",className:"btn secondary",onClick:l,children:"Cancelar"}),a.jsx("button",{type:"submit",className:"btn",children:t==="add"?"Adicionar":"Guardar"})]})]})]})})}const fe="/manut/assets/pdf.worker.min-qwK7q_zL.mjs";function ge(o){const l=["A","B","C","D"],t={A:[],B:[],C:[],D:[]};let c=null;const d=o.split(/\r?\n/);for(const N of d){const y=N.trim();if(!y)continue;if(l.includes(y)&&N.length<5){c=y;continue}const B=y.match(/^(\d{4})\s+/);if(!B||!c)continue;const K=B[1],x=y.slice(4).trim(),w=x.match(/\s+(\d+(?:[.,]\d+)?)\s+([A-ZÇ]{2,4})\s*$/);let f=1,V="PÇ",I=x;w&&(f=parseFloat(w[1].replace(",","."))||1,V=w[2].replace("Ç","Ç"),V==="PC"&&(V="PÇ"),I=x.slice(0,x.length-w[0].length).trim());const F=I.match(/^([\d.]+(?:E\d+)?)\s+(.+)$/s);let j="",A=I;if(F&&F[1].includes(".")){const D=F[1];/^[\d.]+(?:E\d+)?$/.test(D)&&(j=D,A=F[2].trim())}!A||A.length<2||t[c].push({posicao:K,codigoArtigo:j||K,descricao:A,quantidade:f,unidade:V})}return t}async function xe(o){const{PDFParse:l}=await Ea(async()=>{const{PDFParse:d}=await import("./pdf-parse.es-DWQLbnCA.js");return{PDFParse:d}},[]);l.setWorker(fe);const t=new l({data:new Uint8Array(o)}),{text:c}=await t.getText();return t.destroy?.(),c||""}function be(o,l){const t=ge(o||""),c=[];for(const d of["A","B","C","D"])for(const N of t[d]||[])c.push({...N,maquinaId:l,tipoManut:d});return c}async function Va(o,l){const t=await xe(o);return be(t,l)}function Ga(o){const l={A:0,B:0,C:0,D:0};return o.forEach(t=>{const c=t.tipoManut;l[c]!==void 0&&(l[c]+=1)}),l}function Fa(o){return String(o??"").replace(/\s+/g,"").toLowerCase()}function ve(o){if(!o)return[];const l=[],t=(c,d)=>{const N=String(c??"").trim();N&&l.push({id:`ficha-${d}`,codigoArtigo:N,descricao:d,quantidade:1,unidade:"PÇ",fromFicha:!0})};return t(o.refKitManut3000h,"Refª kit manutenção 3000h"),t(o.refKitManut6000h,"Refª kit manutenção 6000h"),t(o.refCorreia,"Refª correia"),t(o.refFiltroOleo,"Refª filtro de óleo"),t(o.refFiltroSeparador,"Refª filtro separador"),t(o.refFiltroAr,"Refª filtro do ar"),l}const ka=[{id:"A",label:"Tipo A",hint:"3.000h / 1 ano"},{id:"B",label:"Tipo B",hint:"6.000h"},{id:"C",label:"Tipo C",hint:"12.000h"},{id:"D",label:"Tipo D",hint:"36.000h"},{id:"periodica",label:"Periódica",hint:"Manutenção periódica standard"}],Ia=["PÇ","TER","L","KG","M","UN"],pa={posicao:"",codigoArtigo:"",descricao:"",quantidade:1,unidade:"PÇ"};function Le({isOpen:o,onClose:l,maquina:t,modoInicial:c=!1}){const{getPecasPlanoByMaquina:d,addPecaPlano:N,replacePecasPlanoMaquina:y,updatePecaPlano:B,removePecaPlano:K,getSubcategoria:x}=ja(),{isAdmin:w}=Ra(),{showToast:f}=wa(),{showGlobalLoading:V,hideGlobalLoading:I}=Ka(),F=C.useRef(null),[j,A]=C.useState("A"),[D,L]=C.useState(pa),[X,s]=C.useState(null),[O,G]=C.useState(pa),[J,E]=C.useState(!1),[aa,Q]=C.useState(null),W=t?x(t.subcategoriaId):null,p=t&&ba(t),n=p&&t&&ya(t.marca),g=p?ka:ka.filter(i=>i.id==="periodica");C.useEffect(()=>{if(!o||!t)return;const i=ba(t)?"A":"periodica";A(i),s(null),L(pa),E(!1),Q(null)},[o,t?.id]),C.useEffect(()=>{g.length>0&&!g.some(i=>i.id===j)&&A(g[0].id)},[t?.id,g,j]);const T=C.useMemo(()=>t?d(t.id,j):[],[t,j,d]),z=C.useMemo(()=>ve(t),[t]),H=C.useMemo(()=>{if(!t)return[];if(j==="periodica"&&p){const i=new Set(z.map(M=>Fa(M.codigoArtigo))),b=T.filter(M=>!i.has(Fa(M.codigoArtigo)));return[...z,...b]}return T},[t,j,p,z,T]),$=C.useMemo(()=>t?d(t.id).length:0,[t,d]);if(!o||!t)return null;const q=i=>{if(i.preventDefault(),!!w){if(!D.codigoArtigo.trim()||!D.descricao.trim()){f("Código de artigo e descrição são obrigatórios.","warning");return}N({...D,maquinaId:t.id,tipoManut:j}),L(pa),f("Peça adicionada ao plano.","success")}},m=i=>{if(w){if(!O.codigoArtigo.trim()||!O.descricao.trim()){f("Código de artigo e descrição são obrigatórios.","warning");return}B(i,O),s(null),f("Peça actualizada.","success")}},P=async i=>{const b=i.target.files?.[0];if(!(!b||!t)){if(i.target.value="",!w){f("A importação do plano a partir de PDF é feita apenas pelo administrador (PC).","warning");return}if(!b.name.toLowerCase().endsWith(".pdf")){f("Seleccione um ficheiro PDF.","warning");return}V();try{const M=await b.arrayBuffer(),ta=await Va(M,t.id);if(ta.length===0){f("Não foi possível extrair peças do PDF. Verifique se o formato é um plano KAESER A/B/C/D.","warning");return}const na=d(t.id).filter(r=>!["A","B","C","D"].includes(r.tipoManut));await y(t.id,[...na,...ta]);const e=Ga(ta);f(`${ta.length} peças importadas (A: ${e.A}, B: ${e.B}, C: ${e.C}, D: ${e.D}).`,"success")}catch(M){ia.error("PecasPlanoModal","importarPdfKaeser",M?.message||"Falha na importação PDF ou na gravação do plano",{maquinaId:t?.id,status:M?.status,stack:M?.stack?.slice(0,400)}),f(`Erro na importação (PDF ou gravação): ${M?.message||"desconhecido"}`,"error",4e3)}finally{I()}}},R=async()=>{if(w)try{const i=d(t.id).filter(b=>b.tipoManut!==j);await y(t.id,i),E(!1),f(`Plano Tipo ${j==="periodica"?"Periódica":j} limpo.`,"success")}catch(i){ia.error("PecasPlanoModal","limparTipoPlano",i?.message||"Falha ao gravar plano",{maquinaId:t?.id,tipoAtivo:j,status:i?.status,stack:i?.stack?.slice(0,400)}),f(i?.message||"Não foi possível limpar o plano no servidor.","error",4e3)}},Y=async()=>{if(w)try{await y(t.id,[]),E(!1),f("Todos os planos desta máquina foram eliminados.","success")}catch(i){ia.error("PecasPlanoModal","limparTodosPlanos",i?.message||"Falha ao gravar plano",{maquinaId:t?.id,status:i?.status,stack:i?.stack?.slice(0,400)}),f(i?.message||"Não foi possível eliminar os planos no servidor.","error",4e3)}};return a.jsx("div",{className:"modal-overlay",onClick:l,children:a.jsxs("div",{className:"modal modal-pecas-plano",onClick:i=>i.stopPropagation(),children:[a.jsxs("div",{className:"modal-pecas-header",children:[a.jsxs("div",{children:[a.jsxs("h2",{children:[a.jsx(Oa,{size:20})," Plano de peças e consumíveis"]}),a.jsxs("p",{className:"modal-pecas-sub",children:[t.marca," ",t.modelo," — Nº Série: ",a.jsx("strong",{children:t.numeroSerie}),W&&a.jsxs(a.Fragment,{children:["  ·  ",W.nome]})]})]}),a.jsx("button",{className:"icon-btn",onClick:l,title:"Fechar",children:a.jsx(Da,{size:20})})]}),a.jsxs("div",{className:"modal-pecas-tabs",children:[g.map(i=>{const b=t?d(t.id,i.id).length:0;return a.jsxs("button",{className:`tab-tipo ${j===i.id?"active":""}`,onClick:()=>{A(i.id),s(null),L(pa)},children:[a.jsx("span",{className:"tab-tipo-label",children:i.label}),a.jsx("span",{className:"tab-tipo-hint",children:i.hint}),b>0&&a.jsx("span",{className:"tab-tipo-count",children:b})]},i.id)}),a.jsx("span",{className:"tab-total",children:$>0?`${$} peças no total`:"Sem peças configuradas"})]}),c&&$===0&&a.jsxs("div",{className:"modal-pecas-boas-vindas",children:[a.jsx("strong",{children:"Equipamento criado!"}),p?w?a.jsxs(a.Fragment,{children:[" Configure o plano de consumíveis deste compressor KAESER (A/B/C/D). Use ",a.jsx("em",{children:'"Importar template para esta máquina"'})," para carregar o plano a partir do PDF (recomendado no PC) e ajuste os artigos ao número de série."]}):a.jsxs(a.Fragment,{children:[" O plano A/B/C/D é importado pelo ",a.jsx("strong",{children:"administrador"})," a partir do PDF no escritório (PC). Aqui pode consultar as peças quando estiverem disponíveis."]}):w?a.jsx(a.Fragment,{children:" Configure os consumíveis recomendados para as manutenções periódicas deste equipamento. Adicione cada artigo manualmente."}):a.jsx(a.Fragment,{children:" Os consumíveis do plano periódico são definidos pelo administrador. Aqui pode consultar a lista."})]}),!w&&n&&j!=="periodica"&&a.jsx("div",{className:"modal-pecas-import modal-pecas-import--readonly",children:a.jsx("span",{className:"import-hint",children:"A importação do plano a partir de PDF é feita apenas pelo administrador (PC), para evitar falhas em tablets. Os dados ficam na base online e aparecem aqui para consulta."})}),w&&n&&j!=="periodica"&&a.jsxs("div",{className:"modal-pecas-import",children:[a.jsx("input",{ref:F,type:"file",accept:".pdf",className:"hidden-file-input",onChange:P,"aria-label":"Seleccionar PDF do plano de manutenção"}),a.jsx("span",{className:"import-hint",children:"Selecione o PDF do plano de manutenção desta máquina (formato KAESER A/B/C/D). Recomendado em PC/desktop."}),a.jsxs("button",{type:"button",className:"btn btn-sm primary",onClick:()=>F.current?.click(),children:[a.jsx(_a,{size:14})," Importar template para esta máquina"]})]}),a.jsxs("div",{className:"modal-pecas-table-wrap",children:[j==="periodica"&&p&&a.jsxs("p",{className:"modal-pecas-ficha-hint",children:["No separador ",a.jsx("strong",{children:"Periódica"}),", as referências da ficha aparecem automaticamente quando preenchidas em"," ",a.jsx("strong",{children:"Editar máquina → Consumíveis (manutenção regular)"}),".",w?" Pode acrescentar mais artigos no plano abaixo.":" Consulte a lista abaixo; alterações ao plano são feitas pelo administrador."]}),H.length===0?a.jsxs("p",{className:"modal-pecas-vazio",children:["Sem peças configuradas para ",a.jsxs("strong",{children:["Tipo ",j==="periodica"?"Periódica":j]}),".",j==="periodica"&&p&&(w?" Preencha as referências na ficha do equipamento ou adicione linhas ao plano.":" As referências da ficha aparecem aqui quando configuradas."),w&&n&&j!=="periodica"&&' Use "Importar template para esta máquina" para carregar o plano a partir de um PDF.',!p&&w&&" Adicione cada consumível manualmente no formulário abaixo.",!p&&!w&&" Consulte a lista abaixo quando o administrador tiver configurado o plano."]}):a.jsxs("table",{className:"tabela-pecas",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Pos."}),a.jsx("th",{children:"Código artigo"}),a.jsx("th",{children:"Descrição"}),a.jsx("th",{children:"Qtd"}),a.jsx("th",{children:"Un."}),a.jsx("th",{})]})}),a.jsx("tbody",{children:H.map(i=>i.fromFicha?a.jsxs("tr",{className:"row-ficha-ref",children:[a.jsx("td",{className:"cell-pos",children:"—"}),a.jsx("td",{className:"cell-code",children:i.codigoArtigo}),a.jsxs("td",{children:[a.jsx("span",{className:"peca-ficha-badge",children:"Ficha"}),i.descricao]}),a.jsx("td",{className:"cell-qty",children:i.quantidade}),a.jsx("td",{className:"cell-un",children:i.unidade}),a.jsx("td",{className:"cell-actions muted",children:"—"})]},i.id):w&&X===i.id?a.jsxs("tr",{className:"row-edit",children:[a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:O.posicao,onChange:b=>G(M=>({...M,posicao:b.target.value})),placeholder:"Ex: 0512",style:{width:"60px"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:O.codigoArtigo,onChange:b=>G(M=>({...M,codigoArtigo:b.target.value})),required:!0,style:{width:"130px"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:O.descricao,onChange:b=>G(M=>({...M,descricao:b.target.value})),required:!0,style:{width:"100%"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",type:"number",min:.01,step:.01,value:O.quantidade,onChange:b=>G(M=>({...M,quantidade:parseFloat(b.target.value)||1})),style:{width:"60px"}})}),a.jsx("td",{children:a.jsx("select",{className:"input-sm",value:O.unidade,onChange:b=>G(M=>({...M,unidade:b.target.value})),children:Ia.map(b=>a.jsx("option",{children:b},b))})}),a.jsxs("td",{className:"cell-actions",children:[a.jsx("button",{type:"button",className:"icon-btn success",onClick:()=>m(i.id),title:"Guardar",children:a.jsx(re,{size:14})}),a.jsx("button",{type:"button",className:"icon-btn",onClick:()=>s(null),title:"Cancelar",children:a.jsx(Da,{size:14})})]})]},i.id):a.jsxs("tr",{children:[a.jsx("td",{className:"cell-pos",children:i.posicao||"—"}),a.jsx("td",{className:"cell-code",children:i.codigoArtigo}),a.jsx("td",{children:i.descricao}),a.jsx("td",{className:"cell-qty",children:i.quantidade}),a.jsx("td",{className:"cell-un",children:i.unidade}),a.jsx("td",{className:"cell-actions",children:w?a.jsxs(a.Fragment,{children:[a.jsx("button",{type:"button",className:"icon-btn secondary",onClick:()=>{s(i.id),G({posicao:i.posicao||"",codigoArtigo:i.codigoArtigo,descricao:i.descricao,quantidade:i.quantidade,unidade:i.unidade})},title:"Editar",children:a.jsx(se,{size:14})}),aa===i.id?a.jsxs(a.Fragment,{children:[a.jsx("button",{type:"button",className:"icon-btn danger",onClick:()=>{K(i.id),Q(null),f("Peça removida.","success")},title:"Confirmar",children:"Sim"}),a.jsx("button",{type:"button",className:"icon-btn secondary",onClick:()=>Q(null),title:"Cancelar",children:"Não"})]}):a.jsx("button",{type:"button",className:"icon-btn danger",onClick:()=>Q(i.id),title:"Remover",children:a.jsx(va,{size:14})})]}):a.jsx("span",{className:"muted",children:"—"})})]},i.id))})]})]}),w&&a.jsxs("form",{className:"modal-pecas-add-row",onSubmit:q,children:[a.jsx("input",{className:"input-sm",placeholder:"Posição",value:D.posicao,onChange:i=>L(b=>({...b,posicao:i.target.value})),style:{width:"65px",flexShrink:0}}),a.jsx("input",{className:"input-sm",placeholder:"Código artigo *",value:D.codigoArtigo,onChange:i=>L(b=>({...b,codigoArtigo:i.target.value})),style:{width:"135px",flexShrink:0}}),a.jsx("input",{className:"input-sm",placeholder:"Descrição *",value:D.descricao,onChange:i=>L(b=>({...b,descricao:i.target.value})),style:{flex:1}}),a.jsx("input",{className:"input-sm",type:"number",min:.01,step:.01,value:D.quantidade,onChange:i=>L(b=>({...b,quantidade:parseFloat(i.target.value)||1})),style:{width:"60px",flexShrink:0}}),a.jsx("select",{className:"input-sm",value:D.unidade,onChange:i=>L(b=>({...b,unidade:i.target.value})),style:{width:"70px",flexShrink:0},children:Ia.map(i=>a.jsx("option",{children:i},i))}),a.jsxs("button",{type:"submit",className:"btn btn-sm primary",style:{flexShrink:0},children:[a.jsx(Ba,{size:14})," Adicionar"]})]}),a.jsx("div",{className:"modal-pecas-footer form-actions",children:J?a.jsxs("div",{className:"confirmar-limpar",children:[a.jsx("button",{type:"button",className:"btn btn-sm secondary",onClick:()=>E(!1),children:"Cancelar"}),a.jsx("span",{className:"confirmar-limpar-label",children:"Eliminar:"}),a.jsxs("button",{type:"button",className:"btn btn-sm danger",onClick:R,children:["Só Tipo ",j==="periodica"?"Periódica":j," (",T.length,")"]}),a.jsxs("button",{type:"button",className:"btn btn-sm danger",onClick:Y,children:["Toda a máquina (",$,")"]})]}):a.jsxs(a.Fragment,{children:[w&&$>0&&a.jsxs("button",{type:"button",className:"btn btn-sm btn-outline-muted",onClick:()=>E(!0),children:[a.jsx(va,{size:13})," Limpar plano…"]}),a.jsx("button",{type:"button",className:"btn secondary modal-pecas-fechar",onClick:l,children:"Fechar"})]})})]})})}const je=8*1024*1024;function we(o){return new Promise((l,t)=>{const c=new FileReader;c.onload=()=>l(String(c.result||"")),c.onerror=()=>t(new Error("Falha ao ler o ficheiro")),c.readAsDataURL(o)})}function ye(o){if(!o||typeof o!="string")return null;try{const l=new URL(o).pathname;return l.startsWith("/uploads/machine-docs/")?l.split("?")[0]:null}catch{const l=o.trim();return l.startsWith("/uploads/machine-docs/")?l.split("?")[0]:null}}function Oe({isOpen:o,onClose:l,maquina:t,onOpenPlanoPecas:c}){const{maquinas:d,manutencoes:N,addDocumentoMaquina:y,removeDocumentoMaquina:B,updateMaquina:K,getPecasPlanoByMaquina:x,replacePecasPlanoMaquina:w}=ja(),{showToast:f}=wa(),{showGlobalLoading:V,hideGlobalLoading:I}=Ka(),{isAdmin:F}=Ra(),j=C.useRef(null),[A,D]=C.useState({tipo:"manual_utilizador",titulo:"",url:""}),[L,X]=C.useState(null),s=d.find(n=>String(n.id)===String(t?.id))??t,O=C.useMemo(()=>s?.id?N.some(n=>String(n.maquinaId)===String(s.id)&&n.status==="concluida"):!1,[N,s?.id]),G=!!s&&ba(s)&&ya(s.marca),J=C.useMemo(()=>(s?.documentos??[]).find(n=>n.tipo==="plano_manutencao"),[s?.documentos]);if(C.useEffect(()=>{if(!o||!s)return;const n=$a.includes(s.subcategoriaId);D(g=>({...g,tipo:n?"plano_manutencao":"manual_utilizador"}))},[o,s?.id,s?.subcategoriaId]),!o)return null;const E=s?s.documentos??[]:[],aa=n=>Aa.find(g=>g.id===n)?.label??n,Q=async n=>{if(n.preventDefault(),!A.titulo.trim()||!A.url.trim()){f("Preencha título e URL para adicionar por link.","warning");return}const g=ga(A.url.trim());if(g==="#"){f("URL inválida. Use um link que comece por https:// ou http://","warning");return}(await y(s.id,{tipo:A.tipo,titulo:A.titulo.trim(),url:g}))?.ok?(f("Documento associado ao equipamento.","success"),D(z=>({...z,titulo:"",url:""}))):f("Não foi possível associar o documento. Verifique a ligação ou tente de novo.","error",4e3)},W=async n=>{const g=n.target.files?.[0];if(n.target.value="",!g||!s?.id)return;const T=g.name||"";if(!T.toLowerCase().endsWith(".pdf")&&g.type!=="application/pdf"){f("Seleccione um ficheiro PDF.","warning");return}if(g.size>je){f("PDF demasiado grande (máx. 8 MB).","warning");return}V();try{const z=await we(g),H=(s.documentos??[]).find(Y=>Y.tipo===A.tipo&&Y.uploadFileName===T&&Number(Y.uploadFileSize)===g.size),$=H?.url?ye(H.url):null,m=(await ne({dataUrl:z,maquinaId:s.id,...$?{replacePath:$}:{}}))?.url;if(!m){f("Resposta do servidor sem URL do PDF.","error",4e3);return}const P=(A.titulo.trim()||T.replace(/\.pdf$/i,"")).slice(0,200),R=await y(s.id,{tipo:A.tipo,titulo:P,url:m,uploadFileName:T,uploadFileSize:g.size});R?.ok?(f(R.replaced?"PDF actualizado (substituiu o envio anterior com o mesmo nome e tamanho).":"PDF carregado e associado ao equipamento.","success"),D(Y=>({...Y,titulo:""}))):f("O PDF foi enviado mas não ficou guardado na ficha. Verifique a ligação ou tente de novo.","error",4500)}catch(z){ia.error("DocumentacaoModal","uploadPdf",z?.message||String(z)),f(z?.message||"Falha ao enviar PDF.","error",4e3)}finally{I()}},p=async()=>{if(!F||!s?.id||!J?.url){f("É necessário um documento «Plano de manutenção (PDF)» na lista abaixo.","warning");return}const n=ga(J.url);if(n==="#"){f("URL do PDF inválida.","warning");return}V();try{const g=await fetch(n,{credentials:"same-origin",mode:"cors"});if(!g.ok){f(`Não foi possível obter o PDF (${g.status}). Abra o documento num separador e importe pelo plano de peças, se preferir.`,"error",4500);return}const T=await g.arrayBuffer(),z=await Va(T,s.id);if(z.length===0){f("Não foi possível extrair peças deste PDF. Confirme que é um plano KAESER A/B/C/D ou importe a partir do ficheiro original no plano de peças.","warning",4500);return}const H=x(s.id).filter(q=>!["A","B","C","D"].includes(q.tipoManut));await w(s.id,[...H,...z]);const $=Ga(z);f(`Importação concluída: ${z.length} linhas (A: ${$.A}, B: ${$.B}, C: ${$.C}, D: ${$.D}).`,"success",5e3),ia.action("DocumentacaoModal","importarPecasDoPdfFicha","Consumíveis KAESER importados do PDF na ficha",{maquinaId:s.id,linhas:z.length,porTipo:$})}catch(g){ia.error("DocumentacaoModal","importarPecasDoPdfFicha",g?.message||String(g),{maquinaId:s?.id,stack:g?.stack?.slice(0,400)}),f(g?.message?.includes("Failed to fetch")||g?.name==="TypeError"?"Não foi possível ler o PDF (rede ou permissões). Use «Abrir plano de peças» e importe o ficheiro localmente.":g?.message||"Falha ao importar consumíveis.","error",5e3)}finally{I()}};return a.jsx("div",{className:"modal-overlay",onClick:l,children:a.jsxs("div",{className:"modal modal-documentacao",onClick:n=>n.stopPropagation(),children:[a.jsxs("h2",{children:["Documentação — ",s?.marca," ",s?.modelo]}),a.jsx("p",{className:"modal-hint",children:qa}),$a.includes(s?.subcategoriaId)&&a.jsx("p",{className:"modal-hint",style:{marginTop:"0.5rem"},children:Ha}),G&&a.jsxs("div",{className:"consumiveis-card doc-plano-kaeser-card",children:[a.jsx("h4",{children:"Plano de peças KAESER (A / B / C / D)"}),a.jsx("p",{className:"modal-hint",style:{marginTop:0},children:"Os consumíveis por fase ficam na base após importação. Pode abrir o gestor de plano aqui ou importar directamente a partir do PDF «Plano de manutenção» já associado a este equipamento (só administrador)."}),a.jsxs("div",{className:"form-row doc-kaeser-actions",style:{flexWrap:"wrap",gap:"0.5rem",marginTop:"0.65rem"},children:[typeof c=="function"&&a.jsxs("button",{type:"button",className:"btn secondary btn-sm",onClick:()=>c(s),children:[a.jsx(Oa,{size:14,"aria-hidden":!0})," Abrir plano de peças (A/B/C/D)"]}),F&&a.jsx("button",{type:"button",className:"btn primary btn-sm",onClick:p,disabled:!J,title:J?"Lê o PDF do plano na lista e grava consumíveis A–D na base":"Associe primeiro um PDF como «Plano de manutenção (PDF)»",children:"Importar consumíveis do PDF já na ficha"})]}),!F&&typeof c=="function"&&a.jsx("p",{className:"text-muted",style:{fontSize:"0.85rem",marginBottom:0,marginTop:"0.5rem"},children:"A importação a partir de PDF é feita pelo administrador. Use «Abrir plano de peças» para consultar as linhas já gravadas."})]}),Ta.includes(s?.subcategoriaId)&&(()=>{if(!s)return null;const n=Ua(s),g=!O&&(!!s.ultimaManutencaoData||n!=null);return O?!s.ultimaManutencaoData&&n==null?null:a.jsxs("div",{className:"consumiveis-card",children:[a.jsx("h4",{children:"Contador (à data da última manutenção)"}),a.jsxs("div",{className:"consumiveis-grid",children:[s.ultimaManutencaoData&&a.jsxs("span",{children:[a.jsx("strong",{children:"Última manut.:"})," ",ma(new Date(s.ultimaManutencaoData+"T12:00:00"),"d MMM yyyy",{locale:ha})]}),n!=null&&a.jsxs("span",{children:[a.jsx("strong",{children:"Horas no contador:"})," ",n," h"]})]})]}):a.jsxs("div",{className:"consumiveis-card",children:[a.jsx("h4",{children:"Contador"}),g?a.jsxs(a.Fragment,{children:[a.jsxs("p",{className:"modal-hint",style:{margin:0},children:["Não há manutenções concluídas, mas a ficha na base ainda tem data ou horas antigas. A referência correcta é ",a.jsx("strong",{children:"0 h"})," até voltar a concluir uma visita."]}),F&&a.jsxs("p",{className:"modal-hint",style:{marginTop:"0.5rem",marginBottom:0},children:[a.jsxs("span",{className:"text-muted",style:{display:"block",marginBottom:"0.35rem"},children:["Valores órfãos: ",s.ultimaManutencaoData?`última data ${ma(new Date(s.ultimaManutencaoData+"T12:00:00"),"d MMM yyyy",{locale:ha})}`:"sem data",n!=null?` · ${n} h`:""]}),a.jsx("button",{type:"button",className:"btn secondary btn-sm",onClick:async()=>{if(window.confirm("Limpar na ficha a data da última manutenção e as horas acumuladas? (Recomendado após apagar intervenções antigas.)"))try{await K(s.id,{ultimaManutencaoData:null,horasServicoAcumuladas:null,horasTotaisAcumuladas:null}),f("Contador e data repostos na ficha.","success")}catch(T){f(T?.message||"Não foi possível limpar a ficha.","error",4e3)}},children:"Limpar contador e data na ficha"})]})]}):a.jsxs("p",{className:"modal-hint",style:{margin:0},children:["Sem manutenções ",a.jsx("strong",{children:"concluídas"})," neste equipamento. Referência: ",a.jsx("strong",{children:"0 h"})," até à primeira intervenção finalizada com relatório."]})]})})(),["sub5","sub14"].includes(s?.subcategoriaId)&&(s?.refKitManut3000h||s?.refKitManut6000h||s?.refCorreia||s?.refFiltroOleo||s?.refFiltroSeparador||s?.refFiltroAr)&&a.jsxs("div",{className:"consumiveis-card",children:[a.jsx("h4",{children:"Consumíveis"}),a.jsxs("div",{className:"consumiveis-grid",children:[s.refKitManut3000h&&a.jsxs("span",{children:[a.jsx("strong",{children:"Kit 3000h:"})," ",s.refKitManut3000h]}),s.refKitManut6000h&&a.jsxs("span",{children:[a.jsx("strong",{children:"Kit 6000h:"})," ",s.refKitManut6000h]}),s.refCorreia&&a.jsxs("span",{children:[a.jsx("strong",{children:"Correia:"})," ",s.refCorreia]}),s.refFiltroOleo&&a.jsxs("span",{children:[a.jsx("strong",{children:"Filtro óleo:"})," ",s.refFiltroOleo]}),s.refFiltroSeparador&&a.jsxs("span",{children:[a.jsx("strong",{children:"Filtro separador:"})," ",s.refFiltroSeparador]}),s.refFiltroAr&&a.jsxs("span",{children:[a.jsx("strong",{children:"Filtro ar:"})," ",s.refFiltroAr]})]})]}),a.jsxs("div",{className:"doc-lista",children:[E.map(n=>a.jsxs("div",{className:"doc-item",children:[a.jsxs("div",{className:"doc-item-info",children:[a.jsx("span",{className:"doc-tipo",children:aa(n.tipo)}),a.jsx("span",{className:"doc-titulo",children:n.titulo})]}),a.jsxs("div",{className:"doc-item-actions",children:[a.jsx("a",{href:ga(n.url),target:"_blank",rel:"noopener noreferrer",className:"icon-btn secondary",title:"Abrir",children:a.jsx(ie,{size:16})}),F&&L===n.id?a.jsxs(a.Fragment,{children:[a.jsx("button",{type:"button",className:"icon-btn danger",onClick:async()=>{X(null);const g=await B(s.id,n.id);f(g?.ok?"Documento removido.":"Não foi possível remover o documento.",g?.ok?"success":"error",4e3)},title:"Confirmar",children:"Sim"}),a.jsx("button",{type:"button",className:"icon-btn secondary",onClick:()=>X(null),title:"Cancelar",children:"Não"})]}):F&&a.jsx("button",{type:"button",className:"icon-btn danger",onClick:()=>X(n.id),title:"Remover",children:a.jsx(va,{size:16})})]})]},n.id)),E.length===0&&a.jsx("p",{className:"doc-empty",children:"Nenhum documento associado."})]}),F&&a.jsxs("form",{onSubmit:Q,className:"form-add-doc",children:[a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Tipo",a.jsx("select",{value:A.tipo,onChange:n=>D(g=>({...g,tipo:n.target.value})),children:Aa.map(n=>a.jsx("option",{value:n.id,children:n.label},n.id))})]}),a.jsxs("label",{style:{flex:1},children:["Título",a.jsx("input",{value:A.titulo,onChange:n=>D(g=>({...g,titulo:n.target.value})),placeholder:"Ex: Plano 3000 h / Manual GA-22"})]})]}),a.jsx("input",{ref:j,type:"file",accept:".pdf,application/pdf",style:{display:"none"},onChange:W}),a.jsxs("div",{className:"form-row doc-upload-row",style:{alignItems:"flex-end",gap:"0.75rem",flexWrap:"wrap"},children:[a.jsxs("button",{type:"button",className:"btn secondary btn-add-doc",onClick:()=>j.current?.click(),children:[a.jsx(_a,{size:16})," Importar PDF (servidor)"]}),a.jsx("span",{className:"text-muted",style:{fontSize:"0.85rem"},children:"Máx. 8 MB · usa o tipo seleccionado acima"})]}),a.jsxs("label",{children:["Ou URL (link para PDF alojado noutro sítio)",a.jsx("input",{type:"url",value:A.url,onChange:n=>D(g=>({...g,url:n.target.value})),placeholder:"https://..."})]}),a.jsxs("button",{type:"submit",className:"btn-add-doc",children:[a.jsx(Ba,{size:16})," Adicionar por URL"]})]}),a.jsx("div",{className:"form-actions",children:a.jsx("button",{type:"button",className:"btn secondary",onClick:l,children:"Fechar"})})]})})}const Z=La,S={azulNavel:"#1a4880",azulMedio:"#2d6eb5",vermelho:"#b91c1c",verde:"#15803d",amarelo:"#a16207",texto:"#111827",muted:"#374151",cinza:"#f3f4f6",cinzaBorda:"#b0c4de",branco:"#ffffff",bgAlt:"#f9fafb",bordaLeve:"#e5e7eb"},h={corpo:"10.5px",pequeno:"9.5px",label:"9px",micro:"8.5px",titulo:"11.5px",numSerie:"14px"};function Ce(o=S.azulNavel,l="rgba(26,72,128,0.12)"){return`
/* ── Página A4, margens de impressão ── */
@page { size: A4 portrait; margin: 8mm 11mm }
* { box-sizing: border-box; margin: 0; padding: 0 }
body {
  font-family: 'Segoe UI', Arial, sans-serif;
  font-size: ${h.corpo};
  line-height: 1.42;
  color: var(--texto);
  background: var(--branco);
  padding: 0;
}

/* ── Paleta via custom properties ── */
:root {
  --azul: ${o};
  --azul-med: ${o};
  --azul-claro: ${l};
  --cinza: ${S.cinza};
  --borda: ${S.cinzaBorda};
  --borda-leve: ${S.bordaLeve};
  --texto: ${S.texto};
  --muted: ${S.muted};
  --verde: ${S.verde};
  --vermelho: ${S.vermelho};
  --amarelo: ${S.amarelo};
  --acento: ${o};
  --branco: ${S.branco};
  --bg-alt: ${S.bgAlt};
}

/* ── Quebras de página ── */
section { margin-bottom: 10px; page-break-inside: avoid }
.section-can-break { page-break-inside: auto }
.page-break-before { page-break-before: always }
.no-break { page-break-inside: avoid }

/* ── Cabeçalho ── */
.rpt-header {
  display: flex; align-items: flex-start; justify-content: space-between;
  gap: 14px; padding-bottom: 10px;
  border-bottom: 3px solid var(--azul);
}
.rpt-logos { display: flex; align-items: center; gap: 12px }
.rpt-logo img, .rpt-logo-marca img {
  max-height: 44px; max-width: 180px; object-fit: contain; display: block;
}
.rpt-logo-fallback { font-size: 1.2em; font-weight: 800; color: var(--azul) }
.rpt-empresa {
  text-align: left; font-size: ${h.pequeno}; line-height: 1.55; color: var(--texto);
}
.rpt-empresa strong { font-size: ${h.corpo}; color: var(--azul) }
.rpt-empresa a { color: var(--azul); text-decoration: none; font-weight: 600 }

/* ── Barra de título ── */
.rpt-titulo-bar {
  display: flex; align-items: center; justify-content: space-between;
  background: var(--azul); color: var(--branco);
  padding: 7px 12px; margin: 8px 0 0; border-radius: 3px;
}
.rpt-titulo-bar h1 {
  font-size: ${h.titulo}; font-weight: 800;
  letter-spacing: .08em; text-transform: uppercase;
}
.rpt-num-wrap { text-align: right }
.rpt-num-label {
  font-size: ${h.micro}; color: rgba(255,255,255,.85); text-transform: uppercase;
  letter-spacing: .08em; display: block;
}
.rpt-num {
  font-size: ${h.numSerie}; font-weight: 800;
  letter-spacing: .04em; font-family: 'Courier New', monospace;
}
.rpt-acento {
  height: 2px; background: linear-gradient(90deg, var(--acento), var(--azul-med));
  margin-bottom: 8px; border-radius: 0 0 2px 2px;
}

/* ── Secções genéricas ── */
.rpt-section-title {
  font-size: ${h.label}; font-weight: 700; text-transform: uppercase;
  letter-spacing: .1em; color: var(--azul);
  border-bottom: 1.5px solid var(--azul); padding-bottom: 3px; margin-bottom: 6px;
}

/* ── Grid de dados (2 colunas) ── */
.rpt-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 1px 10px }
.rpt-field { padding: 2.5px 0; border-bottom: 1px solid var(--borda-leve) }
.rpt-field:last-child { border-bottom: none }
.rpt-label {
  font-size: ${h.label}; font-weight: 600; text-transform: uppercase;
  letter-spacing: .05em; color: var(--muted); display: block; margin-bottom: 1px;
}
.rpt-value { font-size: ${h.corpo}; color: var(--texto) }
.rpt-value--bold { font-weight: 700 }
.rpt-value--mono { font-family: 'Courier New', monospace; letter-spacing: .03em }
.rpt-value--accent { color: var(--azul); font-weight: 600 }
.rpt-value--muted { color: var(--muted) }
.rpt-field--full { grid-column: 1 / -1 }

/* ── Bloco equipamento destacado ── */
.rpt-equip-band {
  background: var(--azul-claro); border: 1.5px solid var(--borda);
  border-top: 3px solid var(--azul);
  border-radius: 4px; padding: 8px 10px; margin-bottom: 8px;
}
.rpt-equip-grid {
  display: grid; grid-template-columns: 1fr 1fr 1fr; gap: 3px 12px;
}
.rpt-equip-item .rpt-label { font-size: ${h.label} }
.rpt-equip-item .rpt-value { font-size: ${h.corpo}; font-weight: 700; color: var(--texto) }

/* ── Notas ── */
.rpt-notas {
  background: var(--azul-claro); border-left: 3px solid var(--azul);
  padding: 7px 10px; border-radius: 0 4px 4px 0;
  font-size: ${h.corpo}; color: var(--texto); line-height: 1.5;
}

/* ── Fotos — layout adaptativo por quantidade ── */
.rpt-fotos-section { margin-top: 8px }
.rpt-fotos-row {
  display: flex; gap: 10px; margin-bottom: 10px;
  page-break-inside: avoid;
}
.rpt-foto-item {
  flex: 1; min-width: 0; text-align: center;
}
.rpt-foto-item img {
  width: 100%; max-height: 180px; object-fit: contain;
  border-radius: 4px; border: 1.5px solid var(--borda);
  background: var(--cinza); display: block;
}
.rpt-foto-caption {
  font-size: ${h.label}; color: var(--texto);
  margin-top: 3px; text-align: center; font-weight: 500;
}
/* 1 foto: centrada, max 60% largura */
.rpt-fotos-row--single .rpt-foto-item { flex: 0 1 60%; margin: 0 auto }
.rpt-fotos-row--single .rpt-foto-item img { max-height: 220px }
/* 2 fotos: 50% cada */
.rpt-fotos-row--pair .rpt-foto-item { flex: 0 1 50% }
.rpt-fotos-row--pair .rpt-foto-item img { max-height: 200px }
/* 3 fotos: terços */
.rpt-fotos-row--triple .rpt-foto-item { flex: 0 1 33.33% }
.rpt-fotos-row--triple .rpt-foto-item img { max-height: 170px }
/* 4 fotos: quarta parte da largura (A4 / impressão) */
.rpt-fotos-row--quad .rpt-foto-item { flex: 0 1 25% }
.rpt-fotos-row--quad .rpt-foto-item img { max-height: 150px }

/* ── Checklist ── */
.checklist-1col { width: 100% }
.checklist-2col { display: grid; grid-template-columns: 1fr 1fr; gap: 0 10px }
.checklist-table { width: 100%; border-collapse: collapse; font-size: ${h.pequeno} }
.checklist-table tr:nth-child(even) { background: var(--cinza) }
.checklist-table td {
  padding: 2.8px 4px; border-bottom: 1px solid var(--borda-leve); vertical-align: top;
}
.checklist-table td.cl-num {
  width: 1.6em; color: var(--muted); font-size: ${h.label};
  padding-left: 2px; white-space: nowrap;
}
.checklist-table td.cl-texto { padding-right: 6px }
.checklist-table td.cl-badge { width: 32px; text-align: center; padding-right: 2px; white-space: nowrap }
.badge-sim {
  background: #dcfce7; color: #14532d;
  padding: 1.5px 6px; border-radius: 8px; font-size: ${h.label}; font-weight: 700;
  border: 1px solid #86efac;
}
.badge-nao {
  background: #fee2e2; color: #7f1d1d;
  padding: 1.5px 6px; border-radius: 8px; font-size: ${h.label}; font-weight: 700;
  border: 1px solid #fca5a5;
}
.badge-nd { color: var(--muted); font-size: ${h.pequeno} }

/* ── Peças e consumíveis ── */
.pecas-table { width: 100%; border-collapse: collapse; font-size: ${h.pequeno} }
.pecas-table thead { display: table-header-group }
.pecas-table th {
  background: var(--azul); color: var(--branco);
  padding: 4px 6px; text-align: left;
  font-size: ${h.label}; text-transform: uppercase; letter-spacing: .04em;
}
.pecas-table td {
  padding: 3px 6px; border-bottom: 1px solid var(--borda-leve); vertical-align: middle;
}
.pecas-table tr.row-usado td { background: #f0fdf4 }
.pecas-table tr.row-nao-usado td { background: var(--bg-alt); color: #6b7280 }
.pecas-table tr.row-nao-usado .cell-desc { text-decoration: line-through }
.pecas-table .cell-status { width: 20px; text-align: center; font-size: ${h.titulo}; font-weight: 700 }
.pecas-table .cell-pos { width: 46px; color: var(--muted); font-family: 'Courier New', monospace; font-size: ${h.label} }
.pecas-table .cell-code { width: 118px; font-family: 'Courier New', monospace; font-size: ${h.pequeno} }
.pecas-table .cell-qty { width: 36px; text-align: right; font-weight: 600 }
.pecas-table .cell-un { width: 34px; color: var(--muted); font-size: ${h.label} }
.pecas-group-row td {
  background: var(--cinza) !important;
  font-size: ${h.label}; font-weight: 700; text-transform: uppercase;
  letter-spacing: .06em; color: var(--muted); padding: 3px 6px;
  page-break-after: avoid;
}
.pecas-group-usado td { border-left: 3px solid var(--verde); color: var(--verde) }
.pecas-group-nao-usado td { border-left: 3px solid #6b7280 }
.pecas-resumo {
  display: flex; gap: 16px; padding: 4px 6px;
  background: var(--cinza); border-top: 1.5px solid var(--borda); font-size: ${h.pequeno};
}
.pecas-resumo-item { display: flex; align-items: center; gap: 4px }
.pecas-resumo-dot { width: 10px; height: 10px; border-radius: 50%; flex-shrink: 0 }
.pecas-resumo-dot.verde { background: var(--verde) }
.pecas-resumo-dot.cinza { background: #6b7280 }

/* ═══════════════════════════════════════════════════════════════════════════
 * PÁGINA DO CLIENTE — assinaturas, declaração e próximas manutenções
 * Forçar sempre nova página; nunca cortar blocos internos.
 * ═══════════════════════════════════════════════════════════════════════════ */
.rpt-pagina-cliente {
  page-break-before: always;
}
.rpt-pagina-cliente-titulo {
  font-size: 12px; font-weight: 800; text-transform: uppercase;
  letter-spacing: .1em; color: var(--branco);
  background: var(--azul); padding: 6px 10px; border-radius: 3px;
  margin-bottom: 12px;
}

/* ── Assinatura lado a lado ── */
.rpt-assinaturas-dual {
  display: grid; grid-template-columns: 1fr 1fr; gap: 12px;
  margin-top: 8px; overflow: hidden;
}
.rpt-assinatura-col {
  background: var(--branco); border: 1.5px solid var(--borda);
  border-top: 3px solid var(--azul);
  border-radius: 4px; padding: 10px 12px;
  box-sizing: border-box;
}
.rpt-assinatura-nome {
  font-size: ${h.corpo}; font-weight: 700; color: var(--texto);
  margin-bottom: 3px;
}
.rpt-assinatura-detalhe { font-size: ${h.label}; color: var(--muted) }
.rpt-assinatura-img img {
  max-width: 100%; max-height: 80px;
  width: auto; height: auto;
  border: 1px solid var(--borda); border-radius: 3px;
  margin-top: 8px; background: var(--branco); display: block;
}
.rpt-assinatura-placeholder {
  height: 70px; border-bottom: 1.5px dashed var(--borda);
  margin-top: 8px; margin-bottom: 4px;
}

/* ── Declaração do cliente ── */
.rpt-declaracao-box {
  background: var(--cinza); border: 1.5px solid var(--borda);
  border-left: 3px solid var(--azul);
  border-radius: 4px; padding: 10px 12px; margin-top: 12px;
}
.rpt-declaracao-titulo {
  font-size: ${h.label}; font-weight: 700; text-transform: uppercase;
  letter-spacing: .06em; color: var(--azul); margin-bottom: 5px;
}
.rpt-declaracao-texto {
  font-size: ${h.pequeno}; color: var(--texto); line-height: 1.6;
}

/* ── Tabela próximas manutenções ── */
.rpt-proximas-box { margin-top: 14px }
.proximas-table { width: 100%; border-collapse: collapse; margin-bottom: 6px }
.proximas-table th {
  background: var(--azul); color: var(--branco);
  padding: 5px 8px; font-size: ${h.label}; text-transform: uppercase;
  letter-spacing: .04em; text-align: left; border: 1px solid var(--azul);
}
.proximas-table th:first-child { text-align: center; width: 30px }
.proximas-table td {
  padding: 4px 8px; font-size: ${h.corpo}; color: var(--texto);
  border: 1px solid var(--borda-leve);
}
.proximas-table tr:nth-child(even) { background: var(--cinza) }
.proximas-nota {
  font-size: ${h.pequeno}; color: var(--texto);
  margin: 4px 0 8px; line-height: 1.55;
  font-style: italic;
}

/* ── Último envio ── */
.rpt-ultimo-envio { font-size: ${h.label}; color: var(--muted); margin-bottom: 6px; font-style: italic }

/* ── Rodapé ── */
.rpt-footer {
  margin-top: 10px; padding-top: 7px;
  border-top: 2px solid var(--azul);
  display: flex; justify-content: space-between; align-items: center;
  font-size: ${h.label}; color: var(--texto);
}
`}function Ne(o,l="",t=""){return`
<header class="rpt-header" style="display:flex;align-items:flex-start;justify-content:space-between;gap:14px;padding-bottom:10px;border-bottom:3px solid ${S.azulNavel}">
  <div class="rpt-logos" style="display:flex;align-items:center;gap:12px">
    <div class="rpt-logo">
      <img src="${o}" alt="Navel" width="160" height="44"
        style="max-height:44px;max-width:160px;width:auto;height:auto;display:block;object-fit:contain"
        onerror="this.parentNode.innerHTML='<span class=rpt-logo-fallback style=font-size:1.2em;font-weight:800;color:${S.azulNavel}>Navel</span>'">
    </div>
    ${l?`
    <div class="rpt-logo-marca">
      <img src="${l}" alt="${Z(t)}" width="120" height="40"
        style="max-height:40px;max-width:120px;width:auto;height:auto;display:block;object-fit:contain"
        onerror="this.parentNode.style.display='none'">
    </div>`:""}
  </div>
  <div class="rpt-empresa" style="text-align:right;font-size:${h.pequeno};line-height:1.55;color:${S.texto}">
    <strong style="font-size:${h.corpo};color:${S.azulNavel}">${Z(sa.nome)}</strong><br>
    ${Z(sa.localidade)} &bull; <a href="https://${sa.web}" style="color:${S.azulNavel};text-decoration:none;font-weight:600">${sa.web}</a><br>
    ${Z(sa.regiao)}
  </div>
</header>`}function $e(o,l,t,c=""){return`
<div class="rpt-titulo-bar" style="display:flex;align-items:center;justify-content:space-between;background:${S.azulNavel};color:#fff;padding:7px 12px;margin:8px 0 0;border-radius:3px">
  <h1 style="font-size:${h.titulo};font-weight:800;letter-spacing:.08em;text-transform:uppercase;margin:0;color:#fff">${Z(o)}${c||""}</h1>
  <div class="rpt-num-wrap" style="text-align:right">
    <span class="rpt-num-label" style="font-size:${h.micro};color:rgba(255,255,255,.85);text-transform:uppercase;letter-spacing:.08em;display:block">${Z(l)}</span>
    <span class="rpt-num" style="font-size:${h.numSerie};font-weight:800;letter-spacing:.04em;font-family:'Courier New',monospace;color:#fff">${Z(t)}</span>
  </div>
</div>
<div class="rpt-acento" style="height:2px;background:linear-gradient(90deg,${S.azulNavel},${S.azulMedio});margin-bottom:8px;border-radius:0 0 2px 2px"></div>`}function Ae(o="",l="",t=""){const c=l?`${Z(Ma)} · ${Z(l)}`:Z(Ma),d=t||`${Z(sa.web)} &nbsp;|&nbsp; ${Z(sa.telefones)}`;return`
${o?`<p class="rpt-ultimo-envio" style="font-size:${h.label};color:${S.muted};margin-bottom:6px;font-style:italic">${Z(o)}</p>`:""}
<div class="rpt-footer" style="margin-top:10px;padding-top:5px;border-top:1.5px solid ${S.azulNavel};display:flex;justify-content:space-between;align-items:center;font-size:8px;color:${S.muted}">
  <span style="font-size:8px;color:${S.muted}">${c}</span>
  <span style="font-size:8px;color:${S.muted}">${d}</span>
</div>`}function _e({maquina:o,cliente:l,subcategoria:t,categoria:c,manutencoes:d=[],relatorios:N=[],reparacoes:y=[],tecnicos:B=[],logoUrl:K}){const x=La,w=K??"/manut/logo-navel.png",f=new Date,V=f.toLocaleString("pt-PT",{dateStyle:"long",timeStyle:"short",timeZone:"Atlantic/Azores"}),I=[...d].sort((m,P)=>P.data.localeCompare(m.data)),F=I.length,j=I.filter(m=>m.status==="concluida"),A=I.filter(m=>m.status!=="concluida"),D=A.filter(m=>fa(m.data)<f),L=A.filter(m=>fa(m.data)>=f),X=j[0],s=L.reduce((m,P)=>!m||P.data<m.data?P:m,null),O=X?la(X.data,!0):"—",G=s?la(s.data,!0):"—",J=o.proximaManut?la(o.proximaManut,!0):G,E=j.map(m=>N.find(P=>P.manutencaoId===m.id)).find(m=>m?.assinaturaDigital),aa=E?.assinaturaDigital?Pa(E.assinaturaDigital):null,Q=X?.tecnico||E?.tecnico||null,W=Q?B.find(m=>m.nome===Q&&m.ativo!==!1):null,p=W?.assinaturaDigital?Pa(W.assinaturaDigital):null,n=t?`${t.nome} — ${o.marca} ${o.modelo}`:`${o.marca} ${o.modelo}`,g=(m,P)=>{const R=N.find(r=>r.manutencaoId===m.id),Y=m.tipo==="montagem"?"Montagem":"Periódica",i=la(m.data,!0),b=x(R?.tecnico??m.tecnico??"—"),M=R?.nomeAssinante?x(R.nomeAssinante):"—",ta=R?.notas?x(R.notas.length>90?R.notas.slice(0,90)+"…":R.notas):"—",na=m.status==="concluida"?'<span class="badge-ok">Executada</span>':fa(m.data)<f?'<span class="badge-err">Em atraso</span>':'<span class="badge-pend">Agendada</span>';return`<tr${P%2===1?' class="row-alt"':""}>
      <td class="td-c">${P+1}</td>
      <td>${i}</td>
      <td class="td-c">${Y}</td>
      <td class="td-c">${na}</td>
      <td>${b}</td>
      <td>${M}</td>
      <td class="td-notes">${ta}</td>
    </tr>`},T=[...y].sort((m,P)=>(P.data||"").localeCompare(m.data||"")),z={pendente:"Pendente",em_progresso:"Em progresso",concluida:"Concluída"},H={pendente:"badge-pend",em_progresso:"badge-pend",concluida:"badge-ok"},$=(m,P)=>{const R=m.data?la(m.data,!0):"—",Y=x(m.tecnico??"—"),i=`<span class="${H[m.status]??"badge-pend"}">${z[m.status]??m.status}</span>`,b=x((m.descricaoAvaria||"—").slice(0,100)),M=x((m.observacoes||"—").slice(0,80));return`<tr${P%2===1?' class="row-alt"':""}>
      <td class="td-c">${P+1}</td>
      <td>${R}</td>
      <td>${Y}</td>
      <td class="td-c">${i}</td>
      <td class="td-notes">${b}</td>
      <td class="td-notes">${M}</td>
    </tr>`},q=`
/* Margens de impressão (histórico usa 10mm 13mm) */
@page { margin: 10mm 13mm; }

/* Override título bar para "Gerado em" (data em vez de nº serviço) */
.rpt-titulo-bar .rpt-num { font-size: 9.5px; font-family: inherit; }
.rpt-titulo-bar .rpt-num-label { font-size: 8.5px; color: rgba(255,255,255,.85); }

/* Ficha do equipamento */
.ficha-grid { display:grid; grid-template-columns:1fr 1fr; gap:0; border:1px solid var(--borda); border-radius:4px; overflow:hidden; margin-bottom:10px; }
.ficha-col { padding:8px 10px; }
.ficha-col + .ficha-col { border-left:1px solid var(--borda); background:var(--cinza); }
.ficha-field { margin-bottom:5px; }
.ficha-field:last-child { margin-bottom:0; }
.ficha-label { display:block; font-size:${h.micro}; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--muted); margin-bottom:1px; }
.ficha-value { font-size:${h.corpo}; color:var(--texto); font-weight:500; }
.ficha-value-lg { font-size:13px; font-weight:700; color:var(--azul); }

/* Estatísticas */
.stats-row { display:grid; grid-template-columns:repeat(5,1fr); gap:6px; margin-bottom:12px; }
.stat-box { border:1px solid var(--borda); border-radius:4px; padding:6px 8px; text-align:center; background:var(--cinza); }
.stat-num { display:block; font-size:18px; font-weight:800; line-height:1.1; color:var(--azul); }
.stat-num.red { color:var(--vermelho); }
.stat-num.green { color:var(--verde); }
.stat-num.orange { color:var(--laranja); }
.stat-lbl { display:block; font-size:${h.micro}; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; margin-top:2px; }
.stat-num.ultima-exec { font-size:${O.length>8?"9":"13"}px; padding-top:${O.length>8?"5":"2"}px; }

/* Tabela histórico */
.hist-table { width:100%; border-collapse:collapse; font-size:${h.pequeno}; margin-bottom:14px; page-break-inside:auto; }
.hist-table th { background:var(--azul); color:var(--branco); padding:4px 6px; text-align:left; font-size:${h.micro}; font-weight:600; letter-spacing:.05em; text-transform:uppercase; white-space:nowrap; }
.hist-table th.th-n { width:22px; }
.hist-table th.th-data { width:62px; }
.hist-table th.th-tipo { width:58px; }
.hist-table th.th-estado { width:68px; }
.hist-table th.th-tecnico { width:80px; }
.hist-table th.th-assin { width:90px; }
.hist-table td { padding:4px 6px; border-bottom:1px solid var(--borda-leve); vertical-align:top; }
.hist-table tr.row-alt td { background:var(--cinza); }
.td-c { text-align:center; }
.td-notes { font-size:${h.label}; color:var(--muted); max-width:140px; }

/* Badges estado */
.badge-ok   { background:#dcfce7; color:#14532d; padding:1.5px 6px; border-radius:8px; font-size:${h.micro}; font-weight:700; white-space:nowrap; border:1px solid #86efac; }
.badge-err  { background:#fee2e2; color:#7f1d1d; padding:1.5px 6px; border-radius:8px; font-size:${h.micro}; font-weight:700; white-space:nowrap; border:1px solid #fca5a5; }
.badge-pend { background:#fef3c7; color:#78350f; padding:1.5px 6px; border-radius:8px; font-size:${h.micro}; font-weight:700; white-space:nowrap; border:1px solid #fcd34d; }

.hist-empty { color:var(--muted); font-size:10px; margin-bottom:12px; font-style:italic; }
.hist-reps-title { margin-top:14px; }
.hist-table.reps-table th.th-tecnico { width:70px; }

@media print {
  .hist-table tr { page-break-inside:avoid; }
  .hist-table thead { display:table-header-group; }
}
`;return`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Histórico de Manutenção — ${x(o.marca)} ${x(o.modelo)}</title>
<style>
${Ce(S.azulNavel,"rgba(26,72,128,0.12)")}
${q}
</style>
</head>
<body>

${Ne(w)}

${$e("Histórico Completo de Manutenção","Gerado em",V)}

<div class="rpt-section-title">Ficha do equipamento</div>
<div class="ficha-grid">
  <div class="ficha-col">
    <div class="ficha-field">
      <span class="ficha-label">Equipamento</span>
      <span class="ficha-value ficha-value-lg">${x(o.marca)} ${x(o.modelo)}</span>
    </div>
    <div class="ficha-field">
      <span class="ficha-label">Nº de Série</span>
      <span class="ficha-value">${x(o.numeroSerie||"—")}</span>
    </div>
    ${t?`<div class="ficha-field">
      <span class="ficha-label">Tipo / Subcategoria</span>
      <span class="ficha-value">${x(t.nome)}${c?` &mdash; ${x(c.nome)}`:""}</span>
    </div>`:""}
    ${o.localizacao?`<div class="ficha-field">
      <span class="ficha-label">Localização</span>
      <span class="ficha-value">${x(o.localizacao)}</span>
    </div>`:""}
  </div>
  <div class="ficha-col">
    <div class="ficha-field">
      <span class="ficha-label">Cliente</span>
      <span class="ficha-value ficha-value-lg">${x(l?.nome??"—")}</span>
    </div>
    ${l?.nif?`<div class="ficha-field">
      <span class="ficha-label">NIF</span>
      <span class="ficha-value">${x(l.nif)}</span>
    </div>`:""}
    ${l?.morada?`<div class="ficha-field">
      <span class="ficha-label">Morada</span>
      <span class="ficha-value">${x(l.morada)}</span>
    </div>`:""}
    <div class="ficha-field">
      <span class="ficha-label">Próxima manutenção</span>
      <span class="ficha-value">${J}</span>
    </div>
  </div>
</div>

<div class="rpt-section-title">Estatísticas globais</div>
<div class="stats-row">
  <div class="stat-box">
    <span class="stat-num">${F}</span>
    <span class="stat-lbl">Total</span>
  </div>
  <div class="stat-box">
    <span class="stat-num green">${j.length}</span>
    <span class="stat-lbl">Executadas</span>
  </div>
  <div class="stat-box">
    <span class="stat-num orange">${L.length}</span>
    <span class="stat-lbl">Agendadas</span>
  </div>
  <div class="stat-box">
    <span class="stat-num${D.length>0?" red":""}">${D.length}</span>
    <span class="stat-lbl">Em atraso</span>
  </div>
  <div class="stat-box">
    <span class="stat-num ultima-exec">${O}</span>
    <span class="stat-lbl">Última execução</span>
  </div>
</div>

<div class="rpt-section-title">
  Registo histórico — ${F} intervenç${F===1?"ão":"ões"} (mais recente primeiro)
</div>
${F===0?'<p class="hist-empty">Nenhuma manutenção registada para este equipamento.</p>':`<table class="hist-table">
  <thead>
    <tr>
      <th class="td-c th-n">#</th>
      <th class="th-data">Data</th>
      <th class="td-c th-tipo">Tipo</th>
      <th class="td-c th-estado">Estado</th>
      <th class="th-tecnico">Técnico</th>
      <th class="th-assin">Assinado por</th>
      <th>Observações</th>
    </tr>
  </thead>
  <tbody>
    ${I.map((m,P)=>g(m,P)).join(`
    `)}
  </tbody>
</table>`}

${T.length>0?`
<div class="rpt-section-title hist-reps-title">
  Reparações — ${T.length} registo${T.length===1?"":"s"}
</div>
<table class="hist-table reps-table">
  <thead>
    <tr>
      <th class="td-c th-n">#</th>
      <th class="th-data">Data</th>
      <th class="th-tecnico">Técnico</th>
      <th class="td-c th-estado">Estado</th>
      <th>Descrição da avaria</th>
      <th>Observações</th>
    </tr>
  </thead>
  <tbody>
    ${T.map((m,P)=>$(m,P)).join(`
    `)}
  </tbody>
</table>`:""}

${aa||p?`
<div class="rpt-section-title">Última assinatura registada</div>
<div class="rpt-assinaturas-dual">
  ${p?`<div class="rpt-assinatura-col">
    <div class="rpt-label">Técnico responsável</div>
    <div class="rpt-assinatura-nome">${x(W?.nome||"")}</div>
    ${W?.telefone?`<div class="rpt-assinatura-detalhe">Tel: ${x(W.telefone)}</div>`:""}
    <div class="rpt-assinatura-img"><img src="${p}" alt="Assinatura do técnico"></div>
  </div>`:"<div></div>"}
  ${aa?`<div class="rpt-assinatura-col">
    <div class="rpt-label">Assinatura do cliente</div>
    <div class="rpt-assinatura-img"><img src="${aa}" alt="Assinatura do cliente"></div>
    ${E?.nomeAssinante?`<div class="rpt-assinatura-detalhe">Assinado por: <strong>${x(E.nomeAssinante)}</strong>${E.dataAssinatura?` &nbsp;&mdash;&nbsp; ${te(E.dataAssinatura)}`:""}</div>`:""}
  </div>`:"<div></div>"}
</div>`:""}

${Ae("","",`${x(n)} &nbsp;&middot;&nbsp; S/N: ${x(o.numeroSerie||"—")}`)}

</body>
</html>`}export{Ke as C,Oe as D,Ue as M,Le as P,qa as a,Ha as b,Re as c,S as d,$e as e,Ae as f,_e as g,Ne as h,Ce as i};
