import{t}from"./format-srypevDS.js";function i(o,r){return+t(o)<+t(r)}export{i};
