import{e as gt}from"./sanitize-Bc5btBtG.js";import{f as bt,p as Z}from"./index-U8En2mk5.js";import{P as l,c as vt,h as xt,a as $t,b as kt}from"./relatorioBaseStyles-DlGRV3b_.js";import{n,d as Y}from"./Clientes-SyH_qAsd.js";import"./vendor-Bk0NZ5Or.js";import"./vendor-pdf-hYLUQ4hX.js";import"./vendor-icons-CtiSrLhX.js";import"./vendor-datefns-CCZTWiZ_.js";import"./gerarHtmlHistoricoMaquina-DfYYcTz4.js";import"./pt-DInhV8Fk.js";import"./RelatorioView-cHixqIpX.js";import"./emailConfig-C2BdRTvi.js";import"./emailService-CcItR6SC.js";import"./limits-C3hP4_4k.js";import"./alertasConfig-B4FOp8kv.js";import"./useDeferredReady-DJeNj7lM.js";const wt=5,tt=3,at=2,L=c=>{if(!c)return"—";const p=String(c).slice(0,10).split("-");return p.length<3?String(c):`${p[2]}-${p[1]}-${p[0]}`};function _t(c,p,et,ot,st=[],lt,rt,k={}){const o=gt,it=k.logoUrl??"/manut/logo-navel.png",y=new Date().toISOString().slice(0,10),nt=bt(y,!0),P=new Date().getFullYear(),z=!!k.periodoCustom,K=k.periodoLabel||String(P),G=k.periodoInicio??null,J=k.periodoFim??null,_=t=>!(!t||G&&t<G||J&&t>J),Q=new Set(p.map(t=>n(t.id))),E=et.filter(t=>Q.has(n(t.maquinaId))),q=st.filter(t=>Q.has(n(t.maquinaId))),C=new Map;E.forEach(t=>{const a=n(t.maquinaId);C.has(a)||C.set(a,[]),C.get(a).push(t)});const M=new Map;q.forEach(t=>{const a=n(t.maquinaId);M.has(a)||M.set(a,[]),M.get(a).push(t)});const B=new Map;for(const t of ot){const a=n(t.manutencaoId);!a||!E.some(e=>n(e.id)===a)||B.set(a,t)}const w=p.map(t=>{const a=lt(t.subcategoriaId),e=a?rt(a.categoriaId):null,r=n(t.id),m=C.get(r)||[],N=M.get(r)||[],d=m.filter(s=>s.status==="concluida").sort((s,f)=>f.data.localeCompare(s.data))[0],v=m.filter(s=>s.status==="agendada"||s.status==="pendente").sort((s,f)=>s.data.localeCompare(f.data))[0],x=v?.data!=null?String(v.data).slice(0,10):t.proximaManut?String(t.proximaManut).slice(0,10):"",$=!!(x&&x<y),X=m.filter(s=>s.status==="concluida").length,U=N.filter(s=>s.status==="concluida").length,D=N.filter(s=>s.status!=="concluida").length,R=d?B.get(n(d.id)):null,T=v?.data??t.proximaManut;let j=null;T&&(j=Math.floor((Z(y)-Z(T))/864e5));let u;!d&&!x?u="instalar":$?u="atraso":u="conforme";let g,b;u==="instalar"?(g="badge-montagem",b="Por instalar"):u==="atraso"?(g="badge-atraso",b="Não conforme"):(g="badge-ok",b="Conforme");const F=m.filter(s=>s.status==="concluida").sort((s,f)=>f.data.localeCompare(s.data));let h={nivel:"neutro",texto:"—",cor:l.muted};if(F.length>=2){const f=F.slice(0,wt).map(W=>B.get(n(W.id))).filter(Boolean).reduce((W,V)=>{const ft=V.checklistSnapshot??[];return W+ft.filter(ht=>V.checklistRespostas?.[ht.id]==="nao").length},0);$?h={nivel:"critico",texto:"⚠ Atraso",cor:l.vermelho}:f===0&&F.length>=tt?h={nivel:"excelente",texto:"★ Excelente",cor:l.verde}:f===0?h={nivel:"bom",texto:"● Conforme",cor:l.verde}:f<=at?h={nivel:"atencao",texto:"◐ Atenção",cor:l.amarelo}:h={nivel:"critico",texto:"⚠ Crítico",cor:l.vermelho}}else F.length===0&&u==="instalar"?h={nivel:"novo",texto:"○ Novo",cor:l.muted}:$&&(h={nivel:"critico",texto:"⚠ Atraso",cor:l.vermelho});return{m:t,sub:a,cat:e,ultima:d,proxima:v,emAtraso:$,diasAtraso:j,totalManuts:X,totalReps:U,repsAbertas:D,relUltima:R,estado:u,estadoBadge:g,estadoLabel:b,tendencia:h,proxDataKey:x}}),O=p.length,A=w.filter(t=>t.estado==="atraso").length,ct=w.filter(t=>t.estado==="conforme").length,H=O>0?Math.round(ct/O*100):0,dt=z?E.filter(t=>t.status==="concluida"&&_(Y(t.data))).length:E.filter(t=>t.status==="concluida"&&t.data?.startsWith(String(P))).length,pt=z?q.filter(t=>t.status==="concluida"&&_(Y(t.data))).length:q.filter(t=>t.status==="concluida"&&t.data?.startsWith(String(P))).length,mt=w.reduce((t,a)=>t+a.repsAbertas,0),S=new Map;w.forEach(t=>{const a=t.cat?.id||"_sem_categoria",e=t.cat?.nome||"Sem categoria";S.has(a)||S.set(a,{nome:e,linhas:[]}),S.get(a).linhas.push(t)});const ut=new Date(Date.now()-365*864e5).toISOString().slice(0,10),I=q.filter(t=>t.status!=="concluida"?!1:z?_(Y(t.data)):t.data>=ut).sort((t,a)=>a.data.localeCompare(t.data)).slice(0,20);let i=`<!DOCTYPE html><html lang="pt"><head><meta charset="utf-8">
<title>Relatório Executivo de Frota — ${o(c.nome)}</title>
<style>${vt(l.azulNavel,"rgba(26,72,128,0.12)")}
@page { size: A4 portrait; margin: 14mm 12mm 12mm }
:root { --verde-light: #dcfce7; --vermelho-light: #fee2e2; --laranja-light: #fef3c7 }
.secao-titulo{background:var(--azul);color:var(--branco);padding:5px 10px;font-size:9pt;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px;border-radius:3px}
.secao-titulo.vermelho{background:#b91c1c}
.secao-titulo.laranja{background:#a16207}
.cliente-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px 12px;padding:8px 10px;background:var(--cinza);border-radius:4px;border:1px solid var(--borda);border-top:3px solid var(--azul);margin-bottom:10px}
.cliente-field{display:flex;flex-direction:column;gap:1px}
.cliente-field .c-label{font-size:8pt;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);font-weight:600}
.cliente-field .c-value{font-size:9pt;font-weight:700;color:var(--texto)}
.kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:6px;margin-bottom:10px}
.kpi-card{background:var(--cinza);border:1px solid var(--borda);border-radius:5px;padding:7px 8px;text-align:center}
.kpi-card.kpi-verde{background:#dcfce7;border-color:#15803d}
.kpi-card.kpi-vermelho{background:#fee2e2;border-color:#b91c1c}
.kpi-card.kpi-laranja{background:#fef3c7;border-color:#a16207}
.kpi-card.kpi-azul{background:var(--azul-claro);border-color:var(--azul)}
.kpi-numero{font-size:18pt;font-weight:800;line-height:1.1}
.kpi-verde .kpi-numero{color:#14532d}
.kpi-vermelho .kpi-numero{color:#7f1d1d}
.kpi-laranja .kpi-numero{color:#78350f}
.kpi-azul .kpi-numero{color:var(--azul)}
.kpi-label{font-size:8pt;color:var(--texto);text-transform:uppercase;letter-spacing:.04em;margin-top:2px;font-weight:600}
.tabela-frota{width:100%;border-collapse:collapse;font-size:8pt;margin-bottom:6px}
.tabela-frota th{background:var(--azul);color:var(--branco);padding:4px 5px;text-align:left;font-size:7.5pt;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.tabela-frota td{padding:3px 5px;vertical-align:top;color:var(--texto)}
.tabela-frota .eq-row td{border-top:1px solid var(--borda-leve);padding-top:4px;padding-bottom:4px;border-bottom:1px solid var(--borda)}
.tabela-frota .eq-row.par td{background:var(--cinza)}
.tabela-frota .eq-cell-stack .eq-nome{display:block;margin-bottom:2px}
.tabela-frota .cell-eq{width:30%}
.tabela-frota .cell-center{text-align:center}
.tabela-frota .cell-muted{color:var(--muted)}
.tabela-frota .cell-dias{font-weight:700}
.badge{display:inline-block;padding:1.5px 6px;border-radius:10px;font-size:7.5pt;font-weight:700;white-space:nowrap}
.badge-ok{background:#dcfce7;color:#14532d;border:1px solid #86efac}
.badge-atraso{background:#fee2e2;color:#7f1d1d;border:1px solid #fca5a5}
.badge-montagem{background:#fef3c7;color:#78350f;border:1px solid #fcd34d}
.data-atraso{color:#b91c1c;font-weight:700}
.data-ok{color:#15803d;font-weight:600}
.eq-nome{font-weight:700;font-size:8.5pt}
.eq-sub{font-size:7pt;color:var(--muted)}
.eq-serie{font-family:'Courier New',monospace;font-size:7pt;color:var(--muted);word-break:break-all;overflow-wrap:anywhere;max-width:100%}
.cat-header{background:var(--azul-claro);padding:5px 8px;font-size:9pt;font-weight:700;color:var(--azul);margin:8px 0 4px;border-radius:3px;border-left:3px solid var(--azul)}
.cat-header .atraso-count{color:#b91c1c}
.resumo-anual{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}
.resumo-box{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:8px 10px}
.resumo-box h4{font-size:9pt;color:var(--azul);margin-bottom:4px;text-transform:uppercase;font-weight:700}
.resumo-stat{display:flex;justify-content:space-between;font-size:9pt;padding:3px 0;border-bottom:1px dotted var(--borda-leve);color:var(--texto)}
.resumo-stat:last-child{border-bottom:none}
.resumo-stat .stat-accent{color:var(--azul);font-weight:700}
.resumo-stat .stat-atraso{color:#b91c1c;font-weight:700}
.sub-muted{font-size:8pt;color:var(--muted)}
.cell-desc{font-size:8pt}
.cell-rel{font-size:8pt}
</style>
</head><body>
${xt(it)}
${$t("Relatório Executivo de Frota","Período",K)}
<div class="cliente-grid">
  <div class="cliente-field"><span class="c-label">Cliente</span><span class="c-value">${o(c.nome)}</span></div>
  <div class="cliente-field"><span class="c-label">NIF</span><span class="c-value">${o(c.nif??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Localidade</span><span class="c-value">${o(c.localidade??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Morada</span><span class="c-value">${o(c.morada??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Telefone</span><span class="c-value">${o(c.telefone??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Email</span><span class="c-value">${o(c.email??"—")}</span></div>
</div>
<div class="kpis">
  <div class="kpi-card"><div class="kpi-numero">${O}</div><div class="kpi-label">Equipamentos</div></div>
  <div class="kpi-card ${H>=80?"kpi-verde":H>=50?"kpi-laranja":"kpi-vermelho"}"><div class="kpi-numero">${H}%</div><div class="kpi-label">Conformidade</div></div>
  <div class="kpi-card ${A>0?"kpi-vermelho":"kpi-verde"}"><div class="kpi-numero">${A}</div><div class="kpi-label">Em atraso</div></div>
  <div class="kpi-card kpi-azul"><div class="kpi-numero">${dt}</div><div class="kpi-label">Manutenções período</div></div>
  <div class="kpi-card ${mt>0?"kpi-laranja":""}"><div class="kpi-numero">${pt}</div><div class="kpi-label">Reparações período</div></div>
</div>`;for(const[,t]of S){const a=t.linhas.filter(e=>e.estado==="atraso").length;i+=`<div class="cat-header">${o(t.nome)} (${t.linhas.length} equip.${a>0?` · <span class="atraso-count">${a} em atraso</span>`:""})</div>
<table class="tabela-frota"><thead><tr>
  <th class="cell-eq" style="width:26%">Equipamento / N.º Série</th>
  <th class="cell-center" style="width:9%">Última</th>
  <th class="cell-center" style="width:9%">Próxima</th>
  <th class="cell-center" style="width:6%">Dias</th>
  <th class="cell-center" style="width:5%">Man.</th>
  <th class="cell-center" style="width:5%">Rep.</th>
  <th class="cell-center" style="width:11%">Estado</th>
  <th class="cell-center" style="width:11%">Tendência</th>
  <th class="cell-center" style="width:18%">Últ. rel.</th>
</tr></thead><tbody>`,t.linhas.sort((e,r)=>(r.diasAtraso??-9999)-(e.diasAtraso??-9999)).forEach(({m:e,sub:r,ultima:m,proxima:N,diasAtraso:d,totalManuts:v,totalReps:x,relUltima:$,estadoBadge:X,estadoLabel:U,tendencia:D,proxDataKey:R},T)=>{const j=d!=null?d>0?`<span class="data-atraso">+${d}</span>`:d===0?"Hoje":`<span class="data-ok">${d}</span>`:"—",u=T%2===0?"par":"",g=N?.data??e.proximaManut,b=[r?`<span class="eq-sub">${o(r.nome)}</span>`:"",e.numeroSerie?`<span class="eq-serie">S/N: ${o(e.numeroSerie)}</span>`:""].filter(Boolean).join(" ");i+=`<tr class="eq-row ${u}">
        <td class="cell-eq eq-cell-stack"><span class="eq-nome">${o(e.marca)} ${o(e.modelo)}</span>${b?`<br/>${b}`:""}</td>
        <td class="cell-center">${m?L(m.data):"—"}</td>
        <td class="cell-center">${g?`<span class="${R&&R<y?"data-atraso":"data-ok"}">${L(g)}</span>`:"—"}</td>
        <td class="cell-center cell-dias">${j}</td>
        <td class="cell-center cell-muted">${v||"—"}</td>
        <td class="cell-center cell-muted">${x||"—"}</td>
        <td class="cell-center"><span class="badge ${X}">${o(U)}</span></td>
        <td class="cell-center" style="font-size:7.5pt;font-weight:700;color:${D.cor}">${D.texto}</td>
        <td class="cell-center cell-rel">${$?.numeroRelatorio??"—"}</td>
      </tr>`}),i+="</tbody></table>"}if(A>0&&(i+=`<div class="secao-titulo vermelho">Manutenções em atraso (${A})</div>
<table class="tabela-frota"><thead><tr>
  <th class="cell-eq" style="width:30%">Equipamento</th><th class="cell-serie" style="width:16%">Nº Série</th>
  <th style="width:14%">Data prevista</th><th class="cell-center" style="width:10%">Dias atraso</th>
  <th style="width:30%">Observações</th>
</tr></thead><tbody>`,w.filter(t=>t.estado==="atraso").sort((t,a)=>(a.diasAtraso??0)-(t.diasAtraso??0)).forEach(({m:t,sub:a,proxima:e,diasAtraso:r})=>{const m=e?.data??t.proximaManut;i+=`<tr>
        <td><strong>${o(t.marca)} ${o(t.modelo)}</strong>${a?` <span class="sub-muted">· ${o(a.nome)}</span>`:""}</td>
        <td class="cell-serie">${o(t.numeroSerie)}</td>
        <td class="data-atraso">${L(m)}</td>
        <td class="data-atraso cell-center cell-dias">+${r??0}d</td>
        <td class="sub-muted">${o(e?.observacoes??"")}</td>
      </tr>`}),i+="</tbody></table>"),I.length>0){const t=z?`${o(K)} — ${I.length}`:`últimos 12 meses — ${I.length}`;i+=`<div class="secao-titulo laranja">Reparações concluídas (${t})</div>
<table class="tabela-frota"><thead><tr>
  <th class="cell-eq" style="width:28%">Equipamento</th><th class="cell-serie" style="width:14%">Nº Série</th>
  <th style="width:12%">Data</th><th style="width:46%">Descrição</th>
</tr></thead><tbody>`;const a=new Map(p.map(e=>[n(e.id),e]));I.forEach(e=>{const r=a.get(n(e.maquinaId));i+=`<tr>
        <td><strong>${r?o(`${r.marca} ${r.modelo}`):"—"}</strong></td>
        <td class="cell-serie">${r?o(r.numeroSerie):"—"}</td>
        <td>${L(e.data)}</td>
        <td class="cell-desc">${o(e.descricao?.slice(0,120)||e.descricaoAvaria?.slice(0,120)||"—")}</td>
      </tr>`}),i+="</tbody></table>"}return i+=`
<div style="margin-top:10px;padding:6px 10px;background:${l.cinza};border:1px solid ${l.bordaLeve};border-radius:4px;font-size:7.5pt;color:${l.muted};display:flex;gap:14px;flex-wrap:wrap;align-items:center;page-break-inside:avoid">
  <strong style="color:${l.azulNavel};text-transform:uppercase;letter-spacing:.04em;font-size:7pt">Legenda Tendência:</strong>
  <span style="color:${l.verde}">★ Excelente — ≥${tt} sem anomalias</span>
  <span style="color:${l.verde}">● Conforme — sem anomalias</span>
  <span style="color:${l.amarelo}">◐ Atenção — anomalias pontuais (≤${at})</span>
  <span style="color:${l.vermelho}">⚠ Crítico — múltiplas anomalias ou atraso</span>
  <span style="color:${l.muted}">○ Novo — sem histórico</span>
</div>`,i+=`${kt("Documento gerado em "+nt)}</body></html>`,i}export{_t as gerarRelatorioFrotaHtml};
