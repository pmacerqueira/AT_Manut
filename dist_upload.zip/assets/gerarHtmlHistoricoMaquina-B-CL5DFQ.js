const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/apiService-CA4-Q1g5.js","assets/index-DuxA0ekz.js","assets/vendor-Bk0NZ5Or.js","assets/vendor-pdf-hYLUQ4hX.js","assets/index-BghBuJB_.css","assets/limits-CwjsBkae.js"])))=>i.map(i=>d[i]);
import{c as va,b as na,a as la,d as wa,R as Ma,p as Sa,q as $a,r as Da,j as a,s as ua,v as Ia,w as ba,u as Ea,n as Pa,x as Fa,X as ma,i as za,m as pa,A as ka}from"./index-DuxA0ekz.js";import{_ as ja}from"./vendor-pdf-hYLUQ4hX.js";import{r as w}from"./vendor-Bk0NZ5Or.js";import{g as Ta,p as ra,f as J,a as La}from"./datasAzores-vTPFpdRw.js";import{f as Ca}from"./format-srypevDS.js";import{p as ya}from"./pt-C4l4ol_H.js";import{U as Ua}from"./upload-DilXJfdP.js";import{S as Ra}from"./save-DN2f5F3e.js";import{C as _a}from"./chevron-down-A85Qfum3.js";import{T as ia}from"./trash-2-CZgAN-WN.js";import{P as Aa}from"./plus-CAgq3fWD.js";import{s as ha,a as ga,e as Ha}from"./emailConfig-CchrVQL_.js";import{E as Ka}from"./external-link-kj4qGCn8.js";import{E as aa}from"./empresa-DQbPD-Qf.js";const Oa=[["path",{d:"M12 10v6",key:"1bos4e"}],["path",{d:"M9 13h6",key:"1uhe8q"}],["path",{d:"M20 20a2 2 0 0 0 2-2V8a2 2 0 0 0-2-2h-7.9a2 2 0 0 1-1.69-.9L9.6 3.9A2 2 0 0 0 7.93 3H4a2 2 0 0 0-2 2v13a2 2 0 0 0 2 2Z",key:"1kt360"}]],ue=va("folder-plus",Oa);const Ba=[["path",{d:"M12 22v-9",key:"x3hkom"}],["path",{d:"M15.17 2.21a1.67 1.67 0 0 1 1.63 0L21 4.57a1.93 1.93 0 0 1 0 3.36L8.82 14.79a1.655 1.655 0 0 1-1.64 0L3 12.43a1.93 1.93 0 0 1 0-3.36z",key:"2ntwy6"}],["path",{d:"M20 13v3.87a2.06 2.06 0 0 1-1.11 1.83l-6 3.08a1.93 1.93 0 0 1-1.78 0l-6-3.08A2.06 2.06 0 0 1 4 16.87V13",key:"1pmm1c"}],["path",{d:"M21 12.43a1.93 1.93 0 0 0 0-3.36L8.83 2.2a1.64 1.64 0 0 0-1.63 0L3 4.57a1.93 1.93 0 0 0 0 3.36l12.18 6.86a1.636 1.636 0 0 0 1.63 0z",key:"12ttoo"}]],Va=va("package-open",Ba),ea=(d,f)=>d(f)?.nome?.toLowerCase().includes("levador")??!1,sa=d=>["sub5","sub14"].includes(d),Ga=d=>ba.includes(d);function Wa(d=[]){return[...d].sort((f,o)=>{const h=(f?.nome??"").trim(),c=(o?.nome??"").trim();return h.localeCompare(c,"pt",{sensitivity:"base"})})}function ta(d){const f=String(d?.id??"").trim();if(f)return`id:${f}`;const o=(d?.nome??"").trim().toLowerCase();return o?`name:${o}`:""}function Za(d){return new Promise((f,o)=>{const h=new FileReader;h.onerror=o,h.onload=()=>f(String(h.result||"")),h.readAsDataURL(d)})}function Ya(d){return new Promise((f,o)=>{const h=new Image;h.onerror=o,h.onload=()=>{const $=Math.min(1200/h.width,360/h.height,1),D=Math.max(1,Math.round(h.width*$)),j=Math.max(1,Math.round(h.height*$)),r=document.createElement("canvas");r.width=D,r.height=j;const F=r.getContext("2d");F.clearRect(0,0,D,j),F.drawImage(h,0,0,D,j),f(r.toDataURL("image/png",.92))},h.src=d})}function me({isOpen:d,onClose:f,mode:o,clienteNifLocked:h,maquina:c,onSave:U}){const{clientes:$,categorias:D,marcas:j,maquinas:r,INTERVALOS:F,getSubcategoriasByCategoria:v,getSubcategoria:i,getCategoria:N,addMarca:E,addMaquina:C,updateMaquina:u,addManutencao:b,manutencoes:_,updateManutencao:Z}=na(),{showToast:P}=la(),{user:k}=wa(),K=k?.role===Ma.ADMIN,[Q,I]=w.useState(""),V=w.useMemo(()=>{const e=new Date().getFullYear(),t=new Set;for(let m=e-1;m<=e+3;m++)Sa(m).forEach(S=>t.add(S));return t},[]),O=w.useCallback(e=>{if(!e)return I(""),!0;const t=new Date(e+"T12:00:00");if($a(t)){const m=t.getDay()===0?"Domingo":"Sábado";return I(`${m} — não é dia útil. Escolha um dia de semana.`),!1}return Da(t,V)?(I("Esta data é feriado. Escolha outro dia."),!1):(I(""),!0)},[V]),H=w.useRef(!1),[l,x]=w.useState({clienteNif:"",categoriaId:"",subcategoriaId:"",periodicidadeManut:"",marcaId:"",marca:"",marcaLogoUrl:"",modelo:"",numeroSerie:"",anoFabrico:"",numeroDocumentoVenda:"",proximaManut:"",refKitManut3000h:"",refKitManut6000h:"",refCorreia:"",refFiltroOleo:"",refFiltroSeparador:"",refFiltroAr:"",posicaoKaeser:null}),G=l.categoriaId?v(l.categoriaId):[],[z,B]=w.useState(!1),[T,R]=w.useState({nome:"",logoUrl:"",corHex:"#1a4880"}),[n,y]=w.useState(!1),s=Wa(j),p=e=>s.find(t=>String(t?.id)===String(e)),M=e=>s.find(t=>(t?.nome??"").trim().toLowerCase()===String(e??"").trim().toLowerCase()),Y=e=>s.find(t=>ta(t)===e),W=(()=>{if(z)return"__new__";if(l.marcaId){const e=p(l.marcaId);if(e)return ta(e)}if(l.marca){const e=M(l.marca);if(e)return ta(e)}return""})();w.useEffect(()=>{const e=d&&!H.current;if(H.current=d,!!e){if(o==="add"){const m=D[0]?.id||"",g=v(m)[0]?.id||"",A=ea(N,m)?"anual":"";x({clienteNif:h||$[0]?.nif||"",categoriaId:m,subcategoriaId:g,periodicidadeManut:A,marcaId:"",marca:"",marcaLogoUrl:"",marcaCorHex:"",modelo:"",numeroSerie:"",anoFabrico:new Date().getFullYear(),numeroDocumentoVenda:"",proximaManut:Ta(),refKitManut3000h:"",refKitManut6000h:"",refCorreia:"",refFiltroOleo:"",refFiltroSeparador:"",refFiltroAr:"",posicaoKaeser:sa(g)?0:null}),B(!1),R({nome:"",logoUrl:"",corHex:"#1a4880"})}else if(c){const t=i(c.subcategoriaId);N(t?.categoriaId);const m=c.periodicidadeManut??(ea(N,t?.categoriaId)?"anual":""),S=j.find(g=>(g.nome??"").toLowerCase()===(c.marca??"").toLowerCase());x({id:c.id,clienteNif:c.clienteNif,categoriaId:t?.categoriaId||"",subcategoriaId:c.subcategoriaId,periodicidadeManut:m,marcaId:c.marcaId!=null?String(c.marcaId):S?.id!=null?String(S.id):"",marca:c.marca,marcaLogoUrl:c.marcaLogoUrl||"",marcaCorHex:c.marcaCorHex||S?.corHex||"",modelo:c.modelo,numeroSerie:c.numeroSerie,anoFabrico:c.anoFabrico||"",numeroDocumentoVenda:c.numeroDocumentoVenda||"",proximaManut:c.proximaManut,refKitManut3000h:c.refKitManut3000h||"",refKitManut6000h:c.refKitManut6000h||"",refCorreia:c.refCorreia||"",refFiltroOleo:c.refFiltroOleo||"",refFiltroSeparador:c.refFiltroSeparador||"",refFiltroAr:c.refFiltroAr||"",posicaoKaeser:c.posicaoKaeser??(sa(c.subcategoriaId)?0:null)}),B(!1),R({nome:"",logoUrl:"",corHex:"#1a4880"})}}},[d,o,h,c,D,$,j,v,i,N,F]);const X=async e=>{if(e.preventDefault(),!K&&!O(l.proximaManut)){P("A data escolhida não é dia útil. Selecione outro dia.","warning");return}const{categoriaId:t,id:m,...S}=l;let g={...S};try{if(z){const A=T.nome.trim();if(!A){P("Indique o nome da nova marca.","warning");return}const L=T.logoUrl.trim(),ca=(T.corHex||"").trim(),da=await E({nome:A,logoUrl:L,corHex:ca}),Na=da!=null?String(da):"";g={...g,marcaId:Na,marca:A,marcaLogoUrl:L,marcaCorHex:ca}}else if(g.marcaId||g.marca){const A=g.marcaId?j.find(L=>String(L.id)===String(g.marcaId)):j.find(L=>(L?.nome??"").trim().toLowerCase()===String(g.marca??"").trim().toLowerCase());A&&(g={...g,marcaId:A.id!=null&&String(A.id).trim()!==""?String(A.id):"",marca:A.nome||g.marca||"",marcaLogoUrl:A.logoUrl||g.marcaLogoUrl||"",marcaCorHex:A.corHex||g.marcaCorHex||""})}if(o==="add"){const A=await C(g);g.proximaManut&&b({maquinaId:A,data:g.proximaManut,tipo:"periodica",status:"pendente",observacoes:"",tecnico:""}),P("Equipamento adicionado com sucesso.","success"),U?.({id:A,...g},"add")}else{if(await u(m,g),g.proximaManut&&g.proximaManut!==c?.proximaManut){const A=_.find(L=>L.maquinaId===m&&(L.status==="pendente"||L.status==="agendada"));A?Z(A.id,{data:g.proximaManut}):b({maquinaId:m,data:g.proximaManut,tipo:"periodica",status:"pendente",observacoes:"",tecnico:""})}P("Equipamento actualizado com sucesso.","success"),U?.({id:m,...g},"edit")}f()}catch(A){P(A?.message||"Falha ao guardar equipamento/marca.","error",4e3)}};if(!d)return null;const q=async e=>{if(e){if(!e.type?.startsWith("image/")){P("Selecione um ficheiro de imagem válido.","warning");return}y(!0);try{const t=await Za(e),m=await Ya(t),{apiUploadMarcaLogo:S}=await ja(async()=>{const{apiUploadMarcaLogo:L}=await import("./apiService-CA4-Q1g5.js");return{apiUploadMarcaLogo:L}},__vite__mapDeps([0,1,2,3,4,5])),g=T.nome.trim()||"marca",A=await S({dataUrl:m,brandName:g});R(L=>({...L,logoUrl:A?.url||""})),P("Logotipo carregado e otimizado com sucesso.","success")}catch(t){P(`Falha no upload do logotipo: ${t?.message||"erro desconhecido"}`,"error",4e3)}finally{y(!1)}}};return a.jsx("div",{className:"modal-overlay",onClick:f,children:a.jsxs("div",{className:"modal",onClick:e=>e.stopPropagation(),children:[a.jsx("h2",{children:o==="add"?"Nova máquina":"Editar máquina"}),a.jsxs("form",{onSubmit:X,children:[a.jsxs("label",{children:["Cliente",a.jsx("select",{required:!0,value:l.clienteNif,onChange:e=>x(t=>({...t,clienteNif:e.target.value})),disabled:!!h,className:h?"readonly":"",children:[...$].sort((e,t)=>(e.nome||"").localeCompare(t.nome||"","pt")).map(e=>a.jsxs("option",{value:e.nif,children:[e.nome," (NIF: ",e.nif,")"]},e.nif))})]}),a.jsxs("label",{children:["Categoria",a.jsx("select",{required:!0,value:l.categoriaId,onChange:e=>{const t=e.target.value,m=v(t),S=ea(N,t)?"anual":"";x(g=>({...g,categoriaId:t,subcategoriaId:m[0]?.id||"",periodicidadeManut:S}))},children:D.map(e=>a.jsxs("option",{value:e.id,children:[e.nome," (",e.intervaloTipo,")"]},e.id))})]}),a.jsxs("label",{children:["Subcategoria (tipo de máquina)",a.jsx("select",{required:!0,value:l.subcategoriaId,onChange:e=>x(t=>({...t,subcategoriaId:e.target.value})),children:G.map(e=>a.jsx("option",{value:e.id,children:e.nome},e.id))})]}),ea(N,l.categoriaId)&&a.jsxs("label",{children:["Periodicidade de manutenção",a.jsxs("select",{required:!0,value:l.periodicidadeManut,onChange:e=>x(t=>({...t,periodicidadeManut:e.target.value})),children:[a.jsx("option",{value:"trimestral",children:"3 meses (trimestral)"}),a.jsx("option",{value:"semestral",children:"6 meses (semestral)"}),a.jsx("option",{value:"anual",children:"1 ano (anual)"})]})]}),!ea(N,l.categoriaId)&&l.categoriaId&&a.jsxs("label",{children:["Periodicidade de manutenção",a.jsxs("select",{value:l.periodicidadeManut,onChange:e=>x(t=>({...t,periodicidadeManut:e.target.value})),children:[a.jsx("option",{value:"",children:"Usar da categoria"}),a.jsx("option",{value:"trimestral",children:"3 meses (trimestral)"}),a.jsx("option",{value:"semestral",children:"6 meses (semestral)"}),a.jsx("option",{value:"anual",children:"1 ano (anual)"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Marca",a.jsxs("select",{value:W,onChange:e=>{const t=e.target.value;if(t==="__new__"){B(!0),x(S=>({...S,marcaId:"",marca:"",marcaLogoUrl:"",marcaCorHex:""}));return}if(!t){B(!1),R({nome:"",logoUrl:"",corHex:"#1a4880"}),x(S=>({...S,marcaId:"",marca:"",marcaLogoUrl:"",marcaCorHex:""}));return}const m=Y(t);B(!1),R({nome:"",logoUrl:"",corHex:"#1a4880"}),x(S=>({...S,marcaId:m?.id!=null&&String(m.id).trim()!==""?String(m.id):"",marca:m?.nome||"",marcaLogoUrl:m?.logoUrl||"",marcaCorHex:m?.corHex||""}))},children:[a.jsx("option",{value:"",children:"— Selecionar marca —"}),s.map(e=>a.jsx("option",{value:ta(e),children:e.nome},ta(e)||`marca-${(e?.nome??"").toLowerCase()}`)),a.jsx("option",{value:"__new__",children:"+ Nova Marca…"})]}),!z&&!l.marcaId&&a.jsx("small",{className:"text-muted",children:"Selecione uma marca ou crie uma nova."})]}),z&&a.jsxs(a.Fragment,{children:[a.jsxs("label",{children:["Nova marca",a.jsx("input",{value:T.nome,onChange:e=>R(t=>({...t,nome:e.target.value})),placeholder:"Ex: ISTOBAL"})]}),a.jsxs("label",{children:["URL do logotipo da marca",a.jsx("input",{type:"url",value:T.logoUrl,onChange:e=>R(t=>({...t,logoUrl:e.target.value})),placeholder:"https://.../logo-marca.png"})]}),a.jsxs("label",{children:["Cor institucional da marca",a.jsxs("div",{style:{display:"flex",gap:"0.5rem",alignItems:"center"},children:[a.jsx("input",{type:"color",value:T.corHex||"#1a4880",onChange:e=>R(t=>({...t,corHex:e.target.value})),style:{width:"48px",height:"34px",padding:0}}),a.jsx("input",{type:"text",value:T.corHex,onChange:e=>R(t=>({...t,corHex:e.target.value})),placeholder:"#c8102e"})]})]}),a.jsxs("label",{children:["Upload do logotipo (recomendado)",a.jsx("input",{type:"file",accept:"image/png,image/jpeg,image/webp,image/svg+xml",onChange:async e=>{const t=e.target.files?.[0];await q(t),e.target.value=""},disabled:n}),a.jsx("small",{className:"text-muted",children:n?"A otimizar e enviar logotipo...":"A imagem é otimizada automaticamente para documentos."})]}),T.logoUrl&&a.jsxs("div",{className:"form-group",children:[a.jsx("small",{className:"text-muted",children:"Pré-visualização do logotipo:"}),a.jsx("div",{style:{marginTop:"0.35rem",padding:"0.45rem",border:"1px solid #e2e8f0",borderRadius:"6px",background:"#fff"},children:a.jsx("img",{src:T.logoUrl,alt:"Preview logotipo da marca",style:{maxHeight:"42px",maxWidth:"170px",objectFit:"contain"}})})]})]}),a.jsxs("label",{children:["Modelo",a.jsx("input",{value:l.modelo,onChange:e=>x(t=>({...t,modelo:e.target.value})),placeholder:"Ex: EV-4P"})]}),a.jsxs("label",{children:["Nº Série",a.jsx("input",{required:!0,value:l.numeroSerie,onChange:e=>x(t=>({...t,numeroSerie:e.target.value})),placeholder:"Ex: NAV-EV-001"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Ano de fabrico",a.jsx("input",{type:"number",min:1900,max:2100,value:l.anoFabrico,onChange:e=>x(t=>({...t,anoFabrico:e.target.value?Number(e.target.value):""})),placeholder:"Ex: 2022"})]}),a.jsxs("label",{children:["Nº documento de venda",a.jsx("input",{value:l.numeroDocumentoVenda,onChange:e=>x(t=>({...t,numeroDocumentoVenda:e.target.value})),placeholder:"Ex: FV-2022-001"})]})]}),a.jsxs("label",{children:["Próxima data de manutenção",a.jsx("input",{type:"date",required:!0,value:l.proximaManut,onChange:e=>{const t=e.target.value;x(m=>({...m,proximaManut:t})),O(t)}}),Q&&a.jsx("span",{className:"form-aviso-data",children:Q})]}),o==="edit"&&(()=>{const e=r.find(t=>t.id===l.id);return!e||!Ga(e.subcategoriaId)||!e.ultimaManutencaoData&&e.horasTotaisAcumuladas==null&&e.horasServicoAcumuladas==null?null:a.jsxs("div",{className:"form-section horas-acumuladas-section",children:[a.jsx("h3",{children:"Contadores (atualizados à última manutenção)"}),a.jsxs("p",{className:"horas-info",children:[e.ultimaManutencaoData&&a.jsxs("span",{children:["Última manutenção: ",Ca(new Date(e.ultimaManutencaoData+"T12:00:00"),"d MMM yyyy",{locale:ya})]}),e.ultimaManutencaoData&&(e.horasTotaisAcumuladas!=null||e.horasServicoAcumuladas!=null)&&" · ",e.horasTotaisAcumuladas!=null&&a.jsxs("span",{children:["Horas totais: ",e.horasTotaisAcumuladas,"h"]}),e.horasTotaisAcumuladas!=null&&e.horasServicoAcumuladas!=null&&" · ",e.horasServicoAcumuladas!=null&&a.jsxs("span",{children:["Horas de serviço: ",e.horasServicoAcumuladas,"h"]})]})]})})(),sa(l.subcategoriaId)&&a.jsxs("div",{className:"form-section",children:[a.jsx("h3",{children:"Ciclo de manutenção KAESER (A/B/C/D)"}),a.jsx("p",{className:"horas-info",children:"Sequência anual: A → B → A → C → A → B → A → C → A → B → A → D (ciclo de 12 anos)"}),a.jsxs("label",{children:["Posição actual no ciclo (0 = Ano 1 Tipo A, 1 = Ano 2 Tipo B, ...)",a.jsx("select",{value:l.posicaoKaeser??0,onChange:e=>x(t=>({...t,posicaoKaeser:Number(e.target.value)})),children:ua.map((e,t)=>a.jsxs("option",{value:t,children:["Ano ",t+1," — Tipo ",e,t===(l.posicaoKaeser??0)?" (actual)":""]},t))})]}),l.posicaoKaeser!=null&&a.jsxs("p",{className:"horas-info",style:{marginTop:"0.25rem"},children:[a.jsx("strong",{children:"Próxima manutenção:"})," ",Ia((l.posicaoKaeser+1)%ua.length)]})]}),sa(l.subcategoriaId)&&a.jsxs("div",{className:"form-section consumiveis-section",children:[a.jsx("h3",{children:"Consumíveis (manutenção regular)"}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Refª kit manutenção 3000h",a.jsx("input",{value:l.refKitManut3000h,onChange:e=>x(t=>({...t,refKitManut3000h:e.target.value})),placeholder:"Ex: 1900 1466 00"})]}),a.jsxs("label",{children:["Refª kit manutenção 6000h",a.jsx("input",{value:l.refKitManut6000h,onChange:e=>x(t=>({...t,refKitManut6000h:e.target.value})),placeholder:"Ex: 1900 1467 00"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Refª correia",a.jsx("input",{value:l.refCorreia,onChange:e=>x(t=>({...t,refCorreia:e.target.value})),placeholder:"Ex: 1900 1468 00"})]}),a.jsxs("label",{children:["Refª filtro de óleo",a.jsx("input",{value:l.refFiltroOleo,onChange:e=>x(t=>({...t,refFiltroOleo:e.target.value})),placeholder:"Ex: 1900 1469 00"})]})]}),a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Refª filtro separador",a.jsx("input",{value:l.refFiltroSeparador,onChange:e=>x(t=>({...t,refFiltroSeparador:e.target.value})),placeholder:"Ex: 1900 1470 00"})]}),a.jsxs("label",{children:["Refª filtro do ar",a.jsx("input",{value:l.refFiltroAr,onChange:e=>x(t=>({...t,refFiltroAr:e.target.value})),placeholder:"Ex: 1900 1471 00"})]})]})]}),a.jsxs("div",{className:"form-actions",children:[a.jsx("button",{type:"button",className:"secondary",onClick:f,children:"Cancelar"}),a.jsx("button",{type:"submit",children:o==="add"?"Adicionar":"Guardar"})]})]})]})})}function Qa(d){const f=["A","B","C","D"],o={A:[],B:[],C:[],D:[]};let h=null;const c=d.split(/\r?\n/);for(const U of c){const $=U.trim();if(!$)continue;if(f.includes($)&&U.length<5){h=$;continue}const D=$.match(/^(\d{4})\s+/);if(!D||!h)continue;const j=D[1],r=$.slice(4).trim(),F=r.match(/\s+(\d+(?:[.,]\d+)?)\s+([A-ZÇ]{2,4})\s*$/);let v=1,i="PÇ",N=r;F&&(v=parseFloat(F[1].replace(",","."))||1,i=F[2].replace("Ç","Ç"),i==="PC"&&(i="PÇ"),N=r.slice(0,r.length-F[0].length).trim());const E=N.match(/^([\d.]+(?:E\d+)?)\s+(.+)$/s);let C="",u=N;if(E&&E[1].includes(".")){const b=E[1];/^[\d.]+(?:E\d+)?$/.test(b)&&(C=b,u=E[2].trim())}!u||u.length<2||o[h].push({posicao:j,codigoArtigo:C||j,descricao:u,quantidade:v,unidade:i})}return o}const xa=[{id:"A",label:"Tipo A",hint:"3.000h / 1 ano"},{id:"B",label:"Tipo B",hint:"6.000h"},{id:"C",label:"Tipo C",hint:"12.000h"},{id:"D",label:"Tipo D",hint:"36.000h"},{id:"periodica",label:"Periódica",hint:"Manutenção periódica standard"}],fa=["PÇ","TER","L","KG","M","UN"],oa={posicao:"",codigoArtigo:"",descricao:"",quantidade:1,unidade:"PÇ"};function pe({isOpen:d,onClose:f,maquina:o,modoInicial:h=!1}){const{getPecasPlanoByMaquina:c,addPecaPlano:U,addPecasPlanoLote:$,updatePecaPlano:D,removePecaPlano:j,removePecasPlanoByMaquina:r,getSubcategoria:F}=na(),{showToast:v}=la(),{showGlobalLoading:i,hideGlobalLoading:N}=Ea(),E=w.useRef(null),[C,u]=w.useState("A"),[b,_]=w.useState(oa),[Z,P]=w.useState(null),[k,K]=w.useState(oa),[Q,I]=w.useState(!1),[V,O]=w.useState(null),H=o?F(o.subcategoriaId):null;o&&Pa.includes(o.subcategoriaId);const l=o&&Fa(o.marca),x=l?xa:xa.filter(s=>s.id==="periodica");w.useEffect(()=>{x.length>0&&!x.some(s=>s.id===C)&&u(x[0].id)},[o?.id,x,C]);const G=w.useMemo(()=>o?c(o.id,C):[],[o,C,c]),z=w.useMemo(()=>o?c(o.id).length:0,[o,c]);if(!d||!o)return null;const B=s=>{if(s.preventDefault(),!b.codigoArtigo.trim()||!b.descricao.trim()){v("Código de artigo e descrição são obrigatórios.","warning");return}U({...b,maquinaId:o.id,tipoManut:C}),_(oa),v("Peça adicionada ao plano.","success")},T=s=>{if(!k.codigoArtigo.trim()||!k.descricao.trim()){v("Código de artigo e descrição são obrigatórios.","warning");return}D(s,k),P(null),v("Peça actualizada.","success")},R=async s=>{const p=s.target.files?.[0];if(!(!p||!o)){if(s.target.value="",!p.name.toLowerCase().endsWith(".pdf")){v("Seleccione um ficheiro PDF.","warning");return}i();try{const{PDFParse:M}=await ja(async()=>{const{PDFParse:m}=await import("./pdf-parse.es-DWQLbnCA.js");return{PDFParse:m}},[]);M.setWorker("/manut/pdf.worker.mjs");const Y=await p.arrayBuffer(),W=new M({data:new Uint8Array(Y)}),{text:X}=await W.getText();W.destroy?.();const q=Qa(X||""),e=[];for(const m of["A","B","C","D"])for(const S of q[m]||[])e.push({...S,maquinaId:o.id,tipoManut:m});if(e.length===0){v("Não foi possível extrair peças do PDF. Verifique se o formato é um plano KAESER A/B/C/D.","warning");return}r(o.id),$(e);const t={A:0,B:0,C:0,D:0};e.forEach(m=>{t[m.tipoManut]=(t[m.tipoManut]||0)+1}),v(`${e.length} peças importadas (A: ${t.A}, B: ${t.B}, C: ${t.C}, D: ${t.D}).`,"success")}catch(M){v(`Erro ao ler PDF: ${M?.message||"desconhecido"}`,"error")}finally{N()}}},n=()=>{G.forEach(s=>j(s.id)),I(!1),v(`Plano Tipo ${C} limpo.`,"success")},y=()=>{r(o.id),I(!1),v("Todos os planos desta máquina foram eliminados.","success")};return a.jsx("div",{className:"modal-overlay",onClick:f,children:a.jsxs("div",{className:"modal modal-pecas-plano",onClick:s=>s.stopPropagation(),children:[a.jsxs("div",{className:"modal-pecas-header",children:[a.jsxs("div",{children:[a.jsxs("h2",{children:[a.jsx(Va,{size:20})," Plano de peças e consumíveis"]}),a.jsxs("p",{className:"modal-pecas-sub",children:[o.marca," ",o.modelo," — Nº Série: ",a.jsx("strong",{children:o.numeroSerie}),H&&a.jsxs(a.Fragment,{children:["  ·  ",H.nome]})]})]}),a.jsx("button",{className:"icon-btn",onClick:f,title:"Fechar",children:a.jsx(ma,{size:20})})]}),a.jsxs("div",{className:"modal-pecas-tabs",children:[x.map(s=>{const p=o?c(o.id,s.id).length:0;return a.jsxs("button",{className:`tab-tipo ${C===s.id?"active":""}`,onClick:()=>{u(s.id),P(null),_(oa)},children:[a.jsx("span",{className:"tab-tipo-label",children:s.label}),a.jsx("span",{className:"tab-tipo-hint",children:s.hint}),p>0&&a.jsx("span",{className:"tab-tipo-count",children:p})]},s.id)}),a.jsx("span",{className:"tab-total",children:z>0?`${z} peças no total`:"Sem peças configuradas"})]}),h&&z===0&&a.jsxs("div",{className:"modal-pecas-boas-vindas",children:[a.jsx("strong",{children:"Equipamento criado!"}),l?a.jsxs(a.Fragment,{children:[" Configure o plano de consumíveis deste compressor KAESER. Use ",a.jsx("em",{children:'"Importar template para esta máquina"'})," para carregar o plano a partir do PDF e ajuste os artigos ao número de série."]}):a.jsx(a.Fragment,{children:" Configure os consumíveis recomendados para as manutenções periódicas deste equipamento. Adicione cada artigo manualmente."})]}),l&&C!=="periodica"&&a.jsxs("div",{className:"modal-pecas-import",children:[a.jsx("input",{ref:E,type:"file",accept:".pdf",className:"hidden-file-input",onChange:R,"aria-label":"Seleccionar PDF do plano de manutenção"}),a.jsx("span",{className:"import-hint",children:"Selecione o PDF do plano de manutenção desta máquina (formato KAESER A/B/C/D)."}),a.jsxs("button",{type:"button",className:"btn btn-sm primary",onClick:()=>E.current?.click(),children:[a.jsx(Ua,{size:14})," Importar template para esta máquina"]})]}),a.jsx("div",{className:"modal-pecas-table-wrap",children:G.length===0?a.jsxs("p",{className:"modal-pecas-vazio",children:["Sem peças configuradas para ",a.jsxs("strong",{children:["Tipo ",C==="periodica"?"Periódica":C]}),".",l&&C!=="periodica"&&' Use "Importar template para esta máquina" para carregar o plano a partir de um PDF.',!l&&" Adicione cada consumível manualmente no formulário abaixo."]}):a.jsxs("table",{className:"tabela-pecas",children:[a.jsx("thead",{children:a.jsxs("tr",{children:[a.jsx("th",{children:"Pos."}),a.jsx("th",{children:"Código artigo"}),a.jsx("th",{children:"Descrição"}),a.jsx("th",{children:"Qtd"}),a.jsx("th",{children:"Un."}),a.jsx("th",{})]})}),a.jsx("tbody",{children:G.map(s=>Z===s.id?a.jsxs("tr",{className:"row-edit",children:[a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:k.posicao,onChange:p=>K(M=>({...M,posicao:p.target.value})),placeholder:"Ex: 0512",style:{width:"60px"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:k.codigoArtigo,onChange:p=>K(M=>({...M,codigoArtigo:p.target.value})),required:!0,style:{width:"130px"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",value:k.descricao,onChange:p=>K(M=>({...M,descricao:p.target.value})),required:!0,style:{width:"100%"}})}),a.jsx("td",{children:a.jsx("input",{className:"input-sm",type:"number",min:.01,step:.01,value:k.quantidade,onChange:p=>K(M=>({...M,quantidade:parseFloat(p.target.value)||1})),style:{width:"60px"}})}),a.jsx("td",{children:a.jsx("select",{className:"input-sm",value:k.unidade,onChange:p=>K(M=>({...M,unidade:p.target.value})),children:fa.map(p=>a.jsx("option",{children:p},p))})}),a.jsxs("td",{className:"cell-actions",children:[a.jsx("button",{className:"icon-btn success",onClick:()=>T(s.id),title:"Guardar",children:a.jsx(Ra,{size:14})}),a.jsx("button",{className:"icon-btn",onClick:()=>P(null),title:"Cancelar",children:a.jsx(ma,{size:14})})]})]},s.id):a.jsxs("tr",{children:[a.jsx("td",{className:"cell-pos",children:s.posicao||"—"}),a.jsx("td",{className:"cell-code",children:s.codigoArtigo}),a.jsx("td",{children:s.descricao}),a.jsx("td",{className:"cell-qty",children:s.quantidade}),a.jsx("td",{className:"cell-un",children:s.unidade}),a.jsxs("td",{className:"cell-actions",children:[a.jsx("button",{className:"icon-btn secondary",onClick:()=>{P(s.id),K({posicao:s.posicao||"",codigoArtigo:s.codigoArtigo,descricao:s.descricao,quantidade:s.quantidade,unidade:s.unidade})},title:"Editar",children:a.jsx(_a,{size:14})}),V===s.id?a.jsxs(a.Fragment,{children:[a.jsx("button",{className:"icon-btn danger",onClick:()=>{j(s.id),O(null),v("Peça removida.","success")},title:"Confirmar",children:"Sim"}),a.jsx("button",{className:"icon-btn secondary",onClick:()=>O(null),title:"Cancelar",children:"Não"})]}):a.jsx("button",{className:"icon-btn danger",onClick:()=>O(s.id),title:"Remover",children:a.jsx(ia,{size:14})})]})]},s.id))})]})}),a.jsxs("form",{className:"modal-pecas-add-row",onSubmit:B,children:[a.jsx("input",{className:"input-sm",placeholder:"Posição",value:b.posicao,onChange:s=>_(p=>({...p,posicao:s.target.value})),style:{width:"65px",flexShrink:0}}),a.jsx("input",{className:"input-sm",placeholder:"Código artigo *",value:b.codigoArtigo,onChange:s=>_(p=>({...p,codigoArtigo:s.target.value})),style:{width:"135px",flexShrink:0}}),a.jsx("input",{className:"input-sm",placeholder:"Descrição *",value:b.descricao,onChange:s=>_(p=>({...p,descricao:s.target.value})),style:{flex:1}}),a.jsx("input",{className:"input-sm",type:"number",min:.01,step:.01,value:b.quantidade,onChange:s=>_(p=>({...p,quantidade:parseFloat(s.target.value)||1})),style:{width:"60px",flexShrink:0}}),a.jsx("select",{className:"input-sm",value:b.unidade,onChange:s=>_(p=>({...p,unidade:s.target.value})),style:{width:"70px",flexShrink:0},children:fa.map(s=>a.jsx("option",{children:s},s))}),a.jsxs("button",{type:"submit",className:"btn btn-sm primary",style:{flexShrink:0},children:[a.jsx(Aa,{size:14})," Adicionar"]})]}),a.jsx("div",{className:"modal-pecas-footer",children:Q?a.jsxs("div",{className:"confirmar-limpar",children:[a.jsx("span",{children:"Eliminar:"}),a.jsxs("button",{className:"btn btn-sm danger",onClick:n,children:["Só Tipo ",C==="periodica"?"Periódica":C," (",G.length,")"]}),a.jsxs("button",{className:"btn btn-sm danger",onClick:y,children:["Toda a máquina (",z,")"]}),a.jsx("button",{className:"btn btn-sm",onClick:()=>I(!1),children:"Cancelar"})]}):a.jsxs(a.Fragment,{children:[z>0&&a.jsxs("button",{className:"btn btn-sm btn-outline-muted",onClick:()=>I(!0),children:[a.jsx(ia,{size:13})," Limpar plano…"]}),a.jsx("button",{className:"btn secondary",onClick:f,style:{marginLeft:"auto"},children:"Fechar"})]})})]})})}function he({isOpen:d,onClose:f,maquina:o}){const{maquinas:h,addDocumentoMaquina:c,removeDocumentoMaquina:U}=na(),{showToast:$}=la(),{isAdmin:D}=za(),[j,r]=w.useState({tipo:"manual_utilizador",titulo:"",url:""}),[F,v]=w.useState(null);if(!d)return null;const i=h.find(u=>u.id===o?.id)??o,N=i?i.documentos??[]:[],E=u=>pa.find(b=>b.id===u)?.label??u,C=u=>{if(u.preventDefault(),!j.titulo.trim()||!j.url.trim())return;const b=ha(j.url.trim());if(b==="#"){$("URL inválida. Use um link que comece por https:// ou http://","warning");return}c(i.id,{tipo:j.tipo,titulo:j.titulo.trim(),url:b}),r({tipo:"manual_utilizador",titulo:"",url:""})};return a.jsx("div",{className:"modal-overlay",onClick:f,children:a.jsxs("div",{className:"modal modal-documentacao",onClick:u=>u.stopPropagation(),children:[a.jsxs("h2",{children:["Documentação — ",i?.marca," ",i?.modelo]}),a.jsx("p",{className:"modal-hint",children:"Adicione manuais, esquemas e planos de manutenção para os técnicos consultarem."}),ba.includes(i?.subcategoriaId)&&(i?.ultimaManutencaoData||i?.horasTotaisAcumuladas!=null||i?.horasServicoAcumuladas!=null)&&a.jsxs("div",{className:"consumiveis-card",children:[a.jsx("h4",{children:"Contadores (à data da última manutenção)"}),a.jsxs("div",{className:"consumiveis-grid",children:[i.ultimaManutencaoData&&a.jsxs("span",{children:[a.jsx("strong",{children:"Última manut.:"})," ",Ca(ra(i.ultimaManutencaoData),"d MMM yyyy",{locale:ya})]}),i.horasTotaisAcumuladas!=null&&a.jsxs("span",{children:[a.jsx("strong",{children:"Horas totais:"})," ",i.horasTotaisAcumuladas,"h"]}),i.horasServicoAcumuladas!=null&&a.jsxs("span",{children:[a.jsx("strong",{children:"Horas serviço:"})," ",i.horasServicoAcumuladas,"h"]})]})]}),["sub5","sub14"].includes(i?.subcategoriaId)&&(i?.refKitManut3000h||i?.refKitManut6000h||i?.refCorreia||i?.refFiltroOleo||i?.refFiltroSeparador||i?.refFiltroAr)&&a.jsxs("div",{className:"consumiveis-card",children:[a.jsx("h4",{children:"Consumíveis"}),a.jsxs("div",{className:"consumiveis-grid",children:[i.refKitManut3000h&&a.jsxs("span",{children:[a.jsx("strong",{children:"Kit 3000h:"})," ",i.refKitManut3000h]}),i.refKitManut6000h&&a.jsxs("span",{children:[a.jsx("strong",{children:"Kit 6000h:"})," ",i.refKitManut6000h]}),i.refCorreia&&a.jsxs("span",{children:[a.jsx("strong",{children:"Correia:"})," ",i.refCorreia]}),i.refFiltroOleo&&a.jsxs("span",{children:[a.jsx("strong",{children:"Filtro óleo:"})," ",i.refFiltroOleo]}),i.refFiltroSeparador&&a.jsxs("span",{children:[a.jsx("strong",{children:"Filtro separador:"})," ",i.refFiltroSeparador]}),i.refFiltroAr&&a.jsxs("span",{children:[a.jsx("strong",{children:"Filtro ar:"})," ",i.refFiltroAr]})]})]}),a.jsxs("div",{className:"doc-lista",children:[N.map(u=>a.jsxs("div",{className:"doc-item",children:[a.jsxs("div",{className:"doc-item-info",children:[a.jsx("span",{className:"doc-tipo",children:E(u.tipo)}),a.jsx("span",{className:"doc-titulo",children:u.titulo})]}),a.jsxs("div",{className:"doc-item-actions",children:[a.jsx("a",{href:ha(u.url),target:"_blank",rel:"noopener noreferrer",className:"icon-btn secondary",title:"Abrir",children:a.jsx(Ka,{size:16})}),D&&F===u.id?a.jsxs(a.Fragment,{children:[a.jsx("button",{type:"button",className:"icon-btn danger",onClick:()=>{U(i.id,u.id),v(null),$("Documento removido.","success")},title:"Confirmar",children:"Sim"}),a.jsx("button",{type:"button",className:"icon-btn secondary",onClick:()=>v(null),title:"Cancelar",children:"Não"})]}):D&&a.jsx("button",{type:"button",className:"icon-btn danger",onClick:()=>v(u.id),title:"Remover",children:a.jsx(ia,{size:16})})]})]},u.id)),N.length===0&&a.jsx("p",{className:"doc-empty",children:"Nenhum documento associado."})]}),D&&a.jsxs("form",{onSubmit:C,className:"form-add-doc",children:[a.jsxs("div",{className:"form-row",children:[a.jsxs("label",{children:["Tipo",a.jsx("select",{value:j.tipo,onChange:u=>r(b=>({...b,tipo:u.target.value})),children:pa.map(u=>a.jsx("option",{value:u.id,children:u.label},u.id))})]}),a.jsxs("label",{style:{flex:1},children:["Título",a.jsx("input",{value:j.titulo,onChange:u=>r(b=>({...b,titulo:u.target.value})),placeholder:"Ex: Manual GA-22",required:!0})]})]}),a.jsxs("label",{children:["URL (link para PDF ou ficheiro)",a.jsx("input",{type:"url",value:j.url,onChange:u=>r(b=>({...b,url:u.target.value})),placeholder:"https://...",required:!0})]}),a.jsxs("button",{type:"submit",className:"btn-add-doc",children:[a.jsx(Aa,{size:16})," Adicionar documento"]})]}),a.jsx("div",{className:"form-actions",style:{marginTop:"1rem"},children:a.jsx("button",{type:"button",className:"secondary",onClick:f,children:"Fechar"})})]})})}function ge({maquina:d,cliente:f,subcategoria:o,categoria:h,manutencoes:c=[],relatorios:U=[],reparacoes:$=[],tecnicos:D=[],logoUrl:j}){const r=Ha,F=j??"/manut/logo-navel.png",v=new Date,i=v.toLocaleString("pt-PT",{dateStyle:"long",timeStyle:"short",timeZone:"Atlantic/Azores"}),N=[...c].sort((n,y)=>y.data.localeCompare(n.data)),E=N.length,C=N.filter(n=>n.status==="concluida"),u=N.filter(n=>n.status!=="concluida"),b=u.filter(n=>ra(n.data)<v),_=u.filter(n=>ra(n.data)>=v),Z=C[0],P=_.reduce((n,y)=>!n||y.data<n.data?y:n,null),k=Z?J(Z.data,!0):"—",K=P?J(P.data,!0):"—",Q=d.proximaManut?J(d.proximaManut,!0):K,I=C.map(n=>U.find(y=>y.manutencaoId===n.id)).find(n=>n?.assinaturaDigital),V=I?.assinaturaDigital?ga(I.assinaturaDigital):null,O=Z?.tecnico||I?.tecnico||null,H=O?D.find(n=>n.nome===O&&n.ativo!==!1):null,l=H?.assinaturaDigital?ga(H.assinaturaDigital):null,x=o?`${o.nome} — ${d.marca} ${d.modelo}`:`${d.marca} ${d.modelo}`,G=(n,y)=>{const s=U.find(t=>t.manutencaoId===n.id),p=n.tipo==="montagem"?"Montagem":"Periódica",M=J(n.data,!0),Y=r(s?.tecnico??n.tecnico??"—"),W=s?.nomeAssinante?r(s.nomeAssinante):"—",X=s?.notas?r(s.notas.length>90?s.notas.slice(0,90)+"…":s.notas):"—",q=n.status==="concluida"?'<span class="badge-ok">Executada</span>':ra(n.data)<v?'<span class="badge-err">Em atraso</span>':'<span class="badge-pend">Agendada</span>';return`<tr${y%2===1?' class="row-alt"':""}>
      <td class="td-c">${y+1}</td>
      <td>${M}</td>
      <td class="td-c">${p}</td>
      <td class="td-c">${q}</td>
      <td>${Y}</td>
      <td>${W}</td>
      <td class="td-notes">${X}</td>
    </tr>`},z=[...$].sort((n,y)=>(y.data||"").localeCompare(n.data||"")),B={pendente:"Pendente",em_progresso:"Em progresso",concluida:"Concluída"},T={pendente:"badge-pend",em_progresso:"badge-pend",concluida:"badge-ok"},R=(n,y)=>{const s=n.data?J(n.data,!0):"—",p=r(n.tecnico??"—"),M=`<span class="${T[n.status]??"badge-pend"}">${B[n.status]??n.status}</span>`,Y=r((n.descricaoAvaria||"—").slice(0,100)),W=r((n.observacoes||"—").slice(0,80));return`<tr${y%2===1?' class="row-alt"':""}>
      <td class="td-c">${y+1}</td>
      <td>${s}</td>
      <td>${p}</td>
      <td class="td-c">${M}</td>
      <td class="td-notes">${Y}</td>
      <td class="td-notes">${W}</td>
    </tr>`};return`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Histórico de Manutenção — ${r(d.marca)} ${r(d.modelo)}</title>
<style>
@page { size: A4 portrait; margin: 10mm 13mm; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Segoe UI', Arial, sans-serif; font-size: 10.5px; line-height: 1.4; color: #1a1a2e; background: #fff; }

:root {
  --azul:#1a4880; --azul-med:#2d6eb5; --azul-claro:#e8f2fa;
  --cinza:#f4f6f8; --borda:#c6d8ec; --texto:#1a1a2e; --muted:#5a6a7e;
  --verde:#16a34a; --vermelho:#dc2626; --laranja:#d97706; --acento:#f0a500;
}

/* ── Cabeçalho ── */
.rpt-header { display:flex; align-items:flex-start; justify-content:space-between; gap:12px; padding-bottom:8px; border-bottom:2.5px solid var(--azul); }
.rpt-logo img { max-height:38px; max-width:140px; object-fit:contain; display:block; }
.rpt-empresa { text-align:right; font-size:8.5px; line-height:1.55; color:var(--muted); }
.rpt-empresa strong { display:block; font-size:9.5px; color:var(--azul); margin-bottom:1px; }

/* ── Barra de título ── */
.rpt-titulo-bar { display:flex; align-items:center; justify-content:space-between; background:var(--azul); color:#fff; padding:5px 10px; margin:7px 0 0; border-radius:3px; }
.rpt-titulo-bar h1 { font-size:11px; font-weight:700; letter-spacing:.07em; text-transform:uppercase; }
.rpt-gerado { font-size:7.5px; opacity:.75; }
.rpt-acento { height:2px; background:linear-gradient(90deg,var(--acento),var(--azul-med)); margin-bottom:11px; border-radius:0 0 2px 2px; }

/* ── Ficha do equipamento ── */
.section-title { font-size:8.5px; font-weight:700; text-transform:uppercase; letter-spacing:.1em; color:var(--azul-med); border-bottom:1px solid var(--borda); padding-bottom:3px; margin:0 0 6px; }
.ficha-grid { display:grid; grid-template-columns:1fr 1fr; gap:0; border:1px solid var(--borda); border-radius:4px; overflow:hidden; margin-bottom:10px; }
.ficha-col { padding:8px 10px; }
.ficha-col + .ficha-col { border-left:1px solid var(--borda); background:var(--cinza); }
.ficha-field { margin-bottom:5px; }
.ficha-field:last-child { margin-bottom:0; }
.ficha-label { display:block; font-size:7.5px; font-weight:700; text-transform:uppercase; letter-spacing:.05em; color:var(--muted); margin-bottom:1px; }
.ficha-value { font-size:10.5px; color:var(--texto); font-weight:500; }
.ficha-value-lg { font-size:13px; font-weight:700; color:var(--azul); }

/* ── Estatísticas ── */
.stats-row { display:grid; grid-template-columns:repeat(5,1fr); gap:6px; margin-bottom:12px; }
.stat-box { border:1px solid var(--borda); border-radius:4px; padding:6px 8px; text-align:center; background:var(--cinza); }
.stat-num { display:block; font-size:18px; font-weight:800; line-height:1.1; color:var(--azul); }
.stat-num.red { color:var(--vermelho); }
.stat-num.green { color:var(--verde); }
.stat-num.orange { color:var(--laranja); }
.stat-lbl { display:block; font-size:7.5px; color:var(--muted); text-transform:uppercase; letter-spacing:.04em; margin-top:2px; }

/* ── Tabela histórico ── */
.hist-table { width:100%; border-collapse:collapse; font-size:9px; margin-bottom:14px; page-break-inside:auto; }
.hist-table th { background:var(--azul); color:#fff; padding:4px 6px; text-align:left; font-size:8px; font-weight:600; letter-spacing:.05em; text-transform:uppercase; white-space:nowrap; }
.hist-table td { padding:4px 6px; border-bottom:1px solid #edf2f7; vertical-align:top; }
.hist-table tr.row-alt td { background:var(--cinza); }
.td-c { text-align:center; }
.td-notes { font-size:8.5px; color:var(--muted); max-width:140px; }

/* ── Badges ── */
.badge-ok   { background:rgba(22,163,74,.14);  color:var(--verde);    padding:1px 5px; border-radius:8px; font-size:8px; font-weight:700; white-space:nowrap; }
.badge-err  { background:rgba(220,38,38,.12);  color:var(--vermelho); padding:1px 5px; border-radius:8px; font-size:8px; font-weight:700; white-space:nowrap; }
.badge-pend { background:rgba(217,119,6,.12);  color:var(--laranja);  padding:1px 5px; border-radius:8px; font-size:8px; font-weight:700; white-space:nowrap; }

/* ── Assinatura ── */
.assin-box { border:1px solid var(--borda); border-radius:4px; padding:8px 10px; background:var(--cinza); display:inline-block; margin-bottom:12px; }
.assin-box img { display:block; max-width:200px; max-height:80px; margin-top:5px; border:1px solid var(--borda); background:#fff; border-radius:3px; }
.assin-meta { font-size:8.5px; color:var(--muted); margin-top:3px; }

/* ── Rodapé ── */
.rpt-footer { margin-top:10px; padding-top:6px; border-top:1px solid var(--borda); display:flex; justify-content:space-between; font-size:8.5px; color:var(--muted); }

@media print {
  .hist-table tr { page-break-inside:avoid; }
  .hist-table thead { display:table-header-group; }
}
</style>
</head>
<body>

<header class="rpt-header">
  <div class="rpt-logo">
    <img src="${F}" alt="Navel"
      onerror="this.parentNode.innerHTML='<strong style=color:#1a4880;font-size:14px>NAVEL</strong>'">
  </div>
  <div class="rpt-empresa">
    <strong>${r(aa.nome)}</strong>
    ${r(aa.divisaoComercial)}<br>
    ${r(aa.sede)}<br>
    ${r(aa.telefones)} &nbsp;|&nbsp; ${r(aa.web)}
  </div>
</header>

<div class="rpt-titulo-bar">
  <h1>Histórico Completo de Manutenção</h1>
  <span class="rpt-gerado">Gerado em ${i}</span>
</div>
<div class="rpt-acento"></div>

<div class="section-title">Ficha do equipamento</div>
<div class="ficha-grid">
  <div class="ficha-col">
    <div class="ficha-field">
      <span class="ficha-label">Equipamento</span>
      <span class="ficha-value ficha-value-lg">${r(d.marca)} ${r(d.modelo)}</span>
    </div>
    <div class="ficha-field">
      <span class="ficha-label">Nº de Série</span>
      <span class="ficha-value">${r(d.numeroSerie||"—")}</span>
    </div>
    ${o?`<div class="ficha-field">
      <span class="ficha-label">Tipo / Subcategoria</span>
      <span class="ficha-value">${r(o.nome)}${h?` &mdash; ${r(h.nome)}`:""}</span>
    </div>`:""}
    ${d.localizacao?`<div class="ficha-field">
      <span class="ficha-label">Localização</span>
      <span class="ficha-value">${r(d.localizacao)}</span>
    </div>`:""}
  </div>
  <div class="ficha-col">
    <div class="ficha-field">
      <span class="ficha-label">Cliente</span>
      <span class="ficha-value ficha-value-lg">${r(f?.nome??"—")}</span>
    </div>
    ${f?.nif?`<div class="ficha-field">
      <span class="ficha-label">NIF</span>
      <span class="ficha-value">${r(f.nif)}</span>
    </div>`:""}
    ${f?.morada?`<div class="ficha-field">
      <span class="ficha-label">Morada</span>
      <span class="ficha-value">${r(f.morada)}</span>
    </div>`:""}
    <div class="ficha-field">
      <span class="ficha-label">Próxima manutenção</span>
      <span class="ficha-value">${Q}</span>
    </div>
  </div>
</div>

<div class="section-title">Estatísticas globais</div>
<div class="stats-row">
  <div class="stat-box">
    <span class="stat-num">${E}</span>
    <span class="stat-lbl">Total</span>
  </div>
  <div class="stat-box">
    <span class="stat-num green">${C.length}</span>
    <span class="stat-lbl">Executadas</span>
  </div>
  <div class="stat-box">
    <span class="stat-num orange">${_.length}</span>
    <span class="stat-lbl">Agendadas</span>
  </div>
  <div class="stat-box">
    <span class="stat-num${b.length>0?" red":""}">${b.length}</span>
    <span class="stat-lbl">Em atraso</span>
  </div>
  <div class="stat-box">
    <span class="stat-num" style="font-size:${k.length>8?"9":"13"}px;padding-top:${k.length>8?"5":"2"}px">${k}</span>
    <span class="stat-lbl">Última execução</span>
  </div>
</div>

<div class="section-title">
  Registo histórico — ${E} intervenç${E===1?"ão":"ões"} (mais recente primeiro)
</div>
${E===0?'<p style="color:#5a6a7e;font-size:10px;margin-bottom:12px;font-style:italic">Nenhuma manutenção registada para este equipamento.</p>':`<table class="hist-table">
  <thead>
    <tr>
      <th class="td-c" style="width:22px">#</th>
      <th style="width:62px">Data</th>
      <th class="td-c" style="width:58px">Tipo</th>
      <th class="td-c" style="width:68px">Estado</th>
      <th style="width:80px">Técnico</th>
      <th style="width:90px">Assinado por</th>
      <th>Observações</th>
    </tr>
  </thead>
  <tbody>
    ${N.map((n,y)=>G(n,y)).join(`
    `)}
  </tbody>
</table>`}

${z.length>0?`
<div class="section-title" style="margin-top:14px">
  Reparações — ${z.length} registo${z.length===1?"":"s"}
</div>
<table class="hist-table">
  <thead>
    <tr>
      <th class="td-c" style="width:22px">#</th>
      <th style="width:62px">Data</th>
      <th style="width:70px">Técnico</th>
      <th class="td-c" style="width:68px">Estado</th>
      <th>Descrição da avaria</th>
      <th>Observações</th>
    </tr>
  </thead>
  <tbody>
    ${z.map((n,y)=>R(n,y)).join(`
    `)}
  </tbody>
</table>`:""}

${V||l?`<div class="section-title">Última assinatura registada</div>
<div style="display:grid;grid-template-columns:1fr 1fr;gap:10px">
  ${l?`<div class="assin-box">
    <span class="ficha-label">Técnico responsável</span>
    <div style="font-weight:600;font-size:10px;margin:3px 0">${r(H?.nome||"")}</div>
    ${H?.telefone?`<div style="font-size:8px;color:#666">Tel: ${r(H.telefone)}</div>`:""}
    <img src="${l}" alt="Assinatura do técnico" style="max-height:50px">
  </div>`:"<div></div>"}
  ${V?`<div class="assin-box">
    <span class="ficha-label">Assinatura do cliente</span>
    <img src="${V}" alt="Assinatura do cliente" style="max-height:50px">
    ${I?.nomeAssinante?`<div class="assin-meta">Assinado por: <strong>${r(I.nomeAssinante)}</strong>${I.dataAssinatura?` &nbsp;&mdash;&nbsp; ${La(I.dataAssinatura)}`:""}</div>`:""}
  </div>`:"<div></div>"}
</div>`:""}

<footer class="rpt-footer">
  <span>${r(ka)}</span>
  <span>${r(x)} &nbsp;&middot;&nbsp; S/N: ${r(d.numeroSerie||"—")}</span>
</footer>

</body>
</html>`}export{he as D,ue as F,me as M,pe as P,Va as a,ge as g};
