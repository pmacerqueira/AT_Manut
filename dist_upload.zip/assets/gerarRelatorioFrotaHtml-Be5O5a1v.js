import{e as wt}from"./horasContadorEquipamento-CtzZOQDv.js";import{f as yt,n as p,d as zt,r as Et,m as qt,e as Ct,h as Mt,i as At,k as L,o as Q,q as St,p as it}from"./index-BWdHbKeY.js";import{d as s,h as Nt,e as It,f as Ft,i as Dt}from"./gerarHtmlHistoricoMaquina-B4B7zyCE.js";import"./vendor-Bk0NZ5Or.js";import"./vendor-pdf-hYLUQ4hX.js";import"./vendor-icons-Xj5hpEcu.js";import"./vendor-datefns-CCZTWiZ_.js";import"./kaeserCiclo-BSrwchLP.js";import"./pt-DInhV8Fk.js";import"./apiService-B-7NRfzQ.js";import"./empresa-pV7uX3IF.js";const Rt=5,nt=3,ct=2,B=i=>{if(!i)return"—";const l=String(i).slice(0,10).split("-");return l.length<3?String(i):`${l[2]}-${l[1]}-${l[0]}`};function Pt(i){const l=String(i??"/manut/logo-navel.png").trim();if(/^https?:\/\//i.test(l))return l;const b=l.startsWith("/")?l:`/${l}`;return typeof window<"u"&&window.location?.origin?`${window.location.origin}${b}`:`https://www.navel.pt${b}`}function Vt(i,l,b,Z,dt=[],pt,mt,x={}){const o=wt,ut=Pt(x.logoUrl),E=new Date().toISOString().slice(0,10),ft=yt(E,!0),O=new Date().getFullYear(),q=!!x.periodoCustom,tt=!!x.emailFragment,et=x.periodoLabel||String(O),at=x.periodoInicio??null,ot=x.periodoFim??null,_=t=>!(!t||at&&t<at||ot&&t>ot),H=new Set(l.map(t=>p(t.id))),C=b.filter(t=>H.has(p(t.maquinaId))),M=dt.filter(t=>H.has(p(t.maquinaId))),A=new Map;C.forEach(t=>{const e=p(t.maquinaId);A.has(e)||A.set(e,[]),A.get(e).push(t)});const S=new Map;M.forEach(t=>{const e=p(t.maquinaId);S.has(e)||S.set(e,[]),S.get(e).push(t)});const N=new Map;for(const t of Z){const e=zt(t);e&&Et(t,H,C,b,l)&&N.set(e,qt(N.get(e),t))}const $=l.map(t=>{const e=pt(t.subcategoriaId),a=e?mt(e.categoriaId):null,r=p(t.id),g=A.get(r)||[],k=S.get(r)||[],{dataUltimaKey:w,ultima:m,relUltima:X}=Ct(t,g,Z,N,b,l),Y=Mt(m,w),R=At(t,g,Y),K=R.registo,u=R.dataKey||"",h=!!(u&&u<E),y=g.filter(L).length,V=k.filter(d=>d.status==="concluida").length,G=k.filter(d=>d.status!=="concluida").length;let P=null;u&&(P=Math.floor((it(E)-it(u))/864e5));let c;!w&&!u?c="instalar":h?c="atraso":c="conforme";let v,T;c==="instalar"?(v="badge-montagem",T="Por instalar"):c==="atraso"?(v="badge-atraso",T="Não conforme"):(v="badge-ok",T="Conforme");const j=g.filter(L).filter(d=>d.data!=null&&d.data!=="").sort((d,z)=>String(z.data).localeCompare(String(d.data)));let f={nivel:"neutro",texto:"—",cor:s.muted};if(j.length>=2){const z=j.slice(0,Rt).map(J=>N.get(p(J.id))).filter(Boolean).reduce((J,rt)=>{const $t=rt.checklistSnapshot??[];return J+$t.filter(kt=>rt.checklistRespostas?.[kt.id]==="nao").length},0);h?f={nivel:"critico",texto:"⚠ Atraso",cor:s.vermelho}:z===0&&j.length>=nt?f={nivel:"excelente",texto:"★ Excelente",cor:s.verde}:z===0?f={nivel:"bom",texto:"● Conforme",cor:s.verde}:z<=ct?f={nivel:"atencao",texto:"◐ Atenção",cor:s.amarelo}:f={nivel:"critico",texto:"⚠ Crítico",cor:s.vermelho}}else j.length===0&&c==="instalar"?f={nivel:"novo",texto:"○ Novo",cor:s.muted}:h&&(f={nivel:"critico",texto:"⚠ Atraso",cor:s.vermelho});return{m:t,sub:e,cat:a,ultima:m,dataUltimaKey:w,proxima:K,emAtraso:h,diasAtraso:P,totalManuts:y,totalReps:V,repsAbertas:G,relUltima:X,estado:c,estadoBadge:v,estadoLabel:T,tendencia:f,proxDataKey:u}}),U=l.length,I=$.filter(t=>t.estado==="atraso").length,gt=$.filter(t=>t.estado==="conforme").length,W=U>0?Math.round(gt/U*100):0,ht=q?C.filter(t=>L(t)&&_(Q(t.data))).length:C.filter(t=>L(t)&&t.data?.startsWith(String(O))).length,vt=q?M.filter(t=>t.status==="concluida"&&_(Q(t.data))).length:M.filter(t=>t.status==="concluida"&&t.data?.startsWith(String(O))).length,bt=$.reduce((t,e)=>t+e.repsAbertas,0),F=new Map;$.forEach(t=>{const e=t.cat?.id||"_sem_categoria",a=t.cat?.nome||"Sem categoria";F.has(e)||F.set(e,{nome:a,linhas:[]}),F.get(e).linhas.push(t)});const xt=new Date(Date.now()-365*864e5).toISOString().slice(0,10),D=M.filter(t=>t.status!=="concluida"?!1:q?_(Q(t.data)):t.data>=xt).sort((t,e)=>e.data.localeCompare(t.data)).slice(0,20),st=`<style type="text/css">${Dt(s.azulNavel,"rgba(26,72,128,0.12)")}
@page { size: A4 portrait; margin: 14mm 12mm 12mm }
:root { --verde-light: #dcfce7; --vermelho-light: #fee2e2; --laranja-light: #fef3c7 }
.secao-titulo{background:var(--azul);color:var(--branco);padding:5px 10px;font-size:9pt;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px;border-radius:3px}
.secao-titulo.vermelho{background:#b91c1c}
.secao-titulo.laranja{background:#a16207}
.cliente-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:4px 12px;padding:8px 10px;background:var(--cinza);border-radius:4px;border:1px solid var(--borda);border-top:3px solid var(--azul);margin-bottom:10px}
/* Outlook ignora flex em muitos blocos — label+valor ficavam colados (ex.: NIF512...) */
.cliente-field{display:block;margin:0 0 8px 0;padding:0;line-height:1.45}
.cliente-field .c-label{font-size:8pt;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);font-weight:600;display:inline}
.cliente-field .c-value{font-size:9pt;font-weight:700;color:var(--texto);display:inline}
.kpis{display:grid;grid-template-columns:repeat(auto-fill,minmax(100px,1fr));gap:6px;margin-bottom:10px}
.kpi-card{background:var(--cinza);border:1px solid var(--borda);border-radius:5px;padding:7px 8px;text-align:center}
.kpi-card.kpi-verde{background:#dcfce7;border-color:#15803d}
.kpi-card.kpi-vermelho{background:#fee2e2;border-color:#b91c1c}
.kpi-card.kpi-laranja{background:#fef3c7;border-color:#a16207}
.kpi-card.kpi-azul{background:var(--azul-claro);border-color:var(--azul)}
.kpi-numero{font-size:18pt;font-weight:800;line-height:1.1}
.kpi-verde .kpi-numero{color:#14532d}
.kpi-vermelho .kpi-numero{color:#7f1d1d}
.kpi-laranja .kpi-numero{color:#78350f}
.kpi-azul .kpi-numero{color:var(--azul)}
.kpi-label{font-size:8pt;color:var(--texto);text-transform:uppercase;letter-spacing:.04em;margin-top:2px;font-weight:600}
.tabela-frota{width:100%;border-collapse:collapse;font-size:8pt;margin-bottom:6px}
.tabela-frota th{background:var(--azul);color:var(--branco);padding:4px 5px;text-align:left;font-size:7.5pt;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.tabela-frota td{padding:3px 5px;vertical-align:top;color:var(--texto)}
.tabela-frota .eq-row td{border-top:1px solid var(--borda-leve);padding-top:4px;padding-bottom:4px;border-bottom:1px solid var(--borda)}
.tabela-frota .eq-row.par td{background:var(--cinza)}
.tabela-frota .eq-cell-stack .eq-nome{display:block;margin-bottom:2px}
.tabela-frota .cell-eq{width:30%}
.tabela-frota .cell-center{text-align:center}
.tabela-frota .cell-muted{color:var(--muted)}
.tabela-frota .cell-dias{font-weight:700}
.badge{display:inline-block;padding:1.5px 6px;border-radius:10px;font-size:7.5pt;font-weight:700;white-space:nowrap}
.badge-ok{background:#dcfce7;color:#14532d;border:1px solid #86efac}
.badge-atraso{background:#fee2e2;color:#7f1d1d;border:1px solid #fca5a5}
.badge-montagem{background:#fef3c7;color:#78350f;border:1px solid #fcd34d}
.data-atraso{color:#b91c1c;font-weight:700}
.data-ok{color:#15803d;font-weight:600}
.eq-nome{font-weight:700;font-size:8.5pt}
.eq-sub{font-size:7pt;color:var(--muted)}
.eq-serie{font-family:'Courier New',monospace;font-size:7pt;color:var(--muted);word-break:break-all;overflow-wrap:anywhere;max-width:100%}
.cat-header{background:var(--azul-claro);padding:5px 8px;font-size:9pt;font-weight:700;color:var(--azul);margin:8px 0 4px;border-radius:3px;border-left:3px solid var(--azul)}
.cat-header .atraso-count{color:#b91c1c}
.resumo-anual{display:grid;grid-template-columns:1fr 1fr;gap:8px;margin-bottom:10px}
.resumo-box{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:8px 10px}
.resumo-box h4{font-size:9pt;color:var(--azul);margin-bottom:4px;text-transform:uppercase;font-weight:700}
.resumo-stat{display:flex;justify-content:space-between;font-size:9pt;padding:3px 0;border-bottom:1px dotted var(--borda-leve);color:var(--texto)}
.resumo-stat:last-child{border-bottom:none}
.resumo-stat .stat-accent{color:var(--azul);font-weight:700}
.resumo-stat .stat-atraso{color:#b91c1c;font-weight:700}
.sub-muted{font-size:8pt;color:var(--muted)}
.cell-desc{font-size:8pt}
.cell-rel{font-size:8pt}
</style>`,lt=`${Nt(ut)}
${It("Relatório Executivo de Frota","Período",et)}
`;let n=tt?`<div class="atm-frota-email-root" style="margin:0;padding:0;background:#fff;color:#111827" lang="pt">${st}
${lt}`:`<!DOCTYPE html><html lang="pt"><head><meta charset="utf-8">
<title>Relatório Executivo de Frota — ${o(i.nome)}</title>
${st}
</head><body>
${lt}`;n+=`
<div class="cliente-grid">
  <div class="cliente-field"><span class="c-label">Cliente:</span> <span class="c-value">${o(i.nome)}</span></div>
  <div class="cliente-field"><span class="c-label">NIF:</span> <span class="c-value">${o(i.nif??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Localidade:</span> <span class="c-value">${o(i.localidade??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Morada:</span> <span class="c-value">${o(i.morada??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Telefone:</span> <span class="c-value">${o(i.telefone??"—")}</span></div>
  <div class="cliente-field"><span class="c-label">Email:</span> <span class="c-value">${o(i.email??"—")}</span></div>
</div>
<div class="kpis">
  <div class="kpi-card"><div class="kpi-numero">${U}</div><div class="kpi-label">Equipamentos</div></div>
  <div class="kpi-card ${W>=80?"kpi-verde":W>=50?"kpi-laranja":"kpi-vermelho"}"><div class="kpi-numero">${W}%</div><div class="kpi-label">Conformidade</div></div>
  <div class="kpi-card ${I>0?"kpi-vermelho":"kpi-verde"}"><div class="kpi-numero">${I}</div><div class="kpi-label">Em atraso</div></div>
  <div class="kpi-card kpi-azul"><div class="kpi-numero">${ht}</div><div class="kpi-label">Manutenções período</div></div>
  <div class="kpi-card ${bt>0?"kpi-laranja":""}"><div class="kpi-numero">${vt}</div><div class="kpi-label">Reparações período</div></div>
</div>`;for(const[,t]of F){const e=t.linhas.filter(a=>a.estado==="atraso").length;n+=`<div class="cat-header">${o(t.nome)} (${t.linhas.length} equip.${e>0?` · <span class="atraso-count">${e} em atraso</span>`:""})</div>
<table class="tabela-frota"><thead><tr>
  <th class="cell-eq" style="width:26%">Equipamento / N.º Série</th>
  <th class="cell-center" style="width:9%">Última</th>
  <th class="cell-center" style="width:9%">Próxima</th>
  <th class="cell-center" style="width:6%">Dias</th>
  <th class="cell-center" style="width:5%">Man.</th>
  <th class="cell-center" style="width:5%">Rep.</th>
  <th class="cell-center" style="width:11%">Estado</th>
  <th class="cell-center" style="width:11%">Tendência</th>
  <th class="cell-center" style="width:18%">Últ. rel.</th>
</tr></thead><tbody>`,t.linhas.sort((a,r)=>(r.diasAtraso??-9999)-(a.diasAtraso??-9999)).forEach(({m:a,sub:r,ultima:g,dataUltimaKey:k,proxima:w,diasAtraso:m,totalManuts:X,totalReps:Y,relUltima:R,estadoBadge:K,estadoLabel:u,tendencia:h,proxDataKey:y},V)=>{const G=m!=null?m>0?`<span class="data-atraso">+${m}</span>`:m===0?"Hoje":`<span class="data-ok">${m}</span>`:"—",P=V%2===0?"par":"",c=y||w?.data||a.proximaManut,v=[r?`<span class="eq-sub">${o(r.nome)}</span>`:"",a.numeroSerie?`<span class="eq-serie">S/N: ${o(a.numeroSerie)}</span>`:""].filter(Boolean).join(" ");n+=`<tr class="eq-row ${P}">
        <td class="cell-eq eq-cell-stack"><span class="eq-nome">${o(a.marca)} ${o(a.modelo)}</span>${v?`<br/>${v}`:""}</td>
        <td class="cell-center">${k?B(k):"—"}</td>
        <td class="cell-center">${c?`<span class="${y&&y<E?"data-atraso":"data-ok"}">${B(c)}</span>`:"—"}</td>
        <td class="cell-center cell-dias">${G}</td>
        <td class="cell-center cell-muted">${X||"—"}</td>
        <td class="cell-center cell-muted">${Y||"—"}</td>
        <td class="cell-center"><span class="badge ${K}">${o(u)}</span></td>
        <td class="cell-center" style="font-size:7.5pt;font-weight:700;color:${h.cor}">${h.texto}</td>
        <td class="cell-center cell-rel">${St(R)||"—"}</td>
      </tr>`}),n+="</tbody></table>"}if(I>0&&(n+=`<div class="secao-titulo vermelho">Manutenções em atraso (${I})</div>
<table class="tabela-frota"><thead><tr>
  <th class="cell-eq" style="width:30%">Equipamento</th><th class="cell-serie" style="width:16%">Nº Série</th>
  <th style="width:14%">Data prevista</th><th class="cell-center" style="width:10%">Dias atraso</th>
  <th style="width:30%">Observações</th>
</tr></thead><tbody>`,$.filter(t=>t.estado==="atraso").sort((t,e)=>(e.diasAtraso??0)-(t.diasAtraso??0)).forEach(({m:t,sub:e,proxima:a,diasAtraso:r})=>{const g=a?.data??t.proximaManut;n+=`<tr>
        <td><strong>${o(t.marca)} ${o(t.modelo)}</strong>${e?` <span class="sub-muted">· ${o(e.nome)}</span>`:""}</td>
        <td class="cell-serie">${o(t.numeroSerie)}</td>
        <td class="data-atraso">${B(g)}</td>
        <td class="data-atraso cell-center cell-dias">+${r??0}d</td>
        <td class="sub-muted">${o(a?.observacoes??"")}</td>
      </tr>`}),n+="</tbody></table>"),D.length>0){const t=q?`${o(et)} — ${D.length}`:`últimos 12 meses — ${D.length}`;n+=`<div class="secao-titulo laranja">Reparações concluídas (${t})</div>
<table class="tabela-frota"><thead><tr>
  <th class="cell-eq" style="width:28%">Equipamento</th><th class="cell-serie" style="width:14%">Nº Série</th>
  <th style="width:12%">Data</th><th style="width:46%">Descrição</th>
</tr></thead><tbody>`;const e=new Map(l.map(a=>[p(a.id),a]));D.forEach(a=>{const r=e.get(p(a.maquinaId));n+=`<tr>
        <td><strong>${r?o(`${r.marca} ${r.modelo}`):"—"}</strong></td>
        <td class="cell-serie">${r?o(r.numeroSerie):"—"}</td>
        <td>${B(a.data)}</td>
        <td class="cell-desc">${o(a.descricao?.slice(0,120)||a.descricaoAvaria?.slice(0,120)||"—")}</td>
      </tr>`}),n+="</tbody></table>"}return n+=`
<div style="margin-top:10px;padding:6px 10px;background:${s.cinza};border:1px solid ${s.bordaLeve};border-radius:4px;font-size:7.5pt;color:${s.muted};display:flex;gap:14px;flex-wrap:wrap;align-items:center;page-break-inside:avoid">
  <strong style="color:${s.azulNavel};text-transform:uppercase;letter-spacing:.04em;font-size:7pt">Legenda Tendência:</strong>
  <span style="color:${s.verde}">★ Excelente — ≥${nt} sem anomalias</span>
  <span style="color:${s.verde}">● Conforme — sem anomalias</span>
  <span style="color:${s.amarelo}">◐ Atenção — anomalias pontuais (≤${ct})</span>
  <span style="color:${s.vermelho}">⚠ Crítico — múltiplas anomalias ou atraso</span>
  <span style="color:${s.muted}">○ Novo — sem histórico</span>
</div>`,n+=`${Ft("Documento gerado em "+ft)}${tt?"</div>":"</body></html>"}`,n}export{Vt as gerarRelatorioFrotaHtml};
