const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/jspdf.es.min-ZA14oXQK.js","assets/index-Cqqd7WHe.js","assets/vendor-Bk0NZ5Or.js","assets/index-Rvtpichj.css"])))=>i.map(i=>d[i]);
import{a as D,f as k}from"./datasAzores-CBhl9I61.js";import{b as O,D as M,e as U}from"./emailConfig-DRobUt5f.js";import{A as L,l as j,_ as I}from"./index-Cqqd7WHe.js";const h={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",divisaoComercial:"Div. Comercial: Pico d'Agua Park, Rua 5, n.º13-15 · 9600-049 Pico da Pedra",sede:"Sede / Divisão Oficinas: Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",pais:"Açores — Portugal",web:"www.navel.pt"};function K(e,i,r,b,p=[],x={}){if(!e)return"";const{subcategoriaNome:g,ultimoEnvio:t,logoUrl:u}=x,o=u??"/manut/logo.png",s=U,P=e.dataCriacao?D(e.dataCriacao):"—",T=e.dataAssinatura?D(e.dataAssinatura):"—",y=i?.data?k(i.data,!0):"—",A=e.dataAssinatura?k(e.dataAssinatura,!0):e.dataCriacao?k(e.dataCriacao,!0):"—",a=r&&g?s(`${g} — ${r.marca} ${r.modelo} — Nº Série: ${r.numeroSerie}`):r?s(`${r.marca} ${r.modelo} — Nº Série: ${r.numeroSerie}`):"—",F=t?.data&&t?.destinatario?`Último envio por email: ${D(t.data)} para ${s(t.destinatario)}`:null,E=s(i?.tecnico||e?.tecnico||"—"),C=e.assinaturaDigital?O(e.assinaturaDigital):"",$=Math.ceil((p??[]).length/2),d=(p??[]).slice(0,$),z=(p??[]).slice($),f=(c,m,v=0)=>{const w=e.checklistRespostas?.[c.id],S=w==="sim"?'<span class="badge-sim">S</span>':w==="nao"?'<span class="badge-nao">N</span>':'<span class="badge-nd">—</span>';return`<tr><td>${m+v+1}.</td><td>${s(c.texto)}</td><td>${S}</td></tr>`};let l=`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Manutenção — Navel</title>
<style>
/* ── Página A4, margens mínimas ── */
@page{size:A4 portrait;margin:8mm 11mm}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10.5px;line-height:1.38;color:#1a1a2e;background:#fff;padding:0}

/* ── Paleta ── */
:root{
  --azul:#1a4880;--azul-med:#2d6eb5;--azul-claro:#e8f2fa;
  --cinza:#f4f6f8;--borda:#c6d8ec;--texto:#1a1a2e;--muted:#5a6a7e;
  --verde:#16a34a;--vermelho:#dc2626;--acento:#f0a500;
}

/* ── Cabeçalho ── */
.rpt-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:8px;border-bottom:2.5px solid var(--azul)}
.rpt-logo img{max-height:42px;max-width:150px;object-fit:contain;display:block}
.rpt-logo-fallback{font-size:1.2em;font-weight:700;color:var(--azul)}
.rpt-empresa{text-align:right;font-size:9px;line-height:1.5;color:var(--muted)}
.rpt-empresa strong{display:block;font-size:10px;color:var(--azul);margin-bottom:1px}
.rpt-empresa a{color:var(--azul-med);text-decoration:none}

/* ── Título ── */
.rpt-titulo-bar{display:flex;align-items:center;justify-content:space-between;background:var(--azul);color:#fff;padding:5px 10px;margin:7px 0 0;border-radius:3px}
.rpt-titulo-bar h1{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
.rpt-num-wrap{text-align:right}
.rpt-num-label{font-size:8px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;display:block}
.rpt-num{font-size:14px;font-weight:800;letter-spacing:.04em;font-family:'Courier New',monospace}
.rpt-acento{height:2px;background:linear-gradient(90deg,var(--acento),var(--azul-med));margin-bottom:10px;border-radius:0 0 2px 2px}

/* ── Secções ── */
section{margin-bottom:9px}
.rpt-section-title{font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--azul-med);border-bottom:1px solid var(--borda);padding-bottom:2px;margin-bottom:5px}

/* ── Grid de dados (2 colunas) ── */
.rpt-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px 10px}
.rpt-field{padding:2px 0;border-bottom:1px solid #edf2f7}
.rpt-field:last-child{border-bottom:none}
.rpt-label{font-size:8.5px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);display:block;margin-bottom:0}
.rpt-value{font-size:10.5px;color:var(--texto)}
.rpt-field--full{grid-column:1/-1}

/* ── Checklist 2 colunas ── */
.checklist-2col{display:grid;grid-template-columns:1fr 1fr;gap:0 10px}
.checklist-table{width:100%;border-collapse:collapse;font-size:9.5px}
.checklist-table tr:nth-child(even){background:var(--cinza)}
.checklist-table td{padding:2.5px 4px 2.5px 0;border-bottom:1px solid #edf2f7;vertical-align:top}
.checklist-table td:first-child{width:1.6em;color:var(--muted);font-size:8.5px;padding-left:2px;white-space:nowrap}
.checklist-table td:last-child{width:22px;text-align:center;padding-right:2px}
.badge-sim{background:rgba(22,163,74,.15);color:var(--verde);padding:1px 4px;border-radius:8px;font-size:9px;font-weight:700}
.badge-nao{background:rgba(220,38,38,.12);color:var(--vermelho);padding:1px 4px;border-radius:8px;font-size:9px;font-weight:700}
.badge-nd{color:var(--muted);font-size:9px}

/* ── Notas ── */
.rpt-notas{background:var(--azul-claro);border-left:2.5px solid var(--azul-med);padding:5px 9px;border-radius:0 3px 3px 0;font-size:10px;color:var(--texto)}

/* ── Fotos ── */
.rpt-fotos-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:6px}
.rpt-fotos-grid img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:3px;border:1px solid var(--borda);display:block}

/* ── Assinatura + declaração lado a lado ── */
.rpt-bottom{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:start}
.rpt-assinatura-box{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px}
.rpt-assinatura-img img{max-width:180px;max-height:70px;border:1px solid var(--borda);border-radius:3px;margin-top:4px;background:#fff;display:block}
.rpt-declaracao{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px;font-size:8.5px;color:var(--muted);line-height:1.55}

/* ── Rodapé ── */
.rpt-footer{margin-top:8px;padding-top:6px;border-top:1px solid var(--borda);display:flex;justify-content:space-between;font-size:8.5px;color:var(--muted)}

/* ── Peças e consumíveis ── */
.pecas-table{width:100%;border-collapse:collapse;font-size:9.5px}
.pecas-table th{background:var(--azul);color:#fff;padding:3px 5px;text-align:left;font-size:8.5px;text-transform:uppercase;letter-spacing:.04em}
.pecas-table td{padding:2.5px 5px;border-bottom:1px solid #edf2f7;vertical-align:middle}
.pecas-table tr.row-usado td{background:#f0fdf4}
.pecas-table tr.row-nao-usado td{background:#fafafa;color:#9ca3af}
.pecas-table tr.row-nao-usado .cell-desc{text-decoration:line-through}
.pecas-table .cell-status{width:22px;text-align:center;font-size:10px}
.pecas-table .cell-pos{width:50px;color:var(--muted);font-family:monospace;font-size:8.5px}
.pecas-table .cell-code{width:120px;font-family:monospace;font-size:8.5px}
.pecas-table .cell-desc{}
.pecas-table .cell-qty{width:38px;text-align:right}
.pecas-table .cell-un{width:35px}
.pecas-secao-label{font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.05em;color:var(--muted);margin:6px 0 3px}
</style>
</head>
<body>

<header class="rpt-header">
  <div class="rpt-logo">
    <img src="${o}" alt="Navel"
      onerror="this.parentNode.innerHTML='<span class=rpt-logo-fallback>Navel</span>'">
  </div>
  <div class="rpt-empresa">
    <strong>${s(h.nome)}</strong>
    ${s(h.divisaoComercial)}<br>
    ${s(h.sede)}<br>
    ${s(h.telefones)} &nbsp;|&nbsp; <a href="https://${h.web}">${h.web}</a><br>
    ${s(h.pais)}
  </div>
</header>

<div class="rpt-titulo-bar">
  <h1>Relatório de Manutenção</h1>
  <div class="rpt-num-wrap">
    <span class="rpt-num-label">Nº de Serviço</span>
    <span class="rpt-num">${s(e?.numeroRelatorio??i?.id??"—")}</span>
  </div>
</div>
<div class="rpt-acento"></div>

<!-- Dados -->
<section>
  <div class="rpt-section-title">Dados da manutenção</div>
  <div class="rpt-grid">
    <div class="rpt-field">
      <span class="rpt-label">Data agendada</span>
      <span class="rpt-value">${y}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Data de realização</span>
      <span class="rpt-value">${A}</span>
    </div>
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Equipamento</span>
      <span class="rpt-value">${a}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Cliente</span>
      <span class="rpt-value">${s(b?.nome??"—")}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Técnico responsável</span>
      <span class="rpt-value">${E}</span>
    </div>
    ${i?.horasTotais!=null||i?.horasServico!=null?`
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Contadores de horas</span>
      <span class="rpt-value">${i.horasTotais!=null?`Total: ${i.horasTotais} h`:""}${i.horasTotais!=null&&i.horasServico!=null?" · ":""}${i.horasServico!=null?`Serviço: ${i.horasServico} h`:""}</span>
    </div>`:""}
  </div>
</section>`;if(p?.length>0&&(l+=`
<section>
  <div class="rpt-section-title">Checklist de verificação</div>
  <div class="checklist-2col">
    <table class="checklist-table"><tbody>
      ${d.map((c,m)=>f(c,m,0)).join("")}
    </tbody></table>
    <table class="checklist-table"><tbody>
      ${z.map((c,m)=>f(c,m,$)).join("")}
    </tbody></table>
  </div>
</section>`),(e.notas||e.fotos?.length>0)&&(l+='<section><div class="rpt-section-title">Notas e fotografias</div>',e.notas&&(l+=`<div class="rpt-notas">${s(e.notas).replace(/\n/g,"<br>")}</div>`),e.fotos?.length>0&&(l+='<div class="rpt-fotos-grid">',e.fotos.forEach((c,m)=>{const v=O(c);v&&(l+=`<img src="${v}" alt="Fotografia ${m+1}">`)}),l+="</div>"),l+="</section>"),e.pecasUsadas?.length>0){const c=e.tipoManutKaeser?` — Manutenção Tipo ${e.tipoManutKaeser}`:"",m=n=>"usado"in n?n:{...n,usado:(n.quantidadeUsada??n.quantidade??0)>0},v=e.pecasUsadas.map(m),w=v.filter(n=>n.usado),S=v.filter(n=>!n.usado),R=(n,N)=>`
      <tr class="${N}">
        <td class="cell-status">${N==="row-usado"?"✓":"✗"}</td>
        <td class="cell-pos">${s(n.posicao??"")}</td>
        <td class="cell-code">${s(n.codigoArtigo??"")}</td>
        <td class="cell-desc">${s(n.descricao??"")}</td>
        <td class="cell-qty">${n.quantidade??""}</td>
        <td class="cell-un">${s(n.unidade??"")}</td>
      </tr>`;l+=`
<section>
  <div class="rpt-section-title">Consumíveis e peças${c}</div>
  <table class="pecas-table">
    <thead>
      <tr><th></th><th>Pos.</th><th>Código artigo</th><th>Descrição</th><th>Qtd.</th><th>Un.</th></tr>
    </thead>
    <tbody>
      ${w.length>0?`<tr><td colspan="6" class="pecas-secao-label">Utilizados (${w.length})</td></tr>`:""}
      ${w.map(n=>R(n,"row-usado")).join("")}
      ${S.length>0?`<tr><td colspan="6" class="pecas-secao-label">Não utilizados (${S.length})</td></tr>`:""}
      ${S.map(n=>R(n,"row-nao-usado")).join("")}
    </tbody>
  </table>
</section>`}return l+=`
<!-- Assinatura + Declaração lado a lado -->
<section>
  <div class="rpt-section-title">Registo e assinatura</div>
  <div class="rpt-bottom">
    <div class="rpt-assinatura-box">
      <div class="rpt-grid">
        <div class="rpt-field">
          <span class="rpt-label">Data de criação</span>
          <span class="rpt-value">${P}</span>
        </div>
        <div class="rpt-field">
          <span class="rpt-label">Data de assinatura</span>
          <span class="rpt-value">${T}</span>
        </div>
        <div class="rpt-field rpt-field--full">
          <span class="rpt-label">Assinado pelo cliente</span>
          <span class="rpt-value">${s(e.nomeAssinante??"—")}</span>
        </div>
      </div>
      ${C?`
      <div class="rpt-assinatura-img">
        <span class="rpt-label" style="margin-top:5px;display:block">Assinatura manuscrita</span>
        <img src="${C}" alt="Assinatura do cliente">
      </div>`:""}
    </div>
    <div class="rpt-declaracao">${s(M)}</div>
  </div>
</section>

${F?`<p style="font-size:8.5px;color:#888;margin-bottom:5px">${F}</p>`:""}
<footer class="rpt-footer">
  <span>${s(L)}</span>
  <span>${s(h.web)} &nbsp;|&nbsp; ${s(h.telefones)}</span>
</footer>

</body></html>`,l}function _(){return window.innerWidth<=768||/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)}async function B({relatorio:e,manutencao:i,maquina:r,cliente:b,checklistItems:p=[],subcategoriaNome:x="",html:g}){if(_())try{const t=await W({relatorio:e,manutencao:i,maquina:r,cliente:b,checklistItems:p,subcategoriaNome:x}),u=URL.createObjectURL(t);window.open(u,"_blank")||alert("Permita pop-ups para visualizar o PDF."),setTimeout(()=>URL.revokeObjectURL(u),6e4)}catch(t){j.error("gerarPdfRelatorio","abrirPdfRelatorio","Erro ao gerar PDF em mobile",{msg:t?.message}),alert("Não foi possível gerar o PDF.")}else V(g)}function V(e){const i=window.open("","_blank");if(!i){alert("Permita pop-ups para obter o PDF.");return}i.document.write(e),i.document.close();const r=()=>{i.focus(),i.print(),i.onafterprint=()=>i.close()};i.addEventListener("load",()=>{const b=Array.from(i.document.images);if(b.length===0){r();return}let p=b.filter(g=>!g.complete).length;if(p===0){r();return}const x=()=>{p--,p<=0&&r()};b.forEach(g=>{g.complete||(g.addEventListener("load",x),g.addEventListener("error",x))}),setTimeout(r,3e3)})}async function W({relatorio:e,manutencao:i,maquina:r,cliente:b,checklistItems:p=[],subcategoriaNome:x=""}){const{jsPDF:g}=await I(async()=>{const{jsPDF:d}=await import("./jspdf.es.min-ZA14oXQK.js").then(z=>z.j);return{jsPDF:d}},__vite__mapDeps([0,1,2,3])),t=new g({orientation:"portrait",unit:"mm",format:"a4"}),u=210,o=14,s=u-2*o,P=i?.tipo==="montagem"?"Montagem":"Manutenção Periódica",T=e?.numeroRelatorio??"S/N",y=r?`${x?x+" — ":""}${r.marca} ${r.modelo} (Nº ${r.numeroSerie})`:"—",A=e?.dataAssinatura?new Date(e.dataAssinatura).toLocaleString("pt-PT",{dateStyle:"long",timeStyle:"short",timeZone:"Atlantic/Azores"}):"—";t.setFillColor(30,58,95),t.rect(0,0,u,26,"F"),t.setTextColor(255,255,255),t.setFontSize(13),t.setFont("helvetica","bold"),t.text("NAVEL-AÇORES",o,11),t.setFontSize(8),t.setFont("helvetica","normal"),t.text("296 205 290 / 296 630 120  •  geral@navel.pt  •  www.navel.pt",o,18),t.text("JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",o,23);let a=36;t.setTextColor(30,58,95),t.setFontSize(11),t.setFont("helvetica","bold"),t.text("Relatório de "+P,o,a),a+=7,t.setTextColor(13,110,253),t.setFontSize(18),t.setFont("helvetica","bold"),t.text(T,o,a),a+=5,t.setDrawColor(13,110,253),t.setLineWidth(.5),t.line(o,a,u-o,a),a+=7;const F=[["CLIENTE",b?.nome??"—"],["EQUIPAMENTO",y],["DATA DE EXECUÇÃO",A],["TÉCNICO",e?.tecnico??i?.tecnico??"—"],["ASSINADO POR",e?.nomeAssinante??"—"]];if(t.setFontSize(9),F.forEach(([d,z],f)=>{f%2===1&&(t.setFillColor(248,249,250),t.rect(o,a-4,s,7.5,"F")),t.setFont("helvetica","bold"),t.setTextColor(107,114,128),t.text(d,o+1,a),t.setFont("helvetica","normal"),t.setTextColor(17,24,39);const l=t.splitTextToSize(String(z),s-55);t.text(l,o+55,a),a+=l.length>1?l.length*5+2:7.5}),a+=3,t.setDrawColor(220,220,220),t.setLineWidth(.3),t.line(o,a,u-o,a),a+=7,p.length>0){a>260&&(t.addPage(),a=20),t.setFontSize(10),t.setFont("helvetica","bold"),t.setTextColor(30,58,95),t.text("CHECKLIST DE VERIFICAÇÃO",o,a),a+=6;const d=Object.values(e?.checklistRespostas??{}).filter(f=>f==="sim").length,z=Object.values(e?.checklistRespostas??{}).filter(f=>f==="nao").length;t.setFontSize(8),t.setFont("helvetica","normal"),t.setTextColor(107,114,128),t.text(`${d} conforme • ${z} não conforme • ${p.length} itens`,o,a),a+=5,t.setFontSize(8.5),p.forEach((f,l)=>{a>270&&(t.addPage(),a=20),l%2===0&&(t.setFillColor(249,250,251),t.rect(o,a-3.5,s,7,"F"));const c=e?.checklistRespostas?.[f.id],m=c==="sim"?"SIM":c==="nao"?"NÃO":"—",v=c==="sim"?[22,163,74]:c==="nao"?[220,38,38]:[107,114,128];t.setFont("helvetica","normal"),t.setTextColor(107,114,128),t.text(String(l+1)+".",o+1,a),t.setTextColor(55,65,81),t.text(f.texto,o+8,a,{maxWidth:s-22}),t.setFont("helvetica","bold"),t.setTextColor(...v),t.text(m,u-o-2,a,{align:"right"}),a+=7}),a+=4}if(e?.notas){a>240&&(t.addPage(),a=20),t.setFontSize(10),t.setFont("helvetica","bold"),t.setTextColor(30,58,95),t.text("NOTAS ADICIONAIS",o,a),a+=6,t.setFontSize(9),t.setFont("helvetica","normal"),t.setTextColor(55,65,81);const d=t.splitTextToSize(e.notas,s);t.text(d,o,a),a+=d.length*5+5}a>255&&(t.addPage(),a=20),t.setFillColor(240,253,244),t.setDrawColor(187,247,208),t.rect(o,a-4,s,16,"FD"),t.setFontSize(9),t.setFont("helvetica","bold"),t.setTextColor(22,163,74),t.text("✓ Relatório assinado digitalmente",o+3,a+1),t.setFontSize(8),t.setFont("helvetica","normal"),t.setTextColor(55,65,81);const E=e?.nomeAssinante?`Assinado por ${e.nomeAssinante} em ${A}. Assinatura manuscrita arquivada no sistema.`:`Assinado em ${A}. Assinatura manuscrita arquivada no sistema.`;t.text(E,o+3,a+8,{maxWidth:s-6}),a+=20;const C=(e?.fotos??[]).length;C>0&&(a>270&&(t.addPage(),a=20),t.setFontSize(8.5),t.setFont("helvetica","italic"),t.setTextColor(107,114,128),t.text(`📷 ${C} fotografia(s) documentadas no sistema Navel Manutencoes.`,o,a));const $=t.internal.getNumberOfPages();for(let d=1;d<=$;d++)t.setPage(d),t.setFillColor(30,58,95),t.rect(0,283,u,14,"F"),t.setTextColor(160,180,210),t.setFontSize(6.5),t.setFont("helvetica","normal"),t.text(L,u/2,286,{align:"center"}),t.setFontSize(5.5),t.text("Pico da Pedra & Ponta Delgada  •  296 205 290 / 296 630 120  •  www.navel.pt",u/2,291,{align:"center"}),$>1&&(t.setTextColor(200,210,230),t.text(`Página ${d}/${$}`,u-o,293,{align:"right"}));return t.output("blob")}export{B as a,V as i,K as r};
