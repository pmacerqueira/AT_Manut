import{t as s,e as i}from"./datasAzores-BiL67wmJ.js";function o(e,r,a){const t=s(e,a?.in);return isNaN(r)?i(e,NaN):(r&&t.setDate(t.getDate()+r),t)}export{o as a};
