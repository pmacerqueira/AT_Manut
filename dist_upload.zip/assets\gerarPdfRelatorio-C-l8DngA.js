import{a as I,f as _}from"./datasAzores-CBhl9I61.js";import{D as J}from"./relatorio-FjR0pwB0.js";import{a as V,e as X}from"./emailConfig-_htEP6Dz.js";import{v as Y,I as Z,A as W,q as ee,r as H,x as ae,l as te}from"./index-AebIxv2_.js";import{_ as se}from"./vendor-pdf-hYLUQ4hX.js";const w={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",divisaoComercial:"Div. Comercial: Pico d'Agua Park, Rua 5, n.º13-15 · 9600-049 Pico da Pedra",sede:"Sede / Divisão Oficinas: Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",pais:"Açores — Portugal",web:"www.navel.pt"};function ue(t,i,o,h,d=[],k={}){if(!t)return"";const{subcategoriaNome:m,ultimoEnvio:e,logoUrl:u}=k,r=u??"/manut/logo.png",s=X,z=!!(t.tipoManutKaeser||Y(o?.marca)),A=t.tipoManutKaeser??"",S=A?Z[A]:null,v=o?.posicaoKaeser??null,a=v!=null?ae(v):null,T=v!=null?H(v):null,D=a!=null?H(a):null,R=t.dataCriacao?I(t.dataCriacao):"—",E=t.dataAssinatura?I(t.dataAssinatura):"—",c=i?.data?_(i.data,!0):"—",y=t.dataAssinatura?_(t.dataAssinatura,!0):t.dataCriacao?_(t.dataCriacao,!0):"—",x=o&&m?s(`${m} — ${o.marca} ${o.modelo} — Nº Série: ${o.numeroSerie}`):o?s(`${o.marca} ${o.modelo} — Nº Série: ${o.numeroSerie}`):"—",$=e?.data&&e?.destinatario?`Último envio por email: ${I(e.data)} para ${s(e.destinatario)}`:null,C=s(i?.tecnico||t?.tecnico||"—"),N=t.assinaturaDigital?V(t.assinaturaDigital):"",F=Math.ceil((d??[]).length/2),Q=(d??[]).slice(0,F),G=(d??[]).slice(F),U=(g,l,p=0)=>{const f=t.checklistRespostas?.[g.id],P=f==="sim"?'<span class="badge-sim">SIM</span>':f==="nao"?'<span class="badge-nao">NÃO</span>':'<span class="badge-nd">—</span>';return`<tr><td class="cl-num">${l+p+1}.</td><td class="cl-texto">${s(g.texto)}</td><td class="cl-badge">${P}</td></tr>`};let b=`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Manutenção — Navel</title>
<style>
/* ── Página A4, margens de impressão ── */
@page{size:A4 portrait;margin:8mm 11mm}
*{box-sizing:border-box;margin:0;padding:0}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:10.5px;line-height:1.42;color:#1a1a2e;background:#fff;padding:0}

/* ── Paleta ── */
:root{
  --azul:#1a4880;--azul-med:#2d6eb5;--azul-claro:#e8f2fa;
  --cinza:#f4f6f8;--borda:#c6d8ec;--texto:#1a1a2e;--muted:#5a6a7e;
  --verde:#16a34a;--vermelho:#dc2626;--acento:#f0a500;
  --kaeser:#b45309;--kaeser-bg:#fffbeb;--kaeser-borda:#fde68a;
}

/* ── Quebras de página ── */
section{margin-bottom:10px;page-break-inside:avoid}
.section-can-break{page-break-inside:auto}
.page-break-before{page-break-before:always}
.no-break{page-break-inside:avoid}

/* ── Cabeçalho ── */
.rpt-header{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:8px;border-bottom:2.5px solid var(--azul)}
.rpt-logo img{max-height:42px;max-width:150px;object-fit:contain;display:block}
.rpt-logo-fallback{font-size:1.2em;font-weight:700;color:var(--azul)}
.rpt-empresa{text-align:right;font-size:9px;line-height:1.5;color:var(--muted)}
.rpt-empresa strong{display:block;font-size:10px;color:var(--azul);margin-bottom:1px}
.rpt-empresa a{color:var(--azul-med);text-decoration:none}

/* ── Título ── */
.rpt-titulo-bar{display:flex;align-items:center;justify-content:space-between;background:var(--azul);color:#fff;padding:5px 10px;margin:7px 0 0;border-radius:3px}
.rpt-titulo-bar h1{font-size:11px;font-weight:700;letter-spacing:.06em;text-transform:uppercase}
.rpt-num-wrap{text-align:right}
.rpt-num-label{font-size:8px;opacity:.7;text-transform:uppercase;letter-spacing:.08em;display:block}
.rpt-num{font-size:14px;font-weight:800;letter-spacing:.04em;font-family:'Courier New',monospace}
.rpt-acento{height:2px;background:linear-gradient(90deg,var(--acento),var(--azul-med));margin-bottom:8px;border-radius:0 0 2px 2px}

/* ── Secções ── */
.rpt-section-title{font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.1em;color:var(--azul-med);border-bottom:1px solid var(--borda);padding-bottom:2px;margin-bottom:5px}

/* ── Grid de dados (2 colunas) ── */
.rpt-grid{display:grid;grid-template-columns:1fr 1fr;gap:1px 10px}
.rpt-field{padding:2.5px 0;border-bottom:1px solid #edf2f7}
.rpt-field:last-child{border-bottom:none}
.rpt-label{font-size:8.5px;font-weight:600;text-transform:uppercase;letter-spacing:.04em;color:var(--muted);display:block;margin-bottom:0}
.rpt-value{font-size:10.5px;color:var(--texto)}
.rpt-field--full{grid-column:1/-1}

/* ── Bloco KAESER ── */
.kaeser-band{background:var(--kaeser-bg);border:1.5px solid var(--kaeser-borda);border-radius:5px;margin-bottom:9px;overflow:hidden;page-break-inside:avoid}
.kaeser-band-header{background:var(--kaeser);color:#fff;padding:4px 10px;display:flex;align-items:center;justify-content:space-between;gap:8px}
.kaeser-band-titulo{font-size:11px;font-weight:800;letter-spacing:.06em;text-transform:uppercase}
.kaeser-band-subtitulo{font-size:9px;opacity:.85}
.kaeser-band-body{padding:7px 10px;display:grid;grid-template-columns:1fr 1fr 1fr;gap:6px 14px}
.kaeser-item{}
.kaeser-item-label{font-size:8px;text-transform:uppercase;letter-spacing:.05em;color:var(--kaeser);font-weight:700;display:block;margin-bottom:1px}
.kaeser-item-valor{font-size:11px;font-weight:600;color:var(--texto)}
.kaeser-item-valor.destaque{font-size:13px;font-weight:800;color:var(--kaeser)}
.kaeser-item-val-sub{font-size:8.5px;color:var(--muted);display:block}
.kaeser-seq{grid-column:1/-1;margin-top:4px;border-top:1px solid var(--kaeser-borda);padding-top:5px}
.kaeser-seq-label{font-size:8px;text-transform:uppercase;letter-spacing:.05em;color:var(--kaeser);font-weight:700;margin-bottom:3px}
.kaeser-seq-dots{display:flex;gap:3px;flex-wrap:wrap;align-items:center}
.kaeser-dot{width:22px;height:22px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:9px;font-weight:700;border:1.5px solid transparent;flex-shrink:0}
.kaeser-dot.passado{background:#e5e7eb;color:#6b7280;border-color:#d1d5db}
.kaeser-dot.atual{background:var(--kaeser);color:#fff;border-color:var(--kaeser)}
.kaeser-dot.proximo{background:#fff;color:var(--kaeser);border-color:var(--kaeser)}
.kaeser-dot.futuro{background:#f9fafb;color:#9ca3af;border-color:#e5e7eb}
.kaeser-dot-sep{color:#9ca3af;font-size:10px;padding:0 1px}

/* ── Checklist coluna única ── */
.checklist-1col{width:100%}
.checklist-2col{display:grid;grid-template-columns:1fr 1fr;gap:0 10px}
.checklist-table{width:100%;border-collapse:collapse;font-size:9.5px}
.checklist-table tr:nth-child(even){background:var(--cinza)}
.checklist-table td{padding:2.8px 4px;border-bottom:1px solid #edf2f7;vertical-align:top}
.checklist-table td.cl-num{width:1.6em;color:var(--muted);font-size:8.5px;padding-left:2px;white-space:nowrap}
.checklist-table td.cl-texto{padding-right:6px}
.checklist-table td.cl-badge{width:32px;text-align:center;padding-right:2px;white-space:nowrap}
.badge-sim{background:rgba(22,163,74,.15);color:var(--verde);padding:1px 5px;border-radius:8px;font-size:8.5px;font-weight:700}
.badge-nao{background:rgba(220,38,38,.12);color:var(--vermelho);padding:1px 5px;border-radius:8px;font-size:8.5px;font-weight:700}
.badge-nd{color:var(--muted);font-size:9px}

/* ── Notas ── */
.rpt-notas{background:var(--azul-claro);border-left:2.5px solid var(--azul-med);padding:5px 9px;border-radius:0 3px 3px 0;font-size:10px;color:var(--texto)}

/* ── Fotos ── */
.rpt-fotos-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-top:6px}
.rpt-fotos-grid img{width:100%;aspect-ratio:1;object-fit:cover;border-radius:3px;border:1px solid var(--borda);display:block}

/* ── Peças e consumíveis ── */
.pecas-table{width:100%;border-collapse:collapse;font-size:9.5px}
.pecas-table thead{display:table-header-group}
.pecas-table th{background:var(--azul);color:#fff;padding:4px 6px;text-align:left;font-size:8.5px;text-transform:uppercase;letter-spacing:.04em}
.pecas-table td{padding:3px 6px;border-bottom:1px solid #edf2f7;vertical-align:middle}
.pecas-table tr.row-usado td{background:#f0fdf4}
.pecas-table tr.row-nao-usado td{background:#fafafa;color:#9ca3af}
.pecas-table tr.row-nao-usado .cell-desc{text-decoration:line-through}
.pecas-table .cell-status{width:20px;text-align:center;font-size:11px;font-weight:700}
.pecas-table .cell-pos{width:46px;color:var(--muted);font-family:'Courier New',monospace;font-size:8.5px}
.pecas-table .cell-code{width:118px;font-family:'Courier New',monospace;font-size:9px}
.pecas-table .cell-qty{width:36px;text-align:right;font-weight:600}
.pecas-table .cell-un{width:34px;color:var(--muted);font-size:8.5px}
.pecas-group-row td{background:var(--cinza)!important;font-size:8.5px;font-weight:700;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);padding:3px 6px;page-break-after:avoid}
.pecas-group-usado td{border-left:3px solid var(--verde);color:var(--verde)}
.pecas-group-nao-usado td{border-left:3px solid #9ca3af}
.pecas-resumo{display:flex;gap:16px;padding:4px 6px;background:var(--cinza);border-top:1.5px solid var(--borda);font-size:9px}
.pecas-resumo-item{display:flex;align-items:center;gap:4px}
.pecas-resumo-dot{width:10px;height:10px;border-radius:50%;flex-shrink:0}
.pecas-resumo-dot.verde{background:var(--verde)}
.pecas-resumo-dot.cinza{background:#9ca3af}

/* ── Assinatura + declaração lado a lado ── */
.rpt-bottom{display:grid;grid-template-columns:1fr 1fr;gap:10px;align-items:start}
.rpt-assinatura-box{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px}
.rpt-assinatura-img img{max-width:180px;max-height:70px;border:1px solid var(--borda);border-radius:3px;margin-top:4px;background:#fff;display:block}
.rpt-declaracao{background:var(--cinza);border:1px solid var(--borda);border-radius:4px;padding:7px 10px;font-size:8.5px;color:var(--muted);line-height:1.55}

/* ── Rodapé ── */
.rpt-footer{margin-top:8px;padding-top:6px;border-top:1px solid var(--borda);display:flex;justify-content:space-between;font-size:8.5px;color:var(--muted)}
</style>
</head>
<body>

<header class="rpt-header">
  <div class="rpt-logo">
    <img src="${r}" alt="Navel"
      onerror="this.parentNode.innerHTML='<span class=rpt-logo-fallback>Navel</span>'">
  </div>
  <div class="rpt-empresa">
    <strong>${s(w.nome)}</strong>
    ${s(w.divisaoComercial)}<br>
    ${s(w.sede)}<br>
    ${s(w.telefones)} &nbsp;|&nbsp; <a href="https://${w.web}">${w.web}</a><br>
    ${s(w.pais)}
  </div>
</header>

<div class="rpt-titulo-bar">
  <h1>Relatório de Manutenção${z?" — Compressor":""}</h1>
  <div class="rpt-num-wrap">
    <span class="rpt-num-label">Nº de Serviço</span>
    <span class="rpt-num">${s(t?.numeroRelatorio??i?.id??"—")}</span>
  </div>
</div>
<div class="rpt-acento"></div>`;if(z){const g=S?.label??(A?`Tipo ${A}`:"Compressor"),l=S?.descricao??"",p=o?.horasTotaisAcumuladas??form?.horasTotais??null,f=o?.horasServicoAcumuladas??form?.horasServico??null,P=o?.anoFabrico??"—",O=s(o?.marca??"—"),n=s(o?.modelo??"—"),L=s(o?.numeroSerie??"—"),K=s(o?.numeroDocumentoVenda??""),q=ee.map((B,M)=>{let j="futuro";return v!=null&&(M<v?j="passado":M===v?j="atual":M===a&&(j="proximo")),`<span class="kaeser-dot ${j}" title="Ano ${M+1}">${B}</span>`}).join('<span class="kaeser-dot-sep">·</span>');b+=`
<div class="kaeser-band">
  <div class="kaeser-band-header">
    <span class="kaeser-band-titulo">Manutenção KAESER — ${s(g)}</span>
    ${l?`<span class="kaeser-band-subtitulo">${s(l)}</span>`:""}
  </div>
  <div class="kaeser-band-body">
    <div class="kaeser-item">
      <span class="kaeser-item-label">Fabricante / Modelo</span>
      <span class="kaeser-item-valor">${O} ${n}</span>
    </div>
    <div class="kaeser-item">
      <span class="kaeser-item-label">Número de série</span>
      <span class="kaeser-item-valor destaque">${L}</span>
    </div>
    <div class="kaeser-item">
      <span class="kaeser-item-label">Ano de fabrico</span>
      <span class="kaeser-item-valor">${P}</span>
      ${K?`<span class="kaeser-item-val-sub">Doc. venda: ${K}</span>`:""}
    </div>
    ${p!=null?`
    <div class="kaeser-item">
      <span class="kaeser-item-label">Horas totais acumuladas</span>
      <span class="kaeser-item-valor destaque">${p} h</span>
    </div>`:""}
    ${f!=null?`
    <div class="kaeser-item">
      <span class="kaeser-item-label">Horas de serviço</span>
      <span class="kaeser-item-valor">${f} h</span>
    </div>`:""}
    ${T?`
    <div class="kaeser-item">
      <span class="kaeser-item-label">Ciclo efectuado</span>
      <span class="kaeser-item-valor">${s(T)}</span>
      ${D?`<span class="kaeser-item-val-sub">Próxima: ${s(D)}</span>`:""}
    </div>`:""}
    <div class="kaeser-seq">
      <div class="kaeser-seq-label">Sequência do ciclo de manutenção (12 anos)</div>
      <div class="kaeser-seq-dots">
        ${q}
        ${v!=null?`<span style="font-size:8px;color:#9ca3af;margin-left:6px">
          ● Efectuado &nbsp; ○ Próximo &nbsp; · Futuro
        </span>`:""}
      </div>
    </div>
  </div>
</div>`}if(b+=`
<section>
  <div class="rpt-section-title">Dados da manutenção</div>
  <div class="rpt-grid">
    <div class="rpt-field">
      <span class="rpt-label">Data agendada</span>
      <span class="rpt-value">${c}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Data de realização</span>
      <span class="rpt-value">${y}</span>
    </div>
    ${z?"":`
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Equipamento</span>
      <span class="rpt-value">${x}</span>
    </div>`}
    <div class="rpt-field">
      <span class="rpt-label">Cliente</span>
      <span class="rpt-value">${s(h?.nome??"—")}</span>
    </div>
    <div class="rpt-field">
      <span class="rpt-label">Técnico responsável</span>
      <span class="rpt-value">${C}</span>
    </div>
    ${(i?.horasTotais!=null||i?.horasServico!=null)&&!z?`
    <div class="rpt-field rpt-field--full">
      <span class="rpt-label">Contadores de horas</span>
      <span class="rpt-value">${i.horasTotais!=null?`Total: ${i.horasTotais} h`:""}${i.horasTotais!=null&&i.horasServico!=null?" · ":""}${i.horasServico!=null?`Serviço: ${i.horasServico} h`:""}</span>
    </div>`:""}
  </div>
</section>`,d?.length>0&&(z?b+=`
<section class="section-can-break">
  <div class="rpt-section-title">Checklist de verificação — ${d.length} pontos</div>
  <div class="checklist-1col">
    <table class="checklist-table"><tbody>
      ${(d??[]).map((g,l)=>U(g,l,0)).join("")}
    </tbody></table>
  </div>
</section>`:b+=`
<section>
  <div class="rpt-section-title">Checklist de verificação</div>
  <div class="checklist-2col">
    <table class="checklist-table"><tbody>
      ${Q.map((g,l)=>U(g,l,0)).join("")}
    </tbody></table>
    <table class="checklist-table"><tbody>
      ${G.map((g,l)=>U(g,l,F)).join("")}
    </tbody></table>
  </div>
</section>`),(t.notas||t.fotos?.length>0)&&(b+='<section><div class="rpt-section-title">Notas e fotografias</div>',t.notas&&(b+=`<div class="rpt-notas">${s(t.notas).replace(/\n/g,"<br>")}</div>`),t.fotos?.length>0&&(b+='<div class="rpt-fotos-grid">',t.fotos.forEach((g,l)=>{const p=V(g);p&&(b+=`<img src="${p}" alt="Fotografia ${l+1}">`)}),b+="</div>"),b+="</section>"),t.pecasUsadas?.length>0){const g=n=>"usado"in n?n:{...n,usado:(n.quantidadeUsada??n.quantidade??0)>0},l=t.pecasUsadas.map(g),p=l.filter(n=>n.usado),f=l.filter(n=>!n.usado),P=A?`Consumíveis e peças — Manutenção Tipo ${A}${S?` · ${S.label}`:""}`:"Consumíveis e peças",O=(n,L)=>`
      <tr class="${L} no-break">
        <td class="cell-status">${L==="row-usado"?"✓":"✗"}</td>
        <td class="cell-pos">${s(n.posicao??"")}</td>
        <td class="cell-code">${s(n.codigoArtigo??"")}</td>
        <td>${s(n.descricao??"")}</td>
        <td class="cell-qty">${n.quantidade??""}</td>
        <td class="cell-un">${s(n.unidade??"")}</td>
      </tr>`;b+=`
<section class="section-can-break${z?" page-break-before":""}">
  <div class="rpt-section-title">${P}</div>
  <table class="pecas-table">
    <thead>
      <tr>
        <th style="width:20px"></th>
        <th style="width:46px">Pos.</th>
        <th style="width:118px">Código artigo</th>
        <th>Descrição</th>
        <th style="width:36px;text-align:right">Qtd.</th>
        <th style="width:34px">Un.</th>
      </tr>
    </thead>
    <tbody>
      ${p.length>0?`<tr class="pecas-group-row pecas-group-usado"><td colspan="6">✓ Utilizados — ${p.length} artigo${p.length!==1?"s":""}</td></tr>`:""}
      ${p.map(n=>O(n,"row-usado")).join("")}
      ${f.length>0?`<tr class="pecas-group-row pecas-group-nao-usado"><td colspan="6">✗ Não utilizados — ${f.length} artigo${f.length!==1?"s":""}</td></tr>`:""}
      ${f.map(n=>O(n,"row-nao-usado")).join("")}
    </tbody>
  </table>
  <div class="pecas-resumo">
    <span class="pecas-resumo-item"><span class="pecas-resumo-dot verde"></span>${p.length} artigo${p.length!==1?"s":""} utilizado${p.length!==1?"s":""}</span>
    ${f.length>0?`<span class="pecas-resumo-item"><span class="pecas-resumo-dot cinza"></span>${f.length} artigo${f.length!==1?"s":""} não substituído${f.length!==1?"s":""}</span>`:""}
    <span style="margin-left:auto;color:var(--muted)">${l.length} artigo${l.length!==1?"s":""} no plano</span>
  </div>
</section>`}return b+=`
<section class="no-break">
  <div class="rpt-section-title">Registo e assinatura</div>
  <div class="rpt-bottom">
    <div class="rpt-assinatura-box">
      <div class="rpt-grid">
        <div class="rpt-field">
          <span class="rpt-label">Data de criação</span>
          <span class="rpt-value">${R}</span>
        </div>
        <div class="rpt-field">
          <span class="rpt-label">Data de assinatura</span>
          <span class="rpt-value">${E}</span>
        </div>
        <div class="rpt-field rpt-field--full">
          <span class="rpt-label">Assinado pelo cliente</span>
          <span class="rpt-value">${s(t.nomeAssinante??"—")}</span>
        </div>
      </div>
      ${N?`
      <div class="rpt-assinatura-img">
        <span class="rpt-label" style="margin-top:5px;display:block">Assinatura manuscrita</span>
        <img src="${N}" alt="Assinatura do cliente">
      </div>`:""}
    </div>
    <div class="rpt-declaracao">${s(J)}</div>
  </div>
</section>

${$?`<p style="font-size:8.5px;color:#888;margin-bottom:5px">${$}</p>`:""}
<footer class="rpt-footer">
  <span>${s(W)}</span>
  <span>${s(w.web)} &nbsp;|&nbsp; ${s(w.telefones)}</span>
</footer>

</body></html>`,b}function oe(){return window.innerWidth<=768||/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)}async function ge({relatorio:t,manutencao:i,maquina:o,cliente:h,checklistItems:d=[],subcategoriaNome:k="",html:m}){if(oe())try{const e=await ie({relatorio:t,manutencao:i,maquina:o,cliente:h,checklistItems:d,subcategoriaNome:k}),u=URL.createObjectURL(e);window.open(u,"_blank")||alert("Permita pop-ups para visualizar o PDF."),setTimeout(()=>URL.revokeObjectURL(u),6e4)}catch(e){te.error("gerarPdfRelatorio","abrirPdfRelatorio","Erro ao gerar PDF em mobile",{msg:e?.message}),alert("Não foi possível gerar o PDF.")}else re(m)}function re(t){const i=window.open("","_blank");if(!i){alert("Permita pop-ups para obter o PDF.");return}i.document.write(t),i.document.close();const o=()=>{i.focus(),i.print(),i.onafterprint=()=>i.close()};i.addEventListener("load",()=>{const h=Array.from(i.document.images);if(h.length===0){o();return}let d=h.filter(m=>!m.complete).length;if(d===0){o();return}const k=()=>{d--,d<=0&&o()};h.forEach(m=>{m.complete||(m.addEventListener("load",k),m.addEventListener("error",k))}),setTimeout(o,3e3)})}async function ie({relatorio:t,manutencao:i,maquina:o,cliente:h,checklistItems:d=[],subcategoriaNome:k=""}){const{jsPDF:m}=await se(async()=>{const{jsPDF:c}=await import("./vendor-pdf-hYLUQ4hX.js").then(y=>y.j);return{jsPDF:c}},[]),e=new m({orientation:"portrait",unit:"mm",format:"a4"}),u=210,r=14,s=u-2*r,z=i?.tipo==="montagem"?"Montagem":"Manutenção Periódica",A=t?.numeroRelatorio??"S/N",S=o?`${k?k+" — ":""}${o.marca} ${o.modelo} (Nº ${o.numeroSerie})`:"—",v=t?.dataAssinatura?new Date(t.dataAssinatura).toLocaleString("pt-PT",{dateStyle:"long",timeStyle:"short",timeZone:"Atlantic/Azores"}):"—";e.setFillColor(30,58,95),e.rect(0,0,u,26,"F"),e.setTextColor(255,255,255),e.setFontSize(13),e.setFont("helvetica","bold"),e.text("NAVEL-AÇORES",r,11),e.setFontSize(8),e.setFont("helvetica","normal"),e.text("296 205 290 / 296 630 120  •  geral@navel.pt  •  www.navel.pt",r,18),e.text("JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",r,23);let a=36;e.setTextColor(30,58,95),e.setFontSize(11),e.setFont("helvetica","bold"),e.text("Relatório de "+z,r,a),a+=7,e.setTextColor(13,110,253),e.setFontSize(18),e.setFont("helvetica","bold"),e.text(A,r,a),a+=5,e.setDrawColor(13,110,253),e.setLineWidth(.5),e.line(r,a,u-r,a),a+=7;const T=[["CLIENTE",h?.nome??"—"],["EQUIPAMENTO",S],["DATA DE EXECUÇÃO",v],["TÉCNICO",t?.tecnico??i?.tecnico??"—"],["ASSINADO POR",t?.nomeAssinante??"—"]];if(e.setFontSize(9),T.forEach(([c,y],x)=>{x%2===1&&(e.setFillColor(248,249,250),e.rect(r,a-4,s,7.5,"F")),e.setFont("helvetica","bold"),e.setTextColor(107,114,128),e.text(c,r+1,a),e.setFont("helvetica","normal"),e.setTextColor(17,24,39);const $=e.splitTextToSize(String(y),s-55);e.text($,r+55,a),a+=$.length>1?$.length*5+2:7.5}),a+=3,e.setDrawColor(220,220,220),e.setLineWidth(.3),e.line(r,a,u-r,a),a+=7,d.length>0){a>260&&(e.addPage(),a=20),e.setFontSize(10),e.setFont("helvetica","bold"),e.setTextColor(30,58,95),e.text("CHECKLIST DE VERIFICAÇÃO",r,a),a+=6;const c=Object.values(t?.checklistRespostas??{}).filter(x=>x==="sim").length,y=Object.values(t?.checklistRespostas??{}).filter(x=>x==="nao").length;e.setFontSize(8),e.setFont("helvetica","normal"),e.setTextColor(107,114,128),e.text(`${c} conforme • ${y} não conforme • ${d.length} itens`,r,a),a+=5,e.setFontSize(8.5),d.forEach((x,$)=>{a>270&&(e.addPage(),a=20),$%2===0&&(e.setFillColor(249,250,251),e.rect(r,a-3.5,s,7,"F"));const C=t?.checklistRespostas?.[x.id],N=C==="sim"?"SIM":C==="nao"?"NÃO":"—",F=C==="sim"?[22,163,74]:C==="nao"?[220,38,38]:[107,114,128];e.setFont("helvetica","normal"),e.setTextColor(107,114,128),e.text(String($+1)+".",r+1,a),e.setTextColor(55,65,81),e.text(x.texto,r+8,a,{maxWidth:s-22}),e.setFont("helvetica","bold"),e.setTextColor(...F),e.text(N,u-r-2,a,{align:"right"}),a+=7}),a+=4}if(t?.notas){a>240&&(e.addPage(),a=20),e.setFontSize(10),e.setFont("helvetica","bold"),e.setTextColor(30,58,95),e.text("NOTAS ADICIONAIS",r,a),a+=6,e.setFontSize(9),e.setFont("helvetica","normal"),e.setTextColor(55,65,81);const c=e.splitTextToSize(t.notas,s);e.text(c,r,a),a+=c.length*5+5}a>255&&(e.addPage(),a=20),e.setFillColor(240,253,244),e.setDrawColor(187,247,208),e.rect(r,a-4,s,16,"FD"),e.setFontSize(9),e.setFont("helvetica","bold"),e.setTextColor(22,163,74),e.text("✓ Relatório assinado digitalmente",r+3,a+1),e.setFontSize(8),e.setFont("helvetica","normal"),e.setTextColor(55,65,81);const D=t?.nomeAssinante?`Assinado por ${t.nomeAssinante} em ${v}. Assinatura manuscrita arquivada no sistema.`:`Assinado em ${v}. Assinatura manuscrita arquivada no sistema.`;e.text(D,r+3,a+8,{maxWidth:s-6}),a+=20;const R=(t?.fotos??[]).length;R>0&&(a>270&&(e.addPage(),a=20),e.setFontSize(8.5),e.setFont("helvetica","italic"),e.setTextColor(107,114,128),e.text(`📷 ${R} fotografia(s) documentadas no sistema Navel Manutencoes.`,r,a));const E=e.internal.getNumberOfPages();for(let c=1;c<=E;c++)e.setPage(c),e.setFillColor(30,58,95),e.rect(0,283,u,14,"F"),e.setTextColor(160,180,210),e.setFontSize(6.5),e.setFont("helvetica","normal"),e.text(W,u/2,286,{align:"center"}),e.setFontSize(5.5),e.text("Pico da Pedra & Ponta Delgada  •  296 205 290 / 296 630 120  •  www.navel.pt",u/2,291,{align:"center"}),E>1&&(e.setTextColor(200,210,230),e.text(`Página ${c}/${E}`,u-r,293,{align:"right"}));return e.output("blob")}export{ge as a,re as i,ue as r};
