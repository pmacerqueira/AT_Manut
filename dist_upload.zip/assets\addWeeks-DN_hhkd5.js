import{a as e}from"./addDays-EA-Jdp2P.js";function s(a,r,d){return e(a,r*7,d)}export{s as a};
