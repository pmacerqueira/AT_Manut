import{c as Ze,b as Re,a as be,u as ve,j as e,A as Le,i as ea,k as aa,S as ta,T as Ie,f as oe,m as De,n as sa}from"./index-COpRYxt7.js";import{r as d,d as oa}from"./vendor-Bk0NZ5Or.js";import{F as ia,M as na,P as la,D as ra}from"./DocumentacaoModal-CdTpD3Nd.js";import{R as da}from"./RelatorioView-d11mlLQv.js";import{r as ca}from"./relatorioHtml-JvwN4_mk.js";import{E as _e,e as Q,s as Ge,M as ma}from"./emailConfig-_9rCpn-h.js";import{f as Be}from"./format-BvtC0E8y.js";import{p as Ue}from"./pt-BAJJYN30.js";import{f as W}from"./datasAzores-CBhl9I61.js";import{i as ua}from"./gerarPdfRelatorio-DphU9DNJ.js";import{A as ie}from"./arrow-left-DsBliMjN.js";import{U as ne}from"./upload-t9VcWXng.js";import{P as fe}from"./plus-zlblJ_jk.js";import{P as ge}from"./pencil-CHLoEnSu.js";import{T as pa}from"./trash-2-YGt01Bfk.js";import{E as ha}from"./relatorio-DcrrmePs.js";import"./vendor-pdf-hYLUQ4hX.js";import"./chevron-down-DyAF0kaE.js";const xa=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M8 18v-2",key:"qcmpov"}],["path",{d:"M12 18v-4",key:"q1q25u"}],["path",{d:"M16 18v-6",key:"15y0np"}]],Fe=Ze("file-chart-column-increasing",xa),Te="comercial@navel.pt";function fa({isOpen:x,onClose:N,manutencao:C,relatorio:k,maquina:S,cliente:B}){const{getChecklistBySubcategoria:n,getSubcategoria:L,updateRelatorio:f}=Re(),{showToast:D}=be(),{showGlobalLoading:_,hideGlobalLoading:w}=ve(),[v,P]=d.useState(""),[q,F]=d.useState(!1),[j,y]=d.useState("");if(!x)return null;const s=S?n(S.subcategoriaId,C?.tipo||"periodica"):[],$=C?.data?Be(new Date(C.data),"d MMM yyyy",{locale:Ue}):"",l=`Relatório de manutenção — ${S?.marca} ${S?.modelo} (${$}) — Navel`,c=async o=>{o.preventDefault(),y("");const g=v.trim();if(!g){y("Indique o endereço de email do destinatário.");return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(g)){y("Endereço de email inválido.");return}F(!0),_();try{const h=S?L(S.subcategoriaId):null,A=ca(k,C,S,B,s,{subcategoriaNome:h?.nome,ultimoEnvio:k.ultimoEnvio,logoUrl:"/manut/logo.png"}),z=typeof window<"u"?window.location.origin:"",m=z?`${z.replace(/\/$/,"")}/api/send-report.php`:"/api/send-report.php",M=await fetch(m,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({auth_token:_e.AUTH_TOKEN,destinatario:g,cc:Te,assunto:l,corpoHtml:A})});if(!M.ok){const b=await M.text();throw new Error(b||`Erro ${M.status}`)}f(k.id,{ultimoEnvio:{data:new Date().toISOString(),destinatario:g}}),D(`Email enviado para ${g}.`,"success"),P(""),N()}catch(h){y(h.message||"Erro ao enviar email.")}finally{F(!1),w()}};return e.jsx("div",{className:"modal-overlay",onClick:N,children:e.jsxs("div",{className:"modal",onClick:o=>o.stopPropagation(),children:[e.jsx("h2",{children:"Enviar relatório por email"}),e.jsxs("p",{className:"text-muted",children:["O email será enviado para o endereço indicado e em cópia para ",Te,"."]}),e.jsxs("form",{onSubmit:c,children:[e.jsxs("label",{children:["Email do destinatário ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:v,onChange:o=>{P(o.target.value),y("")},placeholder:"ex: cliente@empresa.pt",required:!0,disabled:q})]}),j&&e.jsx("p",{className:"form-erro",children:j}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:N,disabled:q,children:"Cancelar"}),e.jsx("button",{type:"submit",disabled:q,children:q?"A enviar…":e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"✉"})," Enviar email"]})})]})]})]})})}const Oe="comercial@navel.pt";function ga({isOpen:x,onClose:N,documento:C,maquina:k}){const{showToast:S}=be(),{showGlobalLoading:B,hideGlobalLoading:n}=ve(),[L,f]=d.useState(""),[D,_]=d.useState(!1),[w,v]=d.useState("");if(!x)return null;const q=`Documento: ${C?.titulo||"Documento"} — ${k?.marca} ${k?.modelo} — Navel`,F=`
<!DOCTYPE html>
<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5;color:#333">
<p>Segue o documento solicitado relativo ao equipamento <strong>${Q(k?.marca||"")} ${Q(k?.modelo||"")}</strong> (Nº Série: ${Q(String(k?.numeroSerie||"—"))}).</p>
<p><a href="${Ge(C?.url)}" style="color:#2563eb">Abrir documento (PDF)</a></p>
<p style="margin-top:2em;font-size:0.9em;color:#666">— Navel Manutenções · www.navel.pt</p>
<p style="margin-top:1.5em;font-size:0.75em;color:#999;border-top:1px solid #ddd;padding-top:0.5em">${Q(Le)}</p>
</body></html>`,j=async y=>{y.preventDefault(),v("");const s=L.trim();if(!s){v("Indique o endereço de email do destinatário.");return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)){v("Endereço de email inválido.");return}_(!0),B();try{const l=typeof window<"u"?window.location.origin:"",c=l?`${l.replace(/\/$/,"")}/api/send-report.php`:"/api/send-report.php",o=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({auth_token:_e.AUTH_TOKEN,destinatario:s,cc:Oe,assunto:q,corpoHtml:F})});if(!o.ok){const g=await o.text();throw new Error(g||`Erro ${o.status}`)}S(`Email enviado para ${s}.`,"success"),f(""),N()}catch(l){v(l.message||"Erro ao enviar email.")}finally{_(!1),n()}};return e.jsx("div",{className:"modal-overlay",onClick:N,children:e.jsxs("div",{className:"modal",onClick:y=>y.stopPropagation(),children:[e.jsx("h2",{children:"Enviar documento por email"}),e.jsxs("p",{className:"text-muted",children:["O email será enviado para o endereço indicado e em cópia para ",Oe,"."]}),e.jsxs("form",{onSubmit:j,children:[e.jsxs("label",{children:["Email do destinatário ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:L,onChange:y=>{f(y.target.value),v("")},placeholder:"ex: cliente@empresa.pt",required:!0,disabled:D})]}),w&&e.jsx("p",{className:"form-erro",children:w}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:N,disabled:D,children:"Cancelar"}),e.jsx("button",{type:"submit",disabled:D,children:D?"A enviar…":"Enviar"})]})]})]})})}const le={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",sede:"Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",web:"www.navel.pt"};function ba(x,N,C,k,S,B={}){const n=Q,L=B.logoUrl??"/manut/logo.png",f=new Date().toISOString().slice(0,10),D=W(f,!0),_=new Date().getFullYear(),w=N.map(s=>{const $=S(s.subcategoriaId),l=C.filter(m=>m.maquinaId===s.id),c=l.filter(m=>m.status==="concluida").sort((m,M)=>M.data.localeCompare(m.data))[0],o=l.filter(m=>m.status==="agendada"||m.status==="pendente").sort((m,M)=>m.data.localeCompare(M.data))[0],g=o&&o.data<f,R=l.filter(m=>m.status==="concluida").length,h=c?k.find(m=>m.manutencaoId===c.id):null;let A,z;return s.proximaManut?g?(A="badge-atraso",z="Em atraso"):(A="badge-ok",z="Conforme"):(A="badge-montagem",z="Por instalar"),{m:s,sub:$,ultima:c,proxima:o,emAtraso:g,totalManuts:R,relUltima:h,estadoBadge:A,estadoLabel:z}}),v=N.length,P=w.filter(s=>s.emAtraso).length,q=w.filter(s=>!s.emAtraso&&s.m.proximaManut).length,F=w.filter(s=>!s.m.proximaManut).length,j=v>0?Math.round(q/v*100):0;return`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Frota — ${n(x.nome)}</title>
<style>
/* ── Reset / Página ── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
@page{size:A4 portrait;margin:14mm 12mm 12mm}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:9pt;color:#1e293b;background:#fff;line-height:1.4}
/* ── Paleta ── */
:root{
  --azul:#0f4c81;--azul-light:#e8f1fb;--cinza:#f8fafc;
  --verde:#15803d;--verde-light:#dcfce7;
  --vermelho:#dc2626;--vermelho-light:#fee2e2;
  --laranja:#d97706;--laranja-light:#fef3c7;
  --muted:#64748b;--border:#e2e8f0;
}
/* ── Cabeçalho ── */
.header{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px;border-bottom:2px solid var(--azul);margin-bottom:10px}
.header-logo img{height:36px;object-fit:contain}
.header-empresa{text-align:right;font-size:7.5pt;color:var(--muted);line-height:1.5}
.header-empresa strong{color:var(--azul);font-size:8.5pt}
/* ── Títulos de secção ── */
.secao-titulo{background:var(--azul);color:#fff;padding:4px 8px;font-size:8pt;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px;border-radius:3px}
/* ── Ficha do cliente ── */
.cliente-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:3px 12px;padding:8px 10px;background:var(--cinza);border-radius:4px;border:1px solid var(--border);margin-bottom:10px}
.cliente-field{display:flex;flex-direction:column;gap:1px}
.c-label{font-size:7pt;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}
.c-value{font-size:8.5pt;font-weight:600;color:#1e293b}
/* ── KPIs ── */
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px}
.kpi-card{background:var(--cinza);border:1px solid var(--border);border-radius:5px;padding:7px 8px;text-align:center}
.kpi-card.kpi-verde{background:var(--verde-light);border-color:var(--verde)}
.kpi-card.kpi-vermelho{background:var(--vermelho-light);border-color:var(--vermelho)}
.kpi-card.kpi-laranja{background:var(--laranja-light);border-color:var(--laranja)}
.kpi-numero{font-size:18pt;font-weight:800;line-height:1.1}
.kpi-verde .kpi-numero{color:var(--verde)}
.kpi-vermelho .kpi-numero{color:var(--vermelho)}
.kpi-laranja .kpi-numero{color:var(--laranja)}
.kpi-label{font-size:7pt;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;margin-top:2px}
/* ── Tabela de frota ── */
.tabela-frota{width:100%;border-collapse:collapse;font-size:8pt}
.tabela-frota th{background:var(--azul);color:#fff;padding:4px 5px;text-align:left;font-size:7.5pt;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.tabela-frota td{padding:3.5px 5px;border-bottom:1px solid var(--border);vertical-align:middle}
.tabela-frota tr:nth-child(even) td{background:var(--cinza)}
.tabela-frota tr:hover td{background:var(--azul-light)}
.col-equip{width:28%}
.col-serie{width:16%;font-family:monospace;font-size:7.5pt;color:var(--muted)}
.col-ultima{width:14%;text-align:center}
.col-proxima{width:14%;text-align:center}
.col-total{width:8%;text-align:center;color:var(--muted)}
.col-estado{width:13%;text-align:center}
.col-num{width:7%;text-align:center;color:var(--muted);font-size:7pt}
/* ── Badges ── */
.badge{display:inline-block;padding:1.5px 6px;border-radius:10px;font-size:7pt;font-weight:700;white-space:nowrap}
.badge-ok{background:var(--verde-light);color:var(--verde)}
.badge-atraso{background:var(--vermelho-light);color:var(--vermelho)}
.badge-montagem{background:var(--laranja-light);color:var(--laranja)}
.data-atraso{color:var(--vermelho);font-weight:600}
.data-ok{color:var(--verde)}
/* ── Rodapé ── */
.rodape{margin-top:12px;padding-top:6px;border-top:1px solid var(--border);font-size:7pt;color:var(--muted);display:flex;justify-content:space-between;align-items:center}
.rodape-data{font-size:7pt;color:var(--muted)}
</style>
</head>
<body>

<!-- Cabeçalho -->
<div class="header">
  <div class="header-logo">
    <img src="${L}" alt="Navel-Açores">
  </div>
  <div class="header-empresa">
    <strong>${n(le.nome)}</strong><br>
    ${n(le.sede)}<br>
    ${n(le.telefones)} · ${n(le.web)}
  </div>
</div>

<!-- Título -->
<div class="secao-titulo">Relatório Executivo de Frota — ${_}</div>

<!-- Ficha do cliente -->
<div class="cliente-grid">
  <div class="cliente-field">
    <span class="c-label">Cliente</span>
    <span class="c-value">${n(x.nome)}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">NIF</span>
    <span class="c-value">${n(x.nif??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Localidade</span>
    <span class="c-value">${n(x.localidade??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Morada</span>
    <span class="c-value">${n(x.morada??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Telefone</span>
    <span class="c-value">${n(x.telefone??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Email</span>
    <span class="c-value">${n(x.email??"—")}</span>
  </div>
</div>

<!-- KPIs -->
<div class="kpis">
  <div class="kpi-card">
    <div class="kpi-numero">${v}</div>
    <div class="kpi-label">Equipamentos</div>
  </div>
  <div class="kpi-card ${j>=80?"kpi-verde":j>=50?"kpi-laranja":"kpi-vermelho"}">
    <div class="kpi-numero">${j}%</div>
    <div class="kpi-label">Taxa de cumprimento</div>
  </div>
  <div class="kpi-card ${P>0?"kpi-vermelho":"kpi-verde"}">
    <div class="kpi-numero">${P}</div>
    <div class="kpi-label">Em atraso</div>
  </div>
  <div class="kpi-card ${F>0?"kpi-laranja":""}">
    <div class="kpi-numero">${F}</div>
    <div class="kpi-label">Por instalar</div>
  </div>
</div>

<!-- Tabela de frota -->
<div class="secao-titulo">Frota de equipamentos (${v})</div>
<table class="tabela-frota">
  <thead>
    <tr>
      <th class="col-equip">Equipamento / Modelo</th>
      <th class="col-serie">Nº Série</th>
      <th class="col-ultima">Última manut.</th>
      <th class="col-proxima">Próxima manut.</th>
      <th class="col-total">Nº serv.</th>
      <th class="col-estado">Estado</th>
      <th class="col-num">Últ. relatório</th>
    </tr>
  </thead>
  <tbody>
    ${w.map(({m:s,sub:$,ultima:l,proxima:c,relUltima:o,estadoBadge:g,estadoLabel:R})=>`
    <tr>
      <td class="col-equip">
        <strong>${n(s.marca)} ${n(s.modelo)}</strong>
        ${$?`<br><span style="font-size:7pt;color:var(--muted)">${n($.nome)}</span>`:""}
      </td>
      <td class="col-serie">${n(s.numeroSerie)}</td>
      <td class="col-ultima" style="text-align:center">${l?W(l.data,!0):"—"}</td>
      <td class="col-proxima" style="text-align:center">
        ${c?`<span class="${c.data<f?"data-atraso":"data-ok"}">${W(c.data,!0)}</span>`:s.proximaManut?`<span class="${s.proximaManut<f?"data-atraso":"data-ok"}">${W(s.proximaManut,!0)}</span>`:"—"}
      </td>
      <td class="col-total">${s.proximaManut?C.filter(h=>h.maquinaId===s.id&&h.status==="concluida").length:"—"}</td>
      <td class="col-estado" style="text-align:center"><span class="badge ${g}">${n(R)}</span></td>
      <td class="col-num">${o?.numeroRelatorio?`<span style="font-size:7pt">${n(o.numeroRelatorio)}</span>`:"—"}</td>
    </tr>`).join("")}
  </tbody>
</table>

${P>0?`
<div class="secao-titulo" style="background:var(--vermelho);margin-top:12px">Manutenções em atraso (${P})</div>
<table class="tabela-frota">
  <thead>
    <tr>
      <th style="width:35%">Equipamento</th>
      <th style="width:18%">Nº Série</th>
      <th style="width:15%">Data prevista</th>
      <th style="width:10%">Dias atraso</th>
      <th style="width:22%">Observações</th>
    </tr>
  </thead>
  <tbody>
    ${w.filter(s=>s.emAtraso).map(({m:s,sub:$,proxima:l})=>{const c=Math.max(0,Math.floor((new Date(f)-new Date(l.data))/864e5));return`<tr>
        <td><strong>${n(s.marca)} ${n(s.modelo)}</strong>${$?` <span style="color:var(--muted);font-size:7pt">· ${n($.nome)}</span>`:""}</td>
        <td style="font-family:monospace;font-size:7.5pt">${n(s.numeroSerie)}</td>
        <td class="data-atraso">${W(l.data,!0)}</td>
        <td class="data-atraso" style="text-align:center;font-weight:700">${c}d</td>
        <td style="font-size:7.5pt;color:var(--muted)">${n(l.observacoes??"")}</td>
      </tr>`}).join("")}
  </tbody>
</table>`:""}

<!-- Rodapé -->
<div class="rodape">
  <span>${n(Le)}</span>
  <span class="rodape-data">Documento gerado em ${D}</span>
</div>

</body>
</html>`}const va={pendente:"Pendente",agendada:"Agendada",concluida:"Executada"};function Oa(){const{clientes:x,maquinas:N,manutencoes:C,relatorios:k,addCliente:S,updateCliente:B,removeCliente:n,importClientes:L,getSubcategoria:f,getCategoria:D,getChecklistBySubcategoria:_,getRelatorioByManutencao:w}=Re(),{canDelete:v,canEditCliente:P,canAddCliente:q,isAdmin:F}=ea(),{showToast:j}=be(),{showGlobalLoading:y,hideGlobalLoading:s}=ve(),$=oa(),[l,c]=d.useState(null),[o,g]=d.useState(null),[R,h]=d.useState("categorias"),[A,z]=d.useState(null),[m,M]=d.useState(null),[b,X]=d.useState(null),[Z,ee]=d.useState(null),[je,Ne]=d.useState(null),[ye,re]=d.useState(null),[E,ae]=d.useState(null),[V,de]=d.useState(null),[ce,Ce]=d.useState(null),[T,O]=d.useState({nif:"",nome:"",morada:"",codigoPostal:"",localidade:"",telefone:"",email:""}),[ke,H]=d.useState(""),[me,Se]=d.useState(""),Ee=aa(me,250),[Ve,te]=d.useState(!1),[I,se]=d.useState(null),[ue,we]=d.useState("novos"),[qe,J]=d.useState(""),He=a=>{J(""),se(null);const t=a.target.files?.[0];if(!t)return;if(!t.name.endsWith(".json")){J("Selecione um ficheiro .json exportado pelo script extract-clientes-saft-2026.js");return}const r=new FileReader;r.onload=u=>{try{const i=JSON.parse(u.target.result);if(!Array.isArray(i)||!i[0]?.nif){J('Ficheiro inválido — deve ser um array de clientes com campo "nif".');return}const p=new Set(x.map(Y=>Y.nif)),G=i.filter(Y=>!p.has(String(Y.nif))),xe=i.filter(Y=>p.has(String(Y.nif)));se({lista:i,novos:G.length,existentes:xe.length})}catch{J("Erro ao ler o ficheiro JSON — verifique se está correctamente formatado.")}},r.readAsText(t,"utf-8"),a.target.value=""},Je=()=>{if(!I)return;const a=L(I.lista,ue);te(!1),se(null);const t=[];a.adicionados&&t.push(`${a.adicionados} novos`),a.atualizados&&t.push(`${a.atualizados} actualizados`),a.ignorados&&t.push(`${a.ignorados} ignorados`),j(`Importação concluída: ${t.join(", ")}.`,"success",5e3)},Ke=()=>{O({nif:"",nome:"",morada:"",codigoPostal:"",localidade:"",telefone:"",email:""}),H(""),c("add")},$e=a=>{O({nif:a.nif,nome:a.nome,morada:a.morada||"",codigoPostal:a.codigoPostal||"",localidade:a.localidade||"",telefone:a.telefone||"",email:a.email||""}),H(""),c("edit")},ze=a=>{g(a),h("categorias"),z(null),M(null),X(null),O({nif:a.nif,nome:a.nome,morada:a.morada||"",codigoPostal:a.codigoPostal||"",localidade:a.localidade||"",telefone:a.telefone||"",email:a.email||""}),c("ficha")},pe=()=>{c(null),g(null),h("categorias"),z(null),M(null),X(null)},Ye=a=>{if(a.preventDefault(),H(""),!T.email?.trim()){H("O email do cliente é obrigatório para envio de lembretes e relatórios.");return}if(l==="add"){if(S(T)===null){H("Já existe um cliente com este NIF.");return}j("Cliente adicionado com sucesso.","success")}else{const{nif:t,...r}=T;B(t,r),o?.nif===t&&g(u=>u?{...u,...r}:null),j("Dados do cliente actualizados.","success")}l!=="ficha"&&c(null)},K=a=>N.filter(t=>t.clienteNif===a).length,Me=a=>N.filter(t=>t.clienteNif===a),Pe=async a=>{const t=Me(a.nif);if(t.length===0){j("Este cliente não tem equipamentos registados.","warning");return}y();try{const r=ba(a,t,C,k??[],f,{logoUrl:"/manut/logo.png"}),u=`frota_${a.nif}_${new Date().toISOString().slice(0,10)}.pdf`;await ua(r,u)}catch{j("Erro ao gerar relatório de frota.","error",4e3)}finally{s()}},U=o?Me(o.nif):[],We=U.reduce((a,t)=>{const r=f(t.subcategoriaId),u=r?D(r.categoriaId):null;return u&&!a.find(i=>i.id===u.id)&&a.push(u),a},[]).sort((a,t)=>(a.nome||"").localeCompare(t.nome||"")),Qe=A?U.filter(a=>f(a.subcategoriaId)?.categoriaId===A.id).reduce((a,t)=>{const r=f(t.subcategoriaId);return r&&!a.find(u=>u.id===r.id)&&a.push(r),a},[]).sort((a,t)=>(a.nome||"").localeCompare(t.nome||"")):[],Xe=m?U.filter(a=>a.subcategoriaId===m.id):[],Ae=a=>C.filter(t=>t.maquinaId===a).sort((t,r)=>new Date(r.data)-new Date(t.data)),he=d.useMemo(()=>{const a=Ee.trim().toLowerCase();return[...a?(()=>{const r=a.split(/\s+/).filter(Boolean);return x.filter(u=>{const i=(u.nif||"").toLowerCase().includes(a),p=r.some(G=>(u.nome||"").toLowerCase().includes(G));return i||p})})():x].sort((r,u)=>(r.nome||"").localeCompare(u.nome||"","pt"))},[Ee,x]);return e.jsxs("div",{className:"page",children:[e.jsxs("div",{className:"page-header",children:[e.jsxs("div",{children:[e.jsxs("button",{type:"button",className:"btn-back",onClick:()=>$(-1),children:[e.jsx(ie,{size:20}),"Voltar atrás"]}),e.jsx("h1",{children:"Clientes"}),e.jsx("p",{className:"page-sub",children:"Empresas e proprietários de equipamentos Navel"})]}),e.jsxs("div",{style:{display:"flex",gap:"0.5rem",flexWrap:"wrap"},children:[F&&e.jsxs("button",{type:"button",className:"secondary",onClick:()=>{te(!0),se(null),J("")},children:[e.jsx(ne,{size:18})," Importar SAF-T"]}),q&&e.jsxs("button",{type:"button",onClick:Ke,children:[e.jsx(fe,{size:18})," Novo cliente"]})]})]}),e.jsxs("div",{className:"search-bar",children:[e.jsx(ta,{size:18,className:"search-icon"}),e.jsx("input",{type:"search",value:me,onChange:a=>Se(a.target.value),placeholder:"Pesquisar por NIF ou palavra do nome...","aria-label":"Pesquisar clientes"}),me&&e.jsx("button",{type:"button",className:"search-clear",onClick:()=>Se(""),"aria-label":"Limpar pesquisa",children:"×"})]}),e.jsxs("div",{className:"clientes-mobile-lista",children:[he.map(a=>{const t=K(a.nif);return e.jsxs("button",{type:"button",className:"cliente-mobile-card",onClick:()=>ze(a),children:[e.jsxs("div",{className:"cliente-mobile-main",children:[e.jsx("span",{className:"cliente-mobile-nome",children:a.nome}),e.jsxs("div",{className:"cliente-mobile-meta",children:[e.jsx("code",{className:"cliente-mobile-nif",children:a.nif}),a.localidade&&e.jsx("span",{className:"cliente-mobile-loc",children:a.localidade}),e.jsxs("span",{className:"cliente-mobile-maq",children:[t," máq."]}),!a.email&&e.jsxs("span",{className:"sem-email-aviso",title:"Sem email registado",children:[e.jsx(Ie,{size:11})," Sem email"]})]})]}),e.jsx(oe,{size:16,className:"cliente-mobile-chevron"})]},a.nif)}),he.length===0&&e.jsx("p",{className:"text-muted",style:{padding:"1rem 0",textAlign:"center"},children:"Nenhum cliente encontrado."})]}),e.jsx("div",{className:"table-card card clientes-table",children:e.jsxs("table",{className:"data-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"NIF"}),e.jsx("th",{children:"Nome do Cliente"}),e.jsx("th",{children:"Morada"}),e.jsx("th",{children:"Localidade"}),e.jsx("th",{children:"Telefone"}),e.jsx("th",{children:"Email"}),e.jsx("th",{children:"Máquinas"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:he.map(a=>e.jsxs("tr",{children:[e.jsx("td",{"data-label":"NIF",children:e.jsx("code",{children:a.nif})}),e.jsx("td",{"data-label":"Nome",children:e.jsx("button",{type:"button",className:"btn-link-inline",onClick:()=>ze(a),title:"Abrir ficha",children:e.jsx("strong",{children:a.nome})})}),e.jsx("td",{"data-label":"Morada",children:a.morada||"—"}),e.jsx("td",{"data-label":"Localidade",children:a.localidade||"—"}),e.jsx("td",{"data-label":"Telefone",children:a.telefone||"—"}),e.jsx("td",{"data-label":"Email",children:a.email?a.email:e.jsxs("span",{className:"sem-email-aviso",title:"Email em falta — edite o cliente para corrigir",children:[e.jsx(Ie,{size:13})," Sem email"]})}),e.jsx("td",{"data-label":"Máquinas",children:K(a.nif)}),e.jsxs("td",{className:"actions","data-label":"",children:[K(a.nif)>0&&e.jsx("button",{className:"icon-btn secondary",onClick:()=>Pe(a),title:"Relatório executivo de frota (PDF)",children:e.jsx(Fe,{size:16})}),P&&e.jsx("button",{className:"icon-btn secondary",onClick:()=>$e(a),title:"Editar",children:e.jsx(ge,{size:16})}),v&&e.jsx("button",{className:"icon-btn danger",onClick:()=>{n(a.nif),j("Cliente eliminado.","info")},disabled:K(a.nif)>0,title:K(a.nif)>0?"Elimine as máquinas primeiro":"Eliminar",children:e.jsx(pa,{size:16})})]})]},a.nif))})]})}),l==="ficha"&&o&&e.jsx("div",{className:"modal-overlay modal-ficha-overlay",onClick:pe,children:e.jsxs("div",{className:"modal modal-ficha-cliente",onClick:a=>a.stopPropagation(),children:[e.jsxs("div",{className:"ficha-header",children:[e.jsx("h2",{className:"ficha-titulo",children:o.nome}),P&&e.jsxs("button",{className:"btn secondary ficha-btn-editar",onClick:()=>{pe(),$e(o)},title:"Editar dados do cliente",children:[e.jsx(ge,{size:14})," Editar"]})]}),e.jsxs("div",{className:"ficha-cliente-dados",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"NIF:"})," ",o.nif," · ",e.jsx("strong",{children:"Morada:"})," ",o.morada||"—"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Localidade:"})," ",o.codigoPostal," ",o.localidade," · ",e.jsx("strong",{children:"Telefone:"})," ",o.telefone||"—"," · ",e.jsx("strong",{children:"Email:"})," ",o.email||"—"]})]}),U.length>0&&e.jsxs("button",{className:"btn secondary ficha-btn-frota",onClick:()=>Pe(o),title:"Relatório executivo de frota (PDF)",children:[e.jsx(Fe,{size:15})," Relatório de frota"]}),U.length===0?e.jsxs("div",{className:"ficha-empty",children:[e.jsx("p",{className:"text-muted",children:"Este cliente ainda não tem máquinas registadas."}),q&&e.jsxs("button",{type:"button",className:"btn-add-maquina",onClick:()=>ee({mode:"add",clienteNif:o.nif}),children:[e.jsx(fe,{size:18})," Adicionar máquina"]})]}):e.jsxs(e.Fragment,{children:[R==="categorias"&&e.jsxs("div",{className:"ficha-categorias",children:[e.jsx("h3",{children:"Categorias"}),e.jsx("div",{className:"categorias-grid",children:We.map(a=>{const t=U.filter(r=>f(r.subcategoriaId)?.categoriaId===a.id).length;return e.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>{z(a),h("subcategorias")},children:[e.jsx("h4",{children:a.nome}),e.jsxs("p",{children:[t," equipamento(s)"]}),e.jsx(oe,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},a.id)})})]}),R==="subcategorias"&&A&&e.jsxs("div",{className:"ficha-subcategorias",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{z(null),h("categorias")},children:[e.jsx(ie,{size:16})," Categorias"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",A.nome]})]}),e.jsx("h3",{children:"Subcategorias"}),e.jsx("div",{className:"categorias-grid",children:Qe.map(a=>{const t=U.filter(r=>r.subcategoriaId===a.id).length;return e.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>{M(a),h("maquinas")},children:[e.jsx("h4",{children:a.nome}),e.jsxs("p",{children:[t," equipamento(s)"]}),e.jsx(oe,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},a.id)})})]}),R==="maquinas"&&m&&e.jsxs("div",{className:"ficha-maquinas-view",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{M(null),h("subcategorias")},children:[e.jsx(ie,{size:16})," Subcategorias"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",m.nome]})]}),e.jsx("h3",{children:"Frota de máquinas"}),e.jsx("div",{className:"maquinas-ficha-lista",children:Xe.map(a=>e.jsxs("button",{type:"button",className:"maquina-ficha-card",onClick:()=>{X(a),h("maquina-detalhe")},children:[e.jsxs("strong",{children:[a.marca," ",a.modelo]}),e.jsxs("span",{className:"text-muted",children:[" — Nº Série: ",a.numeroSerie]}),e.jsx(oe,{size:18,style:{marginLeft:"auto",opacity:.6}})]},a.id))})]}),R==="maquina-detalhe"&&b&&(()=>{const a=N.find(i=>i.id===b.id)??b,t=a.documentos??[],r=i=>t.find(p=>p.tipo===i),u=i=>De.find(p=>p.id===i)?.label??i;return e.jsxs("div",{className:"ficha-maquina-detalhe",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{X(null),h("maquinas")},children:[e.jsx(ie,{size:16})," Frota"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",b.marca," ",b.modelo]})]}),e.jsxs("div",{className:"maquina-detalhe-header",children:[e.jsxs("h3",{children:[b.marca," ",b.modelo," — Nº Série: ",b.numeroSerie]}),e.jsx("div",{className:"maquina-detalhe-actions",children:F&&e.jsxs(e.Fragment,{children:[e.jsxs("button",{type:"button",className:"secondary",onClick:()=>{re(null),ee({mode:"edit",maquina:b})},children:[e.jsx(ge,{size:16})," Editar"]}),e.jsxs("button",{type:"button",className:"secondary",onClick:()=>re(b),children:[e.jsx(ia,{size:16})," Documentação"]})]})})]}),e.jsx("h4",{children:"Documentação obrigatória"}),e.jsx("div",{className:"doc-table-wrapper",children:e.jsxs("table",{className:"data-table doc-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Documento"}),e.jsx("th",{children:"Existe"}),e.jsx("th",{children:"Ações"})]})}),e.jsx("tbody",{children:De.map(i=>{const p=i.id==="outros"?t.filter(xe=>xe.tipo==="outros")[0]:r(i.id),G=!!p;return e.jsxs("tr",{children:[e.jsx("td",{"data-label":"Documento",children:u(i.id)}),e.jsx("td",{"data-label":"Existe",children:e.jsx("span",{className:G?"badge badge-sim":"badge badge-nao",children:G?"Sim":"Não"})}),e.jsx("td",{className:"doc-table-actions","data-label":"Ações",children:p?e.jsxs(e.Fragment,{children:[e.jsx("a",{href:Ge(p.url),target:"_blank",rel:"noopener noreferrer",className:"icon-btn secondary",title:"Visualizar",children:e.jsx(ha,{size:16})}),e.jsx("button",{type:"button",className:"icon-btn secondary",onClick:()=>Ce({documento:p,maquina:a}),title:"Enviar por email",children:e.jsx(ma,{size:16})})]}):e.jsx("span",{className:"text-muted",children:"—"})})]},i.id)})})]})}),e.jsx("h4",{children:"Histórico de manutenções"}),e.jsx("div",{className:"manutencoes-histórico",children:Ae(b.id).length===0?e.jsx("p",{className:"text-muted",children:"Nenhuma manutenção registada."}):Ae(b.id).map(i=>{const p=w(i.id);return e.jsxs("div",{className:"manutencao-item",children:[e.jsxs("button",{type:"button",className:"manutencao-item-btn",onClick:()=>ae({manutencao:i,relatorio:p,maquina:b,cliente:o}),children:[e.jsxs("div",{children:[e.jsx("strong",{children:Be(new Date(i.data),"d MMM yyyy",{locale:Ue})}),e.jsxs("span",{className:"text-muted",children:[" — ",i.tecnico||p?.tecnico||"Não atribuído"]})]}),e.jsx("span",{className:`badge badge-${i.status}`,children:va[i.status]})]}),p?.assinadoPeloCliente&&e.jsx("button",{type:"button",className:"btn-enviar-email",onClick:G=>{G.stopPropagation(),de({manutencao:i,relatorio:p,maquina:b,cliente:o})},children:"Enviar relatório por email"})]},i.id)})})]})})(),q&&e.jsxs("button",{type:"button",className:"btn-add-maquina",onClick:()=>ee({mode:"add",clienteNif:o.nif}),style:{marginTop:"1rem"},children:[e.jsx(fe,{size:18})," Adicionar máquina"]})]}),e.jsx("div",{className:"form-actions",style:{marginTop:"1rem"},children:e.jsx("button",{type:"button",className:"secondary",onClick:pe,children:"Fechar"})})]})}),Z&&e.jsx(na,{isOpen:!0,onClose:()=>ee(null),mode:Z.mode,clienteNifLocked:Z.clienteNif,maquina:Z.maquina,onSave:(a,t)=>{t==="add"&&a&&sa.includes(a.subcategoriaId)&&Ne(a)}}),e.jsx(la,{isOpen:!!je,onClose:()=>Ne(null),maquina:je,modoInicial:!0}),e.jsx(ra,{isOpen:!!ye,onClose:()=>re(null),maquina:ye}),E&&e.jsx("div",{className:"modal-overlay",onClick:()=>ae(null),children:e.jsxs("div",{className:"modal modal-relatorio modal-relatorio-ficha",onClick:a=>a.stopPropagation(),children:[e.jsxs("div",{className:"modal-relatorio-header",children:[e.jsx("h2",{children:"Relatório de manutenção"}),e.jsx("button",{type:"button",className:"secondary",onClick:()=>ae(null),children:"Fechar"})]}),e.jsx(da,{relatorio:E.relatorio,manutencao:E.manutencao,maquina:E.maquina,cliente:E.cliente,checklistItems:E.maquina?_(E.maquina.subcategoriaId,E.manutencao?.tipo||"periodica"):[]}),E.relatorio?.assinadoPeloCliente&&e.jsx("div",{className:"form-actions",style:{marginTop:"1rem"},children:e.jsx("button",{type:"button",onClick:()=>{ae(null),de({manutencao:E.manutencao,relatorio:E.relatorio,maquina:E.maquina,cliente:E.cliente})},children:"Enviar relatório por email"})})]})}),V&&e.jsx(fa,{isOpen:!0,onClose:()=>de(null),manutencao:V.manutencao,relatorio:V.relatorio,maquina:V.maquina,cliente:V.cliente}),ce&&e.jsx(ga,{isOpen:!0,onClose:()=>Ce(null),documento:ce.documento,maquina:ce.maquina}),Ve&&e.jsx("div",{className:"modal-overlay",onClick:()=>te(!1),children:e.jsxs("div",{className:"modal modal-import",onClick:a=>a.stopPropagation(),children:[e.jsxs("h2",{children:[e.jsx(ne,{size:20,style:{verticalAlign:"middle",marginRight:"0.5rem"}}),"Importar clientes — SAF-T"]}),e.jsxs("p",{className:"text-muted",style:{marginBottom:"1rem",fontSize:"0.9rem"},children:["Selecione o ficheiro ",e.jsx("strong",{children:"clientes-navel-2026.json"})," gerado pelo script de extracção SAF-T. O ficheiro deve estar em ",e.jsx("code",{children:"C:\\Cursor_Dados_Gestor\\dados-exportados\\"}),"."]}),e.jsxs("label",{className:"import-file-label",children:[e.jsx("input",{type:"file",accept:".json",onChange:He,style:{display:"none"},id:"import-json-input"}),e.jsxs("span",{className:"btn secondary",style:{cursor:"pointer"},onClick:()=>document.getElementById("import-json-input").click(),children:[e.jsx(ne,{size:16})," Escolher ficheiro JSON…"]})]}),qe&&e.jsx("p",{className:"form-erro",style:{marginTop:"0.75rem"},children:qe}),I&&e.jsxs("div",{className:"import-preview",children:[e.jsxs("div",{className:"import-preview-stats",children:[e.jsxs("div",{className:"import-stat import-stat-new",children:[e.jsx("span",{className:"import-stat-num",children:I.novos}),e.jsx("span",{className:"import-stat-label",children:"novos clientes"})]}),e.jsxs("div",{className:"import-stat import-stat-exist",children:[e.jsx("span",{className:"import-stat-num",children:I.existentes}),e.jsx("span",{className:"import-stat-label",children:"já existem"})]}),e.jsxs("div",{className:"import-stat",children:[e.jsx("span",{className:"import-stat-num",children:I.lista.length}),e.jsx("span",{className:"import-stat-label",children:"total no ficheiro"})]})]}),e.jsxs("fieldset",{className:"import-modo-fieldset",children:[e.jsx("legend",{children:"O que fazer com os clientes já existentes?"}),e.jsxs("label",{className:"import-radio",children:[e.jsx("input",{type:"radio",name:"importModo",value:"novos",checked:ue==="novos",onChange:()=>we("novos")}),e.jsx("strong",{children:"Ignorar"})," — só adiciona os ",I.novos," novos (recomendado)"]}),e.jsxs("label",{className:"import-radio",children:[e.jsx("input",{type:"radio",name:"importModo",value:"atualizar",checked:ue==="atualizar",onChange:()=>we("atualizar")}),e.jsx("strong",{children:"Actualizar"})," — substitui morada/contactos dos ",I.existentes," existentes com dados do SAF-T"]})]})]}),e.jsxs("div",{className:"form-actions",style:{marginTop:"1.25rem"},children:[e.jsx("button",{type:"button",className:"secondary",onClick:()=>te(!1),children:"Cancelar"}),e.jsxs("button",{type:"button",onClick:Je,disabled:!I,children:[e.jsx(ne,{size:16})," Importar ",I?I.lista.length:""," clientes"]})]})]})}),l&&l!=="ficha"&&e.jsx("div",{className:"modal-overlay",onClick:()=>c(null),children:e.jsxs("div",{className:"modal",onClick:a=>a.stopPropagation(),children:[e.jsx("h2",{children:l==="add"?"Novo cliente":"Editar cliente"}),ke&&e.jsx("p",{className:"form-erro",children:ke}),e.jsxs("form",{onSubmit:Ye,children:[e.jsxs("label",{children:["NIF ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{required:!0,value:T.nif,onChange:a=>O(t=>({...t,nif:a.target.value})),placeholder:"123456789",readOnly:l==="edit",className:l==="edit"?"readonly":""})]}),e.jsxs("label",{children:["Nome do Cliente ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{required:!0,value:T.nome,onChange:a=>O(t=>({...t,nome:a.target.value})),placeholder:"Razão social"})]}),e.jsxs("label",{children:["Morada",e.jsx("input",{value:T.morada,onChange:a=>O(t=>({...t,morada:a.target.value}))})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("label",{children:["Código Postal",e.jsx("input",{value:T.codigoPostal,onChange:a=>O(t=>({...t,codigoPostal:a.target.value}))})]}),e.jsxs("label",{children:["Localidade",e.jsx("input",{value:T.localidade,onChange:a=>O(t=>({...t,localidade:a.target.value}))})]})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("label",{children:["Telefone",e.jsx("input",{value:T.telefone,onChange:a=>O(t=>({...t,telefone:a.target.value}))})]}),e.jsxs("label",{children:["Email ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:T.email,onChange:a=>O(t=>({...t,email:a.target.value})),placeholder:"email@cliente.pt"})]})]}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:()=>c(null),children:"Cancelar"}),e.jsx("button",{type:"submit",children:l==="add"?"Adicionar":"Guardar"})]})]})]})})]})}export{Oa as default};
