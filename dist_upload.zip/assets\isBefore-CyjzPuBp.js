import{t}from"./format-BvtC0E8y.js";function i(o,r){return+t(o)<+t(r)}export{i};
