import{c as Te,b as Ne,a as ne,u as le,j as e,A as ke,i as Le,k as Oe,S as Re,T as _e,f as oe,m as be}from"./index-DJNb0I1h.js";import{r as m,d as Ge}from"./vendor-Bk0NZ5Or.js";import{F as Be,M as Ve,D as He}from"./DocumentacaoModal-DnKduXv4.js";import{R as Ue}from"./RelatorioView-BpfsBj1L.js";import{r as Je,i as Ke}from"./gerarPdfRelatorio-DvYDwJj7.js";import{E as Ce,e as U,s as Ee,a as Ye,M as Qe}from"./emailConfig-D4E5Iu8I.js";import{f as qe}from"./format-BvtC0E8y.js";import{p as we}from"./pt-BAJJYN30.js";import{f as H}from"./datasAzores-CBhl9I61.js";import{A as W}from"./arrow-left-BmxozOpK.js";import{P as ie,a as fe}from"./plus-DEQufh-b.js";import{T as Xe}from"./trash-2-DIQrgkxa.js";const We=[["path",{d:"M6 22a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h8a2.4 2.4 0 0 1 1.704.706l3.588 3.588A2.4 2.4 0 0 1 20 8v12a2 2 0 0 1-2 2z",key:"1oefj6"}],["path",{d:"M14 2v5a1 1 0 0 0 1 1h5",key:"wfsgrz"}],["path",{d:"M8 18v-2",key:"qcmpov"}],["path",{d:"M12 18v-4",key:"q1q25u"}],["path",{d:"M16 18v-6",key:"15y0np"}]],ve=Te("file-chart-column-increasing",We),je="comercial@navel.pt";function Ze({isOpen:g,onClose:f,manutencao:y,relatorio:N,maquina:k,cliente:R}){const{getChecklistBySubcategoria:i,getSubcategoria:$,updateRelatorio:S}=Ne(),{showToast:A}=ne(),{showGlobalLoading:O,hideGlobalLoading:M}=le(),[x,z]=m.useState(""),[F,C]=m.useState(!1),[I,v]=m.useState("");if(!g)return null;const s=k?i(k.subcategoriaId,y?.tipo||"periodica"):[],u=y?.data?qe(new Date(y.data),"d MMM yyyy",{locale:we}):"",n=`Relatório de manutenção — ${k?.marca} ${k?.modelo} (${u}) — Navel`,o=async p=>{p.preventDefault(),v("");const h=x.trim();if(!h){v("Indique o endereço de email do destinatário.");return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(h)){v("Endereço de email inválido.");return}C(!0),O();try{const q=k?$(k.subcategoriaId):null,P=Je(N,y,k,R,s,{subcategoriaNome:q?.nome,ultimoEnvio:N.ultimoEnvio,logoUrl:"/manut/logo.png"}),D=typeof window<"u"?window.location.origin:"",c=D?`${D.replace(/\/$/,"")}/api/send-report.php`:"/api/send-report.php",d=await fetch(c,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({auth_token:Ce.AUTH_TOKEN,destinatario:h,cc:je,assunto:n,corpoHtml:P})});if(!d.ok){const G=await d.text();throw new Error(G||`Erro ${d.status}`)}S(N.id,{ultimoEnvio:{data:new Date().toISOString(),destinatario:h}}),A(`Email enviado para ${h}.`,"success"),z(""),f()}catch(q){v(q.message||"Erro ao enviar email.")}finally{C(!1),M()}};return e.jsx("div",{className:"modal-overlay",onClick:f,children:e.jsxs("div",{className:"modal",onClick:p=>p.stopPropagation(),children:[e.jsx("h2",{children:"Enviar relatório por email"}),e.jsxs("p",{className:"text-muted",children:["O email será enviado para o endereço indicado e em cópia para ",je,"."]}),e.jsxs("form",{onSubmit:o,children:[e.jsxs("label",{children:["Email do destinatário ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:x,onChange:p=>{z(p.target.value),v("")},placeholder:"ex: cliente@empresa.pt",required:!0,disabled:F})]}),I&&e.jsx("p",{className:"form-erro",children:I}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:f,disabled:F,children:"Cancelar"}),e.jsx("button",{type:"submit",disabled:F,children:F?"A enviar…":e.jsxs(e.Fragment,{children:[e.jsx("span",{children:"✉"})," Enviar email"]})})]})]})]})})}const ye="comercial@navel.pt";function ea({isOpen:g,onClose:f,documento:y,maquina:N}){const{showToast:k}=ne(),{showGlobalLoading:R,hideGlobalLoading:i}=le(),[$,S]=m.useState(""),[A,O]=m.useState(!1),[M,x]=m.useState("");if(!g)return null;const F=`Documento: ${y?.titulo||"Documento"} — ${N?.marca} ${N?.modelo} — Navel`,C=`
<!DOCTYPE html>
<html><head><meta charset="utf-8"></head><body style="font-family:Arial,sans-serif;font-size:14px;line-height:1.5;color:#333">
<p>Segue o documento solicitado relativo ao equipamento <strong>${U(N?.marca||"")} ${U(N?.modelo||"")}</strong> (Nº Série: ${U(String(N?.numeroSerie||"—"))}).</p>
<p><a href="${Ee(y?.url)}" style="color:#2563eb">Abrir documento (PDF)</a></p>
<p style="margin-top:2em;font-size:0.9em;color:#666">— Navel Manutenções · www.navel.pt</p>
<p style="margin-top:1.5em;font-size:0.75em;color:#999;border-top:1px solid #ddd;padding-top:0.5em">${U(ke)}</p>
</body></html>`,I=async v=>{v.preventDefault(),x("");const s=$.trim();if(!s){x("Indique o endereço de email do destinatário.");return}if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(s)){x("Endereço de email inválido.");return}O(!0),R();try{const n=typeof window<"u"?window.location.origin:"",o=n?`${n.replace(/\/$/,"")}/api/send-report.php`:"/api/send-report.php",p=await fetch(o,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({auth_token:Ce.AUTH_TOKEN,destinatario:s,cc:ye,assunto:F,corpoHtml:C})});if(!p.ok){const h=await p.text();throw new Error(h||`Erro ${p.status}`)}k(`Email enviado para ${s}.`,"success"),S(""),f()}catch(n){x(n.message||"Erro ao enviar email.")}finally{O(!1),i()}};return e.jsx("div",{className:"modal-overlay",onClick:f,children:e.jsxs("div",{className:"modal",onClick:v=>v.stopPropagation(),children:[e.jsx("h2",{children:"Enviar documento por email"}),e.jsxs("p",{className:"text-muted",children:["O email será enviado para o endereço indicado e em cópia para ",ye,"."]}),e.jsxs("form",{onSubmit:I,children:[e.jsxs("label",{children:["Email do destinatário ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:$,onChange:v=>{S(v.target.value),x("")},placeholder:"ex: cliente@empresa.pt",required:!0,disabled:A})]}),M&&e.jsx("p",{className:"form-erro",children:M}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:f,disabled:A,children:"Cancelar"}),e.jsx("button",{type:"submit",disabled:A,children:A?"A enviar…":"Enviar"})]})]})]})})}const Z={nome:"JOSÉ GONÇALVES CERQUEIRA (NAVEL-AÇORES), Lda.",sede:"Rua Engº Abel Ferin Coutinho · Apt. 1481 · 9501-802 Ponta Delgada",telefones:"Tel: 296 205 290 / 296 630 120",web:"www.navel.pt"};function aa(g,f,y,N,k,R={}){const i=U,$=R.logoUrl??"/manut/logo.png",S=new Date().toISOString().slice(0,10),A=H(S,!0),O=new Date().getFullYear(),M=f.map(s=>{const u=k(s.subcategoriaId),n=y.filter(c=>c.maquinaId===s.id),o=n.filter(c=>c.status==="concluida").sort((c,d)=>d.data.localeCompare(c.data))[0],p=n.filter(c=>c.status==="agendada"||c.status==="pendente").sort((c,d)=>c.data.localeCompare(d.data))[0],h=p&&p.data<S,E=n.filter(c=>c.status==="concluida").length,q=o?N.find(c=>c.manutencaoId===o.id):null;let P,D;return s.proximaManut?h?(P="badge-atraso",D="Em atraso"):(P="badge-ok",D="Conforme"):(P="badge-montagem",D="Por instalar"),{m:s,sub:u,ultima:o,proxima:p,emAtraso:h,totalManuts:E,relUltima:q,estadoBadge:P,estadoLabel:D}}),x=f.length,z=M.filter(s=>s.emAtraso).length,F=M.filter(s=>!s.emAtraso&&s.m.proximaManut).length,C=M.filter(s=>!s.m.proximaManut).length,I=x>0?Math.round(F/x*100):0;return`<!DOCTYPE html>
<html lang="pt">
<head>
<meta charset="utf-8">
<title>Relatório de Frota — ${i(g.nome)}</title>
<style>
/* ── Reset / Página ── */
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
@page{size:A4 portrait;margin:14mm 12mm 12mm}
body{font-family:'Segoe UI',Arial,sans-serif;font-size:9pt;color:#1e293b;background:#fff;line-height:1.4}
/* ── Paleta ── */
:root{
  --azul:#0f4c81;--azul-light:#e8f1fb;--cinza:#f8fafc;
  --verde:#15803d;--verde-light:#dcfce7;
  --vermelho:#dc2626;--vermelho-light:#fee2e2;
  --laranja:#d97706;--laranja-light:#fef3c7;
  --muted:#64748b;--border:#e2e8f0;
}
/* ── Cabeçalho ── */
.header{display:flex;align-items:flex-start;justify-content:space-between;padding-bottom:8px;border-bottom:2px solid var(--azul);margin-bottom:10px}
.header-logo img{height:36px;object-fit:contain}
.header-empresa{text-align:right;font-size:7.5pt;color:var(--muted);line-height:1.5}
.header-empresa strong{color:var(--azul);font-size:8.5pt}
/* ── Títulos de secção ── */
.secao-titulo{background:var(--azul);color:#fff;padding:4px 8px;font-size:8pt;font-weight:700;text-transform:uppercase;letter-spacing:.06em;margin:10px 0 6px;border-radius:3px}
/* ── Ficha do cliente ── */
.cliente-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:3px 12px;padding:8px 10px;background:var(--cinza);border-radius:4px;border:1px solid var(--border);margin-bottom:10px}
.cliente-field{display:flex;flex-direction:column;gap:1px}
.c-label{font-size:7pt;text-transform:uppercase;letter-spacing:.04em;color:var(--muted)}
.c-value{font-size:8.5pt;font-weight:600;color:#1e293b}
/* ── KPIs ── */
.kpis{display:grid;grid-template-columns:repeat(4,1fr);gap:6px;margin-bottom:10px}
.kpi-card{background:var(--cinza);border:1px solid var(--border);border-radius:5px;padding:7px 8px;text-align:center}
.kpi-card.kpi-verde{background:var(--verde-light);border-color:var(--verde)}
.kpi-card.kpi-vermelho{background:var(--vermelho-light);border-color:var(--vermelho)}
.kpi-card.kpi-laranja{background:var(--laranja-light);border-color:var(--laranja)}
.kpi-numero{font-size:18pt;font-weight:800;line-height:1.1}
.kpi-verde .kpi-numero{color:var(--verde)}
.kpi-vermelho .kpi-numero{color:var(--vermelho)}
.kpi-laranja .kpi-numero{color:var(--laranja)}
.kpi-label{font-size:7pt;color:var(--muted);text-transform:uppercase;letter-spacing:.04em;margin-top:2px}
/* ── Tabela de frota ── */
.tabela-frota{width:100%;border-collapse:collapse;font-size:8pt}
.tabela-frota th{background:var(--azul);color:#fff;padding:4px 5px;text-align:left;font-size:7.5pt;font-weight:700;text-transform:uppercase;letter-spacing:.04em}
.tabela-frota td{padding:3.5px 5px;border-bottom:1px solid var(--border);vertical-align:middle}
.tabela-frota tr:nth-child(even) td{background:var(--cinza)}
.tabela-frota tr:hover td{background:var(--azul-light)}
.col-equip{width:28%}
.col-serie{width:16%;font-family:monospace;font-size:7.5pt;color:var(--muted)}
.col-ultima{width:14%;text-align:center}
.col-proxima{width:14%;text-align:center}
.col-total{width:8%;text-align:center;color:var(--muted)}
.col-estado{width:13%;text-align:center}
.col-num{width:7%;text-align:center;color:var(--muted);font-size:7pt}
/* ── Badges ── */
.badge{display:inline-block;padding:1.5px 6px;border-radius:10px;font-size:7pt;font-weight:700;white-space:nowrap}
.badge-ok{background:var(--verde-light);color:var(--verde)}
.badge-atraso{background:var(--vermelho-light);color:var(--vermelho)}
.badge-montagem{background:var(--laranja-light);color:var(--laranja)}
.data-atraso{color:var(--vermelho);font-weight:600}
.data-ok{color:var(--verde)}
/* ── Rodapé ── */
.rodape{margin-top:12px;padding-top:6px;border-top:1px solid var(--border);font-size:7pt;color:var(--muted);display:flex;justify-content:space-between;align-items:center}
.rodape-data{font-size:7pt;color:var(--muted)}
</style>
</head>
<body>

<!-- Cabeçalho -->
<div class="header">
  <div class="header-logo">
    <img src="${$}" alt="Navel-Açores">
  </div>
  <div class="header-empresa">
    <strong>${i(Z.nome)}</strong><br>
    ${i(Z.sede)}<br>
    ${i(Z.telefones)} · ${i(Z.web)}
  </div>
</div>

<!-- Título -->
<div class="secao-titulo">Relatório Executivo de Frota — ${O}</div>

<!-- Ficha do cliente -->
<div class="cliente-grid">
  <div class="cliente-field">
    <span class="c-label">Cliente</span>
    <span class="c-value">${i(g.nome)}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">NIF</span>
    <span class="c-value">${i(g.nif??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Localidade</span>
    <span class="c-value">${i(g.localidade??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Morada</span>
    <span class="c-value">${i(g.morada??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Telefone</span>
    <span class="c-value">${i(g.telefone??"—")}</span>
  </div>
  <div class="cliente-field">
    <span class="c-label">Email</span>
    <span class="c-value">${i(g.email??"—")}</span>
  </div>
</div>

<!-- KPIs -->
<div class="kpis">
  <div class="kpi-card">
    <div class="kpi-numero">${x}</div>
    <div class="kpi-label">Equipamentos</div>
  </div>
  <div class="kpi-card ${I>=80?"kpi-verde":I>=50?"kpi-laranja":"kpi-vermelho"}">
    <div class="kpi-numero">${I}%</div>
    <div class="kpi-label">Taxa de cumprimento</div>
  </div>
  <div class="kpi-card ${z>0?"kpi-vermelho":"kpi-verde"}">
    <div class="kpi-numero">${z}</div>
    <div class="kpi-label">Em atraso</div>
  </div>
  <div class="kpi-card ${C>0?"kpi-laranja":""}">
    <div class="kpi-numero">${C}</div>
    <div class="kpi-label">Por instalar</div>
  </div>
</div>

<!-- Tabela de frota -->
<div class="secao-titulo">Frota de equipamentos (${x})</div>
<table class="tabela-frota">
  <thead>
    <tr>
      <th class="col-equip">Equipamento / Modelo</th>
      <th class="col-serie">Nº Série</th>
      <th class="col-ultima">Última manut.</th>
      <th class="col-proxima">Próxima manut.</th>
      <th class="col-total">Nº serv.</th>
      <th class="col-estado">Estado</th>
      <th class="col-num">Últ. relatório</th>
    </tr>
  </thead>
  <tbody>
    ${M.map(({m:s,sub:u,ultima:n,proxima:o,relUltima:p,estadoBadge:h,estadoLabel:E})=>`
    <tr>
      <td class="col-equip">
        <strong>${i(s.marca)} ${i(s.modelo)}</strong>
        ${u?`<br><span style="font-size:7pt;color:var(--muted)">${i(u.nome)}</span>`:""}
      </td>
      <td class="col-serie">${i(s.numeroSerie)}</td>
      <td class="col-ultima" style="text-align:center">${n?H(n.data,!0):"—"}</td>
      <td class="col-proxima" style="text-align:center">
        ${o?`<span class="${o.data<S?"data-atraso":"data-ok"}">${H(o.data,!0)}</span>`:s.proximaManut?`<span class="${s.proximaManut<S?"data-atraso":"data-ok"}">${H(s.proximaManut,!0)}</span>`:"—"}
      </td>
      <td class="col-total">${s.proximaManut?y.filter(q=>q.maquinaId===s.id&&q.status==="concluida").length:"—"}</td>
      <td class="col-estado" style="text-align:center"><span class="badge ${h}">${i(E)}</span></td>
      <td class="col-num">${p?.numeroRelatorio?`<span style="font-size:7pt">${i(p.numeroRelatorio)}</span>`:"—"}</td>
    </tr>`).join("")}
  </tbody>
</table>

${z>0?`
<div class="secao-titulo" style="background:var(--vermelho);margin-top:12px">Manutenções em atraso (${z})</div>
<table class="tabela-frota">
  <thead>
    <tr>
      <th style="width:35%">Equipamento</th>
      <th style="width:18%">Nº Série</th>
      <th style="width:15%">Data prevista</th>
      <th style="width:10%">Dias atraso</th>
      <th style="width:22%">Observações</th>
    </tr>
  </thead>
  <tbody>
    ${M.filter(s=>s.emAtraso).map(({m:s,sub:u,proxima:n})=>{const o=Math.max(0,Math.floor((new Date(S)-new Date(n.data))/864e5));return`<tr>
        <td><strong>${i(s.marca)} ${i(s.modelo)}</strong>${u?` <span style="color:var(--muted);font-size:7pt">· ${i(u.nome)}</span>`:""}</td>
        <td style="font-family:monospace;font-size:7.5pt">${i(s.numeroSerie)}</td>
        <td class="data-atraso">${H(n.data,!0)}</td>
        <td class="data-atraso" style="text-align:center;font-weight:700">${o}d</td>
        <td style="font-size:7.5pt;color:var(--muted)">${i(n.observacoes??"")}</td>
      </tr>`}).join("")}
  </tbody>
</table>`:""}

<!-- Rodapé -->
<div class="rodape">
  <span>${i(ke)}</span>
  <span class="rodape-data">Documento gerado em ${A}</span>
</div>

</body>
</html>`}const ta={pendente:"Pendente",agendada:"Agendada",concluida:"Executada"};function ga(){const{clientes:g,maquinas:f,manutencoes:y,relatorios:N,addCliente:k,updateCliente:R,removeCliente:i,getSubcategoria:$,getCategoria:S,getChecklistBySubcategoria:A,getRelatorioByManutencao:O}=Ne(),{canDelete:M,canEditCliente:x,canAddCliente:z,isAdmin:F}=Le(),{showToast:C}=ne(),{showGlobalLoading:I,hideGlobalLoading:v}=le(),s=Ge(),[u,n]=m.useState(null),[o,p]=m.useState(null),[h,E]=m.useState("categorias"),[q,P]=m.useState(null),[D,c]=m.useState(null),[d,G]=m.useState(null),[J,K]=m.useState(null),[re,ee]=m.useState(null),[w,Y]=m.useState(null),[B,ae]=m.useState(null),[te,de]=m.useState(null),[T,L]=m.useState({nif:"",nome:"",morada:"",codigoPostal:"",localidade:"",telefone:"",email:""}),[ce,V]=m.useState(""),[se,me]=m.useState(""),ue=Oe(se,250),$e=()=>{L({nif:"",nome:"",morada:"",codigoPostal:"",localidade:"",telefone:"",email:""}),V(""),n("add")},Se=a=>{L({nif:a.nif,nome:a.nome,morada:a.morada||"",codigoPostal:a.codigoPostal||"",localidade:a.localidade||"",telefone:a.telefone||"",email:a.email||""}),V(""),n("edit")},Me=a=>{p(a),E("categorias"),P(null),c(null),G(null),L({nif:a.nif,nome:a.nome,morada:a.morada||"",codigoPostal:a.codigoPostal||"",localidade:a.localidade||"",telefone:a.telefone||"",email:a.email||""}),n("ficha")},pe=()=>{n(null),p(null),E("categorias"),P(null),c(null),G(null)},ze=a=>{if(a.preventDefault(),V(""),!T.email?.trim()){V("O email do cliente é obrigatório para envio de lembretes e relatórios.");return}if(u==="add"){if(k(T)===null){V("Já existe um cliente com este NIF.");return}C("Cliente adicionado com sucesso.","success")}else{const{nif:t,...r}=T;R(t,r),o?.nif===t&&p(j=>j?{...j,...r}:null),C("Dados do cliente actualizados.","success")}u!=="ficha"&&n(null)},Q=a=>f.filter(t=>t.clienteNif===a).length,he=a=>f.filter(t=>t.clienteNif===a),ge=async a=>{const t=he(a.nif);if(t.length===0){C("Este cliente não tem equipamentos registados.","warning");return}I();try{const r=aa(a,t,y,N??[],$,{logoUrl:"/manut/logo.png"}),j=`frota_${a.nif}_${new Date().toISOString().slice(0,10)}.pdf`;await Ke(r,j)}catch{C("Erro ao gerar relatório de frota.","error",4e3)}finally{v()}},_=o?he(o.nif):[],De=_.reduce((a,t)=>{const r=$(t.subcategoriaId),j=r?S(r.categoriaId):null;return j&&!a.find(l=>l.id===j.id)&&a.push(j),a},[]).sort((a,t)=>(a.nome||"").localeCompare(t.nome||"")),Pe=q?_.filter(a=>$(a.subcategoriaId)?.categoriaId===q.id).reduce((a,t)=>{const r=$(t.subcategoriaId);return r&&!a.find(j=>j.id===r.id)&&a.push(r),a},[]).sort((a,t)=>(a.nome||"").localeCompare(t.nome||"")):[],Ae=D?_.filter(a=>a.subcategoriaId===D.id):[],xe=a=>y.filter(t=>t.maquinaId===a).sort((t,r)=>new Date(r.data)-new Date(t.data)),Fe=m.useMemo(()=>{const a=ue.trim().toLowerCase();if(!a)return g;const t=a.split(/\s+/).filter(Boolean);return g.filter(r=>{const j=(r.nif||"").toLowerCase().includes(a),l=t.some(b=>(r.nome||"").toLowerCase().includes(b));return j||l})},[ue,g]);return e.jsxs("div",{className:"page",children:[e.jsxs("div",{className:"page-header",children:[e.jsxs("div",{children:[e.jsxs("button",{type:"button",className:"btn-back",onClick:()=>s(-1),children:[e.jsx(W,{size:20}),"Voltar atrás"]}),e.jsx("h1",{children:"Clientes"}),e.jsx("p",{className:"page-sub",children:"Empresas e proprietários de equipamentos Navel"})]}),z&&e.jsxs("button",{type:"button",onClick:$e,children:[e.jsx(ie,{size:18})," Novo cliente"]})]}),e.jsxs("div",{className:"search-bar",children:[e.jsx(Re,{size:18,className:"search-icon"}),e.jsx("input",{type:"search",value:se,onChange:a=>me(a.target.value),placeholder:"Pesquisar por NIF ou palavra do nome...","aria-label":"Pesquisar clientes"}),se&&e.jsx("button",{type:"button",className:"search-clear",onClick:()=>me(""),"aria-label":"Limpar pesquisa",children:"×"})]}),e.jsx("div",{className:"table-card card clientes-table",children:e.jsxs("table",{className:"data-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"NIF"}),e.jsx("th",{children:"Nome do Cliente"}),e.jsx("th",{children:"Morada"}),e.jsx("th",{children:"Localidade"}),e.jsx("th",{children:"Telefone"}),e.jsx("th",{children:"Email"}),e.jsx("th",{children:"Máquinas"}),e.jsx("th",{})]})}),e.jsx("tbody",{children:Fe.map(a=>e.jsxs("tr",{children:[e.jsx("td",{"data-label":"NIF",children:e.jsx("code",{children:a.nif})}),e.jsx("td",{"data-label":"Nome",children:e.jsx("button",{type:"button",className:"btn-link-inline",onClick:()=>Me(a),title:"Abrir ficha",children:e.jsx("strong",{children:a.nome})})}),e.jsx("td",{"data-label":"Morada",children:a.morada||"—"}),e.jsx("td",{"data-label":"Localidade",children:a.localidade||"—"}),e.jsx("td",{"data-label":"Telefone",children:a.telefone||"—"}),e.jsx("td",{"data-label":"Email",children:a.email?a.email:e.jsxs("span",{className:"sem-email-aviso",title:"Email em falta — edite o cliente para corrigir",children:[e.jsx(_e,{size:13})," Sem email"]})}),e.jsx("td",{"data-label":"Máquinas",children:Q(a.nif)}),e.jsxs("td",{className:"actions","data-label":"",children:[Q(a.nif)>0&&e.jsx("button",{className:"icon-btn secondary",onClick:()=>ge(a),title:"Relatório executivo de frota (PDF)",children:e.jsx(ve,{size:16})}),x&&e.jsx("button",{className:"icon-btn secondary",onClick:()=>Se(a),title:"Editar",children:e.jsx(fe,{size:16})}),M&&e.jsx("button",{className:"icon-btn danger",onClick:()=>{i(a.nif),C("Cliente eliminado.","info")},disabled:Q(a.nif)>0,title:Q(a.nif)>0?"Elimine as máquinas primeiro":"Eliminar",children:e.jsx(Xe,{size:16})})]})]},a.nif))})]})}),u==="ficha"&&o&&e.jsx("div",{className:"modal-overlay modal-ficha-overlay",onClick:pe,children:e.jsxs("div",{className:"modal modal-ficha-cliente",onClick:a=>a.stopPropagation(),children:[e.jsxs("div",{style:{display:"flex",alignItems:"center",justifyContent:"space-between",marginBottom:"0.5rem"},children:[e.jsxs("h2",{style:{margin:0},children:["Ficha do cliente — ",o.nome]}),_.length>0&&e.jsxs("button",{className:"btn secondary",style:{display:"flex",alignItems:"center",gap:"0.35rem",fontSize:"0.82rem"},onClick:()=>ge(o),title:"Relatório executivo de frota (PDF)",children:[e.jsx(ve,{size:15})," Relatório de frota"]})]}),e.jsxs("div",{className:"ficha-cliente-dados",children:[e.jsxs("p",{children:[e.jsx("strong",{children:"NIF:"})," ",o.nif," · ",e.jsx("strong",{children:"Morada:"})," ",o.morada||"—"]}),e.jsxs("p",{children:[e.jsx("strong",{children:"Localidade:"})," ",o.codigoPostal," ",o.localidade," · ",e.jsx("strong",{children:"Telefone:"})," ",o.telefone||"—"," · ",e.jsx("strong",{children:"Email:"})," ",o.email||"—"]})]}),_.length===0?e.jsxs("div",{className:"ficha-empty",children:[e.jsx("p",{className:"text-muted",children:"Este cliente ainda não tem máquinas registadas."}),z&&e.jsxs("button",{type:"button",className:"btn-add-maquina",onClick:()=>K({mode:"add",clienteNif:o.nif}),children:[e.jsx(ie,{size:18})," Adicionar máquina"]})]}):e.jsxs(e.Fragment,{children:[h==="categorias"&&e.jsxs("div",{className:"ficha-categorias",children:[e.jsx("h3",{children:"Categorias"}),e.jsx("div",{className:"categorias-grid",children:De.map(a=>{const t=_.filter(r=>$(r.subcategoriaId)?.categoriaId===a.id).length;return e.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>{P(a),E("subcategorias")},children:[e.jsx("h4",{children:a.nome}),e.jsxs("p",{children:[t," equipamento(s)"]}),e.jsx(oe,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},a.id)})})]}),h==="subcategorias"&&q&&e.jsxs("div",{className:"ficha-subcategorias",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{P(null),E("categorias")},children:[e.jsx(W,{size:16})," Categorias"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",q.nome]})]}),e.jsx("h3",{children:"Subcategorias"}),e.jsx("div",{className:"categorias-grid",children:Pe.map(a=>{const t=_.filter(r=>r.subcategoriaId===a.id).length;return e.jsxs("button",{type:"button",className:"categoria-card",onClick:()=>{c(a),E("maquinas")},children:[e.jsx("h4",{children:a.nome}),e.jsxs("p",{children:[t," equipamento(s)"]}),e.jsx(oe,{size:20,style:{marginTop:"0.5rem",opacity:.6}})]},a.id)})})]}),h==="maquinas"&&D&&e.jsxs("div",{className:"ficha-maquinas-view",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{c(null),E("subcategorias")},children:[e.jsx(W,{size:16})," Subcategorias"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",D.nome]})]}),e.jsx("h3",{children:"Frota de máquinas"}),e.jsx("div",{className:"maquinas-ficha-lista",children:Ae.map(a=>e.jsxs("button",{type:"button",className:"maquina-ficha-card",onClick:()=>{G(a),E("maquina-detalhe")},children:[e.jsxs("strong",{children:[a.marca," ",a.modelo]}),e.jsxs("span",{className:"text-muted",children:[" — Nº Série: ",a.numeroSerie]}),e.jsx(oe,{size:18,style:{marginLeft:"auto",opacity:.6}})]},a.id))})]}),h==="maquina-detalhe"&&d&&(()=>{const a=f.find(l=>l.id===d.id)??d,t=a.documentos??[],r=l=>t.find(b=>b.tipo===l),j=l=>be.find(b=>b.id===l)?.label??l;return e.jsxs("div",{className:"ficha-maquina-detalhe",children:[e.jsxs("div",{className:"equipamentos-nav",children:[e.jsxs("button",{type:"button",className:"breadcrumb-btn",onClick:()=>{G(null),E("maquinas")},children:[e.jsx(W,{size:16})," Frota"]}),e.jsxs("span",{className:"breadcrumb",children:["/ ",d.marca," ",d.modelo]})]}),e.jsxs("div",{className:"maquina-detalhe-header",children:[e.jsxs("h3",{children:[d.marca," ",d.modelo," — Nº Série: ",d.numeroSerie]}),e.jsx("div",{className:"maquina-detalhe-actions",children:F&&e.jsxs(e.Fragment,{children:[e.jsxs("button",{type:"button",className:"secondary",onClick:()=>{ee(null),K({mode:"edit",maquina:d})},children:[e.jsx(fe,{size:16})," Editar"]}),e.jsxs("button",{type:"button",className:"secondary",onClick:()=>ee(d),children:[e.jsx(Be,{size:16})," Documentação"]})]})})]}),e.jsx("h4",{children:"Documentação obrigatória"}),e.jsx("div",{className:"doc-table-wrapper",children:e.jsxs("table",{className:"data-table doc-table",children:[e.jsx("thead",{children:e.jsxs("tr",{children:[e.jsx("th",{children:"Documento"}),e.jsx("th",{children:"Existe"}),e.jsx("th",{children:"Ações"})]})}),e.jsx("tbody",{children:be.map(l=>{const b=l.id==="outros"?t.filter(Ie=>Ie.tipo==="outros")[0]:r(l.id),X=!!b;return e.jsxs("tr",{children:[e.jsx("td",{"data-label":"Documento",children:j(l.id)}),e.jsx("td",{"data-label":"Existe",children:e.jsx("span",{className:X?"badge badge-sim":"badge badge-nao",children:X?"Sim":"Não"})}),e.jsx("td",{className:"doc-table-actions","data-label":"Ações",children:b?e.jsxs(e.Fragment,{children:[e.jsx("a",{href:Ee(b.url),target:"_blank",rel:"noopener noreferrer",className:"icon-btn secondary",title:"Visualizar",children:e.jsx(Ye,{size:16})}),e.jsx("button",{type:"button",className:"icon-btn secondary",onClick:()=>de({documento:b,maquina:a}),title:"Enviar por email",children:e.jsx(Qe,{size:16})})]}):e.jsx("span",{className:"text-muted",children:"—"})})]},l.id)})})]})}),e.jsx("h4",{children:"Histórico de manutenções"}),e.jsx("div",{className:"manutencoes-histórico",children:xe(d.id).length===0?e.jsx("p",{className:"text-muted",children:"Nenhuma manutenção registada."}):xe(d.id).map(l=>{const b=O(l.id);return e.jsxs("div",{className:"manutencao-item",children:[e.jsxs("button",{type:"button",className:"manutencao-item-btn",onClick:()=>Y({manutencao:l,relatorio:b,maquina:d,cliente:o}),children:[e.jsxs("div",{children:[e.jsx("strong",{children:qe(new Date(l.data),"d MMM yyyy",{locale:we})}),e.jsxs("span",{className:"text-muted",children:[" — ",l.tecnico||b?.tecnico||"Não atribuído"]})]}),e.jsx("span",{className:`badge badge-${l.status}`,children:ta[l.status]})]}),b?.assinadoPeloCliente&&e.jsx("button",{type:"button",className:"btn-enviar-email",onClick:X=>{X.stopPropagation(),ae({manutencao:l,relatorio:b,maquina:d,cliente:o})},children:"Enviar relatório por email"})]},l.id)})})]})})(),z&&e.jsxs("button",{type:"button",className:"btn-add-maquina",onClick:()=>K({mode:"add",clienteNif:o.nif}),style:{marginTop:"1rem"},children:[e.jsx(ie,{size:18})," Adicionar máquina"]})]}),e.jsx("div",{className:"form-actions",style:{marginTop:"1rem"},children:e.jsx("button",{type:"button",className:"secondary",onClick:pe,children:"Fechar"})})]})}),J&&e.jsx(Ve,{isOpen:!0,onClose:()=>K(null),mode:J.mode,clienteNifLocked:J.clienteNif,maquina:J.maquina}),e.jsx(He,{isOpen:!!re,onClose:()=>ee(null),maquina:re}),w&&e.jsx("div",{className:"modal-overlay",onClick:()=>Y(null),children:e.jsxs("div",{className:"modal modal-relatorio modal-relatorio-ficha",onClick:a=>a.stopPropagation(),children:[e.jsxs("div",{className:"modal-relatorio-header",children:[e.jsx("h2",{children:"Relatório de manutenção"}),e.jsx("button",{type:"button",className:"secondary",onClick:()=>Y(null),children:"Fechar"})]}),e.jsx(Ue,{relatorio:w.relatorio,manutencao:w.manutencao,maquina:w.maquina,cliente:w.cliente,checklistItems:w.maquina?A(w.maquina.subcategoriaId,w.manutencao?.tipo||"periodica"):[]}),w.relatorio?.assinadoPeloCliente&&e.jsx("div",{className:"form-actions",style:{marginTop:"1rem"},children:e.jsx("button",{type:"button",onClick:()=>{Y(null),ae({manutencao:w.manutencao,relatorio:w.relatorio,maquina:w.maquina,cliente:w.cliente})},children:"Enviar relatório por email"})})]})}),B&&e.jsx(Ze,{isOpen:!0,onClose:()=>ae(null),manutencao:B.manutencao,relatorio:B.relatorio,maquina:B.maquina,cliente:B.cliente}),te&&e.jsx(ea,{isOpen:!0,onClose:()=>de(null),documento:te.documento,maquina:te.maquina}),u&&u!=="ficha"&&e.jsx("div",{className:"modal-overlay",onClick:()=>n(null),children:e.jsxs("div",{className:"modal",onClick:a=>a.stopPropagation(),children:[e.jsx("h2",{children:u==="add"?"Novo cliente":"Editar cliente"}),ce&&e.jsx("p",{className:"form-erro",children:ce}),e.jsxs("form",{onSubmit:ze,children:[e.jsxs("label",{children:["NIF ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{required:!0,value:T.nif,onChange:a=>L(t=>({...t,nif:a.target.value})),placeholder:"123456789",readOnly:u==="edit",className:u==="edit"?"readonly":""})]}),e.jsxs("label",{children:["Nome do Cliente ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{required:!0,value:T.nome,onChange:a=>L(t=>({...t,nome:a.target.value})),placeholder:"Razão social"})]}),e.jsxs("label",{children:["Morada",e.jsx("input",{value:T.morada,onChange:a=>L(t=>({...t,morada:a.target.value}))})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("label",{children:["Código Postal",e.jsx("input",{value:T.codigoPostal,onChange:a=>L(t=>({...t,codigoPostal:a.target.value}))})]}),e.jsxs("label",{children:["Localidade",e.jsx("input",{value:T.localidade,onChange:a=>L(t=>({...t,localidade:a.target.value}))})]})]}),e.jsxs("div",{className:"form-row",children:[e.jsxs("label",{children:["Telefone",e.jsx("input",{value:T.telefone,onChange:a=>L(t=>({...t,telefone:a.target.value}))})]}),e.jsxs("label",{children:["Email ",e.jsx("span",{className:"required",children:"*"}),e.jsx("input",{type:"email",value:T.email,onChange:a=>L(t=>({...t,email:a.target.value})),placeholder:"email@cliente.pt"})]})]}),e.jsxs("div",{className:"form-actions",children:[e.jsx("button",{type:"button",className:"secondary",onClick:()=>n(null),children:"Cancelar"}),e.jsx("button",{type:"submit",children:u==="add"?"Adicionar":"Guardar"})]})]})]})})]})}export{ga as default};
