import{t as s,c as i}from"./format-BvtC0E8y.js";function o(a,r,e){const t=s(a,e?.in);return isNaN(r)?i(a,NaN):(r&&t.setDate(t.getDate()+r),t)}export{o as a};
